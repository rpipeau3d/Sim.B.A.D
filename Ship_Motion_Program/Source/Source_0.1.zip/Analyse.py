##  This ship motion program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  This program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program.
##  If not, see <https://www.gnu.org/licenses/>.

# Import modules
import numpy as np
import matplotlib.pyplot as plt
from math import ceil
from prettytable import PrettyTable
import Max_Min as MM
from IRF import calc_irf_mov
from wave_excitation import wave_excitation

def Mov(respons,freq_file,res_file):
# Reading the frequency file
    with open(freq_file,'r') as df:
        raw = df.readlines()
        print('\nReading the file results in the ' + freq_file + ' file')
        num_freq = len(raw)

# Enumerate to split the result file
        freq = {}
        freq = np.zeros(num_freq).astype(np.float)
        for i, line in enumerate(raw, start=0):
            freq[i] = raw[i].split()[0]
        #print(freq)

# Reading the RAO movement file
    with open(res_file,'r') as df:
        raw = df.readlines()
        print('\nReading the file results in the ' + res_file + ' file')
        num_mov = len(raw)

# Enumerate to split the result file
        mov = {}
        mov = np.zeros(num_mov).astype(np.float)
        for i, line in enumerate(raw, start=0):
            mov[i] = raw[i].split()[0]
        #print(mov)

# Calculate IRF of RAO movement
    irft, irfmov = calc_irf_mov(num_freq,freq,mov)

# Plots of RAO movement IRF
    repons = input('Do you want plots of Motion RAO IRF?: Yes or No (default: Yes)\n')
    if repons !='':
        repons = str(repons)
    else:
        repons = 'Yes'

    if repons == 'Yes':
# Plots of RAO movement IRF
        respons = np.int(respons)-1
        Ecrit = np.zeros(6).astype(np.str)
        Ecrit = ['Surge','Sway ','Heave','Roll ','Pitch','Yaw  ']
        try:      
            plt.interactive(True)
            plt.figure()
            plt.plot(irft,irfmov,'r-',label=Ecrit[respons])
            plt.xlabel('Time (s)')
            plt.ylabel('Motion RAO IRF')
            plt.grid(True)
            plt.legend()
            plt.title('Motion RAO IRF')
            plt.savefig(Ecrit[respons]+" RAO IRF.pdf")
        except:
            pass
#Calculation of wave and motion time series
    move_ts_t,move_ts = wave_excitation(respons,freq,irft,irfmov)

# Determination of max and min
    inum_start = 0
    inum_end = len(move_ts)-1
    max_mov = MM.Maximum(inum_start,inum_end,move_ts)
    min_mov = MM.Minimum(inum_start,inum_end,move_ts)

# Determination an ranking of of peaks in a time series
# Determination of f1/3, f1/10, max and min statistical values    
    h3,h10,hminstd,hmaxstd = MM.Rank_peakMov(inum_start,inum_end,move_ts)

# Writing of results in a txt file
    with open(Ecrit[respons]+'.txt','w') as fid:
        fid.write("Type:        Min       Max       Minst.      Maxst.     F1/3       F1/10\n")
        tmp = np.array([Ecrit[respons],min_mov,max_mov,hminstd,hmaxstd,h3,h10])
        np.savetxt(fid,[tmp],fmt="%-10.6s")
#--------------------------------------------------------------------------------
