##  This ship motion program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  This program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program.
##  If not, see <https://www.gnu.org/licenses/>.

# Import modules
import numpy as np
import waveFunctions as wf
import matplotlib.pyplot as plt
from math import ceil
import plot_WSS as plW
import models as ms
import sys

## import convolution
from excitation_convol import convolution

def wave_excitation(respons,freqs,irft,irfmov):

# Read characteristics of calculation: Hs, Tp, h,
# time (total duration of simulation), dt time step...
    Hs = input('Wave height Hs in m (default value:0.001 m): ')
    if Hs !='':
        Hs = np.float(Hs)
    else:
        Hs = np.float('0.001')
    print('Wave height Hs in m: ',Hs,'m')

    Tp = input('Peak period Tp in s (default value:0.1 s): ')
    if Tp !='':
        Tp = np.float(Tp)
    else:
        Tp = np.float('0.1')
    print('Peak period Tp in s: ',Tp,'s')

##    h = input('Water depth in m (default value:999.0 m): ')
##    if h !='':
##        h = np.float(h)
##    else:
##        h = np.float('999.0')
##    print('Water depth in m: ',h,'m')

# Read total duration of simulation (time) and time step dt
    time = input('Simulation duration in s (default value: 14400): ')
    if time != '':
        time = np.float(time)
    else:
        time = np.float('14400.0')
    dt = input('Time step between 0.1 and 1 s (default value: 0.5): ')
    if dt != '':
        dt = np.float(dt)
    else:
        dt = np.float('0.5')
    if dt != 0.0:
        num_dt = int(ceil(time/dt))
    else:
        print('Time step equal to zero')
        sys.exit()
    if num_dt%2==1: num_dt = num_dt+1 # num_dt should be an even integer

    eta_t = np.zeros(num_dt)
    for istep in range (num_dt-1):
        eta_t[istep+1] = eta_t[istep] + dt
    #print(eta_t)

# Wave frequencies
    fp = 2*np.pi/Tp
    iFreq = 0
    while fp > freqs[iFreq]:
        iFreq +=1
    else:
        freqs[iFreq] = fp
    #print('Wave frequencies:\n',freq)
# Choice of spectrum model and calculation of spectral values
    reponsSM = input('1: Jonswap spectrum density model,\n'
                   +'2: Bretschneider spectrum density model,\n'
                   +'3: Torsethaugen spectrum density model,\n'
                   +'4: McCormick spectrum density model,\n'
                   +'5: OchiHubble spectrum density model,\n'
                   +'6: Wallop spectrum density model,\n'
                   +'Default: 1\n')
    if reponsSM !='':
        reponsSM = str(reponsSM)
    else:
        reponsSM = '1'
        
    if '1' in reponsSM:
##        specSS = wf.spectralValue(Hs,fp,freqs,iFreq)
        gam = ms.jonswap_peakfact(Hs,Tp)
        specSS = ms.Jonswap(Hm0=Hs, Tp=Tp, gamma=gam)
        specSS = specSS(freqs)
    elif '2' in reponsSM:
        specSS = ms.Bretschneider(Hm0=Hs, Tp=Tp)
        specSS = specSS(freqs)
    elif '3' in reponsSM:
        specSS = ms.Torsethaugen(Hm0=Hs, Tp=Tp)
        specSS = specSS(freqs)
    elif '4' in reponsSM:
        specSS = ms.McCormick(Hm0=Hs, Tp=Tp)
        specSS = specSS(freqs)
    elif '5' in reponsSM:
        specSS = ms.OchiHubble(Hm0=Hs, par=2)
        specSS = specSS(freqs)
    elif '6' in reponsSM:
        specSS = ms.Wallop(Hm0=Hs, Tp=Tp)
        specSS = specSS(freqs)
# Zero-out the wave spectrum above the cut-off frequency.
# We must cut-off the frequency in order to avoid nonphysical values
# Two ways to cut-off frequency: Omega > 3*Omegap or S(Omega) < S(Omegap)/100
    for iS in range(0,len(freqs)):
        if freqs[iS] > 3*fp: specSS[iS] = 0.0
        if specSS[iS] < (specSS[iFreq]/100): specSS[iS] = 0.0
# Choice of wave time series calculation type
    reponsWTS = input('1: Wave time series with random phase,\n'
                   +'2: Wave time series with the Fast method,\n'
                   +'3: Wave time series from a specific file,\n'
                   +'4: Wave time series from a specific density spectrum,\n'
                   +'Default: 2\n')
    if reponsWTS !='':
        reponsWTS = str(reponsWTS)
    else:
        reponsWTS = '2'

###########################################################
# Calculate wave time series with random phase
###########################################################
    if '1' in reponsWTS:
# Construct phaseVector
        phaseVector = wf.makePhase(eta_t,freqs)
# Calculate Wave Excitation Signal (eta in cosinus; eta1 in sinus)
        plW.Plot_specSS(reponsSM,freqs,specSS)
        eta, eta1 = wf.makeWavex(eta_t,freqs,specSS,phaseVector)

# Plot the data for verification (only eta)
        plW.Plot_WS(reponsWTS,eta_t,eta,Hs)

# Calculation of Spectral density value
# The suitable value for fs would be 1/dt
        plW.Plot_SS(reponsWTS,eta_t,eta,dt,freqs,method='2')

############################################################
# Wave excitation signal from FAST program
############################################################
    if '2' in reponsWTS:
        plW.Plot_specSS(reponsSM,freqs,specSS)
        eta = wf.makeWave_Fast(dt,num_dt,eta_t,freqs,specSS)
# Plot the data for verification.
        plW.Plot_WS(reponsWTS,eta_t,eta,Hs)

# Calculation of Spectral density value
# The suitable value for fs would be 1/dt
        plW.Plot_SS(reponsWTS,eta_t,eta,dt,freqs,method='2')

############################################################
# Wave excitation signal from a specific file
############################################################
    if '3' in reponsWTS:
        wave_data = np.loadtxt('wave_elev_South.dat')
        eta = wave_data[:,1]
        eta_t = wave_data[:,0]
        dt = eta_t[1]-eta_t[0]

# Plot the data for verification.
        plW.Plot_WS(reponsWTS,eta_t,eta,Hs)

# Calculation of Spectral density value
# The suitable value for fs would be 1/dt
        plW.Plot_SS(reponsWTS,eta_t,eta,dt,freqs,method='2')

############################################################
# Wave excitation signal from a specific density spectrum
############################################################
    if '4' in reponsWTS:
        tmp = np.loadtxt('spectre.dat')
        specVO = tmp[:,1]
        freqVO = tmp[:,0]
        plW.Plot_specSS('0',freqVO,specVO)
# Construct phaseVector
        phaseVector = wf.makePhase(eta_t,freqVO)
        eta, eta1 = wf.makeWavex(eta_t,freqVO,specVO,phaseVector)

# Plot the data for verification.
        plW.Plot_WS(reponsWTS,eta_t,eta,Hs)

# Calculation of Spectral density value
# The suitable value for fs would be 1/dt
        plW.Plot_SS(reponsWTS,eta_t,eta,dt,freqs,method='2')

############################################################
# Load movement time series
############################################################
    move_ts = np.zeros(len(eta_t)).astype(np.float)
    move_ts_t = np.zeros(len(eta_t)).astype(np.float)

    ex_f = convolution(irf=irfmov, irf_t=irft, eta=eta, eta_t=eta_t)
    move_ts_t[:] = ex_f.excitation_force.t
    move_ts[:] = ex_f.excitation_force.f

# Plot the movement time series for verification.
# Set interactive
    repons = input('Do you want plots of movement time series?: Yes or No (default: Yes)\n')
    if repons !='':
        repons = str(repons)
    else:
        repons = 'Yes'

    if repons == 'Yes':
        Ecrit = np.zeros(6).astype(np.str)
        Ecrit = ['Surge','Sway','Heave','Roll','Pitch','Yaw']
        try:      
            plt.interactive(True)
            plt.figure()
            plt.plot(move_ts_t[:], move_ts[:],'r-',label=Ecrit[respons])
            plt.xlabel('Time (s)')
            plt.ylabel('Motion time series')
            plt.grid(True)
            plt.legend()
            plt.title('Motion time series')
            plt.savefig(Ecrit[respons]+" time series.pdf")
        except:
            pass
# Writing of movement time series in a txt file
    with open(Ecrit[respons]+'_ts.txt','w') as f:
        ndt = len(eta_t)
        #print(ndt)
        np.savetxt(f,[ndt],fmt='%.1i')
        for irow in range(ndt):
            tmpa = move_ts_t[irow]
            tmpb = move_ts[irow]
            np.savetxt(f,[(tmpa,tmpb)],fmt='%.6e')
############################################################
    return move_ts_t,move_ts
