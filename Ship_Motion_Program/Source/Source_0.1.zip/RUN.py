##  This ship motion program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  This program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program.
##  If not, see <https://www.gnu.org/licenses/>.

# Import modules
import numpy as np
import Analyse as An

# Choice of one result file
repons = input('1: RAO Surge,\n'
               +'2: RAO Sway,\n'
               +'3: RAO Heave,\n'
               +'4: RAO Roll,\n'
               +'5: RAO Pitch,\n'
               +'6: RAO Yaw\n'
               )
if '1' in repons: res_file = str('RAOSurge.txt')
if '2' in repons: res_file = str('RAOSway.txt')
if '3' in repons: res_file = str('RAOHeave.txt')
if '4' in repons: res_file = str('RAORoll.txt')
if '5' in repons: res_file = str('RAOPitch.txt')
if '6' in repons: res_file = str('RAOYaw.txt')

# Frequency file
try:
    freq_file = str('Frequences.txt')
except IOError:
    print("File Frequences.txt not accessible")
    input("Press the ENTER key to continue...")
    sys.exit()

# RAO Surge
if '1' in repons:
    try:
        An.Mov('1',freq_file,res_file)
    except IOError:
        print("File RAOSurge.txt not accessible")

# RAO Sway
if '2' in repons:
    try:
        An.Mov('2',freq_file,res_file)
    except IOError:
        print("File RAOSway.txt not accessible")

# RAO Heave
if '3' in repons:
    try:
        An.Mov('3',freq_file,res_file)
    except IOError:
        print("File RAOHeave.txt not accessible")    

# RAO Roll
if '4' in repons:
    try:
        An.Mov('4',freq_file,res_file)
    except IOError:
        print("File RAORoll.txt not accessible")    

# RAO Pitch
if '5' in repons:
    try:
        An.Mov('5',freq_file,res_file)
    except IOError:
        print("File RAOPitch.txt not accessible")    

# RAO Yaw
if '6' in repons:
    try:
        An.Mov('6',freq_file,res_file)
    except IOError:
        print("File RAOYaw.txt not accessible")   

#
input("Press the ENTER key to continue...")
