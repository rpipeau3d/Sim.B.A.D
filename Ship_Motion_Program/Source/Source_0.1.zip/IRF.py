##  This ship motion program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  This program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program.
##  If not, see <https://www.gnu.org/licenses/>.

# Import modules
import numpy as np
import os
from scipy import interpolate
from progressbar import ProgressBar, Bar, Percentage
import Max_Min as MM


def calc_irf_mov(num_freq, freq, mov, t_end=100.0, n_t=1001, n_w=1001, w_min=None, w_max=None):
        '''Function to calculate the excitation impulse response function. For
        more information please see equation 2.12 in:

            Dynamics Modeling and Loads Analysis of an Offshore Floating Wind
            Turbine, J. M Jonkman, 2007, NREL/TP-500-41958

        Args:
            t_end : float
                Calculation range for the IRF. The IRF is calculated from -t_end
                to t_end
            n_t : int
                Number of timesteps in the IRF
            n_w : int
                Number of frequecy steps to use in the IRF calculation. If the
                frequency steps are different from the loaded data, the
                excitation coefficients are interpolated.

        Returns:
            No variables are directily returned by this function. The following
            internal variables are calculated:

            irf_t : np.array
                Timesteps at which the IRF is calculated
            irf_w : np.array
                Frequency steps used to calculate the IRF
            irf_mov : np.array
                The RAO movement IRF. This is a 1 dimensional np.array:
                = size(ex.irf.t)

        Note:
            When using this function it is important to look at the resulting
            IRF to insure that it is physical. The user may need to adjust the
            t_end, n_t, and n_w values in order to generate a realistic IRF.

        '''
        inum_end = num_freq - 1
        if w_min is None:
            w_min = MM.Minimum(0,inum_end,freq)
        if w_max is None:
            w_max = MM.Maximum(0,inum_end,freq)

# Permet d’obtenir un tableau 1D allant d’une valeur de départ (-t_end ou w_min)
# à une valeur de fin (t_end ou w_max) avec un nombre donné d’éléments (n_t ou n_w).
        irf_t = np.linspace(-t_end, t_end, n_t)
        irf_w = np.linspace(w_min, w_max, n_w)
        
# Tableau 1D de l'IRF des RAOs du mouvement en fonction du nombre de pas de temps

        irf_mov = np.zeros(irf_t.size)

# Interpolation sur les RAOs du mouvement en fonction de la plage de fréquences
# ex_interp est alors un tableau à 1 dimension

        interp = _interpolate_for_irf(freq, irf_w, mov)
#
        pbar_maxval = irf_t.size
        pbar = ProgressBar(widgets=['RAO movement IRF:', Percentage(), Bar()], maxval=pbar_maxval).start()
        count = 1
# Calcul de l'IRF des RAOs du mouvement 
        for t_ind, t in enumerate(irf_t):

# Tableau de valeurs des RAO à l'instant t, en fonction des fréquences

           tmp = interp[:] * np.cos(irf_w * t)

# Multiplication des efforts par 1/pi
# On condidère 1/pi au lieu de 1/2.pi du fait que l'on intègre de 0 à wmax au lieu de -wmax à wmax
           tmp *= 1. / np.pi
              
# Intégration pour obtenir l'IRF à chaque indice de pas de temps (t_ind)
           irf_mov[t_ind] = np.trapz(y=tmp, x=irf_w)
           pbar.update(count)
           count += 1

        pbar.finish()
        return irf_t,irf_mov


def _interpolate_for_irf(w_orig, w_interp, mat_in):
  '''
  Interpolate matrices for the IRF calculations
  '''
  mat_interp = np.zeros(w_interp.size)

  flip = False

# Inversion de l'ordre des valeurs dans le tableau des fréquences avec fonction flipud
  if w_orig[0] > w_orig[1]:

    w_tmp = np.flipud(w_orig)
    flip = True

  else:

    w_tmp = w_orig

# Interpolation des valeurs de RAOs du mouvement en fonction 
# des valeurs de fréquence demandées (w_interp)

  if flip is True:

    rdTmp = np.flipud(mat_in)

  else:

    rdTmp = mat_in

  f = interpolate.interp1d(x=w_tmp, y=rdTmp)
  mat_interp = f(w_interp)

  return mat_interp
