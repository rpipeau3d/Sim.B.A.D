##  This ship motion program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  This program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program.
##  If not, see <https://www.gnu.org/licenses/>.

# This file is adapted from Python code found in:
# - Tranell, J. (2021), “Seakeeping capabilities of sailing cruise 
# and passenger vessels (Master’s thesis in Marine Technology)”, NTNU, Trondheim

import numpy as np
import math
from scipy . integrate import simps
import sys

def windSpeedGrad(TWS10, z):
    """
    This fuction calculates the local velocities at each position z in the
    wind boundary layer
    Input: 
        TWS10, scalar, True wind speed at reference height 10 m [m / s]
        z, col vector or scalar, Vertical position of points [m]
    
    Output:
        TWS, col vector or scalar, Wind speed at points [m/s]
    
    """
    a = 0.11 # Hellmann exponent
    TWS = TWS10 * (z / 10) ** a
    return TWS

def wingsail_coeff(awa, asp, AoA, incl_stall):
    """
    This function calculates the lift and drag coefficients of a wingsail as 
    a function of height.
    It corrects for 3D effects by assuming an elliptical lift distribution.
    
    Inputs:
        awa, N array, Local apparent wind angle [rad]
        asp, scalar, Aspect ratio of sail [-]
        AoA, scalar, Angle of attack [rad]
        incl_stall, boolean, Include or ignore sail stall
    
    Outputs:    
        Cl, N array, Sectional lift coefficient [-]
        Cd, N array, Sectional drag coefficient [-]
    
    """
    trim = AoA + np.mean(awa)+np.pi
    # Condition for sail trim
    if trim > 2*np.pi:
        trim = trim - 2*np.pi
    #print("Sail trim = {:.2f} deg".format(math.degrees(trim)))
    # Message for stall
    alpha_stall = np.deg2rad(20) # stall angle of 2D foil [rad]
    if incl_stall=='True' and AoA > alpha_stall:
        print("\nStall occurs with an Angle of attack greater than: {:.2f} deg\n"\
              .format(math.degrees(alpha_stall)))
    
    Cl_stall = 0.5 # 2D lift coefficient after stall
    Cd_viscous = 0.01 # 2D viscous drag coefficient before stall
    Cd_stall = 2 # 2D viscous drag coefficient after stall
    if incl_stall == 'False': # linear foil theory
        Cl_2D = np.ones_like(awa) *2 * np.pi * AoA
        Cdv_2D = np.ones_like(Cl_2D) * Cd_viscous
    else :  # incl_stall == 1:
        Cl_2D = np.ones_like(awa)*np.where(abs(AoA) <= alpha_stall, 2 * np.pi * AoA, 
                         Cl_stall * (AoA / abs(AoA)))
        Cdv_2D = np.ones_like(Cl_2D)*np.where(abs(AoA) <= alpha_stall, Cd_viscous, Cd_stall)

    # Corrections for 3D effects
    Cl = Cl_2D / (1 + 2 / asp)
    Cdi = np.power(Cl, 2) / (np.pi * asp)  # induced drag
    Cd = Cdv_2D + Cdi  # total drag
    
    # print(AoA,np.mean(Cl_2D),np.mean(Cdv_2D),np.mean(Cl),np.mean(Cd))    
    return Cl, Cd

def flettner_coeff(d, aws, asp, AoA):
    """
    This function calculates the lift and drag coefficients of a Flettner 
    rotor as a function of height.
    The empirical formula is based on Tillig (2020) valid for asp of 6 and
    with an end plate twice the diameter of the rotor.
    
    Inputs:
        d, scalar, Rotor diameter [m]
        aws, N x 1 array, Local apparent wind speed [m/s]
        asp, scalar, Aspect ratio of sail [-]
        AoA, scalar, Target SR of rotor [-]

    Outputs:
        RPM, scalar, RPM of rotor, based on input target AoA
        sr, N x 1 array, Local spin ratio
        Cl, N x 1 array, Sectional lift coefficient [-]
        Cd, N x 1 array, Sectional drag coefficient [-]
        Cp, N x 1 array, Sectional power coefficient [-]

    """

    w = AoA * np.mean(aws) / (d / 2)  # required angular speed [rad/s]
    RPM = w / (2 * np.pi / 60)  # RPM of Flettner rotor at current run

    sr = (w * d / 2) / aws  # local spin ratio [-]
    SR_corr = np.where(abs(sr) > 6, 6*np.sign(sr), sr)

    # drag coefficient function: Tillig (AoA 0-6) + extrapolation (AoA > 6)
    def dragcoeff(SR):
        drag_coeff = -0.0017 * np.power(SR, 5) + 0.0464 * np.power(SR, 4) - 0.4424 * np.power(SR, 3) + \
        1.7243 * np.power(SR, 2) - 1.641 * SR + 0.6375
        return drag_coeff

    points = np.linspace(5, 6, 3)
    z = np.polyfit(points, dragcoeff(points), 1)
    Cd_extrap = np.poly1d(z)

    Cl = -0.0046 * np.power(abs(SR_corr), 5) + 0.1145 * np.power(abs(SR_corr), 4) - 0.9817 * np.power(abs(SR_corr), 3) \
        + 3.1309 * np.power(abs(SR_corr), 2) - 0.1039 * abs(SR_corr)
    Cd = np.where(abs(sr) < 6, dragcoeff(abs(sr)), Cd_extrap(abs(sr)))
    Cp = 0.0001 * np.power(abs(sr), 5) - 0.0004 * np.power(abs(sr), 4) + 0.0143 * np.power(abs(sr), 3) - 0.0168 * np.power(abs(sr), 2) +\
        0.0234 * abs(sr)

    # Make Cl negative if rotor rotates in opposite direction such that negative lift is generated.
    Cl = np.where(SR_corr < 0, -Cl, Cl)
    
    # print(np.mean(Cl),np.mean(Cd))
    
    return RPM, sr, Cl, Cd, Cp

def wingsail_forces(rhoa, c, Cl, Cd, aws, awa):
    """
    This function calculates the driving and heeling forces at each wingsail 
    section. The lift and drag forces are transformed with respect to the local wind angle
    
    Inputs:  
        rhoa, scalar, Density of air [kg/m-3]
        c, scalar, chord length [m]
        Cl, N array, Sectional lift coefficient [-]\
        Cd, N array, Sectional drag coefficient [-]
        aws, N array, Local apparent wind speed [m/s]
        awa, N array, Local apparent wind angle [rad]
    
    Outputs:
        dL, N array, Sectional lift force [N/m].
        dD, N array, Sectional drag force [N/m]
        dFD, N array, Sectional driving force [N/m]
        dFH, N array, Sectional heeling force [N/m]
        dFD_lift, dFD_drag, dFH_lift, dFH_drag: the lift and drag
        contributions [N/m] of the above arrays
    
    Note: these are 2D forces. Simpson's rule is used for FD and FH in main.py
    """
    dL = np.multiply(Cl, np.power(aws, 2)) * 0.5 * rhoa * c  # lift [N/m]
    dD = np.multiply(Cd, np.power(aws, 2)) * 0.5 * rhoa * c  # drag [N/m]

    dFD_lift = np.zeros_like(dL)  # the contribution of lift to driving force
    dFD_drag = np.zeros_like(dL)  # the contribution of drag
    dFD = np.zeros_like(dL)  # driving force [N/m]

    dFH_lift = np.zeros_like(dL)  # the contribution of lift to heeling force
    dFH_drag = np.zeros_like(dL)  # the contribution of drag
    dFH = np.zeros_like(dL)  # heeling force [N/m]
    for i in range(len(dL)):
        dFD_lift[i] = dL[i] * math.sin(awa[i])
        dFD_drag[i] = dD[i] * math.cos(awa[i])
        dFD[i] = dFD_lift[i] + dFD_drag[i]

        dFH_lift[i] = -dL[i] * math.cos(awa[i])
        dFH_drag[i] = dD[i] * math.sin(awa[i])
        dFH[i] = dFH_lift[i] + dFH_drag[i]

    return dL, dD, dFD_lift, dFD_drag, dFD, dFH_lift, dFH_drag, dFH

def flettner_forces(rhoa, d, Cl, Cd, Cp, aws, awa):
    """
    This function calculates the sectional driving and heeling force of a
    Fletner rotor. With the rotor spinning in the counter-clock direction (SR>0) and 
    awa in the range [0, pi], the lift is in the positive X-direction

    Inputs:
        rhoa, scalar, Density of air [kg/m-3]
        d, scalar, rotor diameter [m]
        Cl, N x 1 array, Sectional lift coefficient [-]
        Cd, N x 1 array, Sectional drag coefficient [-]
        Cp, N x 1 array, Sectional power coefficient [-]
        aws, N x 1 array, Local apparent wind speed [m/s]
        awa, N x 1 array, Local apparent wind angle [rad]
    
    Outputs:
        dL, N x 1 array, Sectional lift force [N/m]
        dD, N x 1 array, Sectional drag force [N/m]
        dP, N x 1 array, Sectional power coefficient [J/m]
        dFD, N x 1 array, Sectional driving force [N/m]
        dFH, N x 1 array, Sectional heeling force [N/m]
        dFD_lift, dFD_drag, dFH_lift, dFH_drag: the lift and drag 
        contributions [N/m] of the above arrays

    Note: these are 2D forces. Simpson's rule is used for FD and FH in main.py
    """
    dL = np.multiply(Cl, np.power(aws, 2)) * 0.5 * rhoa * d # lift [N/m]
    dD = np.multiply(Cd, np.power(aws, 2)) * 0.5 * rhoa * d # drag [N/m]
    dP = np.multiply(Cp, np.power(aws, 3)) * 0.5 * rhoa * d # power [W/m]

    dFD_lift = np.multiply(dL, np.sin(awa))  # the lift's contribution to driving force
    dFD_drag = np.multiply(dD, np.cos(awa))  # the drag's contribution to driving force
    dFD = dFD_lift + dFD_drag  # driving force [N/m]

    dFH_lift = -np.multiply(dL, np.cos(awa))
    dFH_drag = np.multiply(dD, np.sin(awa))
    dFH = dFH_lift + dFH_drag  # heeling force [N/m]
    
    # print(np.mean(aws),math.degrees(np.mean(awa)))
    # print(np.mean(dFD),np.mean(dFH))
    
    return dL, dD, dP, dFD_lift, dFD_drag, dFD, dFH_lift, dFH_drag, dFH

def apparentWind(Vws, h_mwl, twa, tws):
    """
    This function calculates the apparent wind speed and angle according to
    the velocity triangle.
    
    Input:
        Vws, scalar, Wind velocity due to ship velocity [m/s]
        h_mwl, N x 1 array, Height of sail sections above MWL [m]
        twa, col vector, Local true wind angle [rad]
        tws, col vector, Local true wind speed [m/s]
    
    Output:  
        aws, col vector, Unsteady apparent wind speed [m/s]
        awa, col vector, Unsteady apparent wind angle [rad]
    
    """
    aws = np.zeros_like(tws)
    awa = np.zeros_like(tws)
    for i in range(len(tws)):
        aws_Y = tws[i] * math.sin(twa[i])
        aws_X = -Vws + tws[i] * math.cos(twa[i])
        aws[i] = math.sqrt(aws_X ** 2 + aws_Y ** 2)
        awa[i] = np.arctan2(aws_Y, aws_X) # returns an angle in [-pi, +pi]
        if awa[i] < 0: # returns an angle in [0, 2*pi]
            awa[i] = 2*np.pi + awa[i]
    return aws, awa

def sailModel(waps):
    """ 
    Data on sail geometries
    
    Input:  
        waps, integer, Wingsail (1) or Flettner rotor (2)

    Output:
        H, scalar, Height of sail or Flettner rotor
        c, scalar, Chord length (if waps == 1) or diameter (if waps =2)
        asp, scalar, Sail aspect ratio [-]
        Ap, scalar, Projected sail area [m2]
        f, Scalar, Ship freeboard [m]
    """
    H = input('Height of Wingsail or Flettner rotor (default value: 35m): ')
    if H != '':
        H = float(H)
    else:
        H = float('35.0')
    
    c = input('Cord length or Flettner rotor diameter' 
             + '(default value: 10m for cord length; 5m for diameter): ')
    if c != '':
        c = float(c)
    else:
        if waps == 1:  # WINGSAIL. Dimensions, assuming rectangular shape
            c = float('10.0')
        else:          # FLETTNER ROTOR
            c = float('5.0')
    
    f = input('Ship freeboard above MWL (default value: 12.5m): ')
    if f != '':
        f = float(f)
    else:
        f = float('12.5')
    
    asp = H / c
    Ap = H * c

    return H, c, asp, Ap, f

def main(waps, Vs, AoA, incl_stall, ABL, H, c, asp, Ap, f, TWS10, TWA10, zg, xg):
    """ 
    This function is the main function of the calculation of Flettner rotor 
    and wingsail wind forces 
    
    Inputs:  
        waps, integer (1 or 2), Wingsail (1) or Flettner rotor (2)
        Vs, scalar, Ship velocity [kn]
        AoA, scalar, Angle of Attack [deg] or SR [-]
        incl_stall, boolean, Include or ignore sail stall
        ABL, boolean, Account for the atmospheric boundary layer in tws
        if True (1)
        H, scalar, Height of sail or Flettner rotor
        c, scalar, Chord length (if waps == 1) or diameter (if waps =2)
        asp, scalar, Sail aspect ratio [-]
        Ap, scalar, Projected sail area [m2]
        f, Scalar, Ship freeboard [m]
        TWS10, scalar, True wind speed at reference height 10 m [m / s]
        TWA10, scalar, True wind angle at reference height 10 m [0° - 360°]
        zg, scalar, Position of Center of gravity above MWL [m]
        xg, scalar, Position of wingsail or rotor vs COG [m]

    Outputs: 
        Flettner rotor and wingsail wind forces
    """
    rhoa = 1.21  # air density at 20 degC [kg/m3]
    Vs_mps = Vs*(1852 / 3600)  # convert ship speed from knots to m/s [m/s]
    if Vs_mps < 0:
        print("Ship velocity negative = {0:.2f} m/s".format(Vs_mps))
        sys.exit()
    # - - - - SAIL MODEL
    if waps == 2:
        d = c # rename chord to diameter

    # - - - - DISCRETISATION   
    N = 70 # number of wing sections z-direction
    sw = H / N # section width [m]
    h = np.arange(0.5 * sw, H, sw).reshape(-1, 1) # height of sail sections [m]
    h_mwl = h + f # Vertical position of wingsail sections above MWL [m].
    
    # - - - - WIND MODEL 
    TWA10 = TWA10 * np.pi / 180 # reference TWA, [rad] in range (0, 2pi)    
    twa = np.ones_like(h_mwl) * TWA10  # TWA constant in height
    if ABL == 'True':
        tws = windSpeedGrad(TWS10, h_mwl) # local true wind speed [m/s]
    else:
        tws = np.ones_like(h_mwl) * TWS10  # ignore ABL. TWS constant in height
    Vws = Vs_mps  # wind velocity due to ship velocity
    # Apparent wind from the wind velocity triangle:
    aws, awa = apparentWind(Vws, h_mwl, twa, tws)

    # - - - - FORCE MODEL   
    if waps == 1:
        AoA = np.deg2rad(AoA) # convert target AoA to radians [rad]
        Cl, Cd = wingsail_coeff(awa, asp, AoA, incl_stall)
        dL, dD, dFD_lift, dFD_drag, dFD, dFH_lift, dFH_drag, dFH = wingsail_forces(rhoa, c, Cl, Cd, aws, awa)
    else:
        PM, sr, Cl, Cd, Cp = flettner_coeff(d, aws, asp, AoA)
        dL, dD, dP, dFD_lift, dFD_drag, dFD, dFH_lift, dFH_drag, dFH = flettner_forces(rhoa, d, Cl, Cd, Cp, aws, awa)

    # Lift and drag contributions to aerodynamic roll moment
    dF4_lift = np.multiply(-dFH_lift, h_mwl-zg)
    dF4_drag = np.multiply(-dFH_drag, h_mwl-zg)

    # Aerodynamic roll and pitch moment, sectional [N/m*m]
    dF4 = np.multiply(-dFH, h_mwl-zg)									
					
    #Use Simpson's rule to integrate over the height. Forces [N] and moments [Nm].											
    if waps == 2:						
        P = simps(dP[:].reshape(1, -1), h.reshape(1, -1))						
    FD = simps(dFD[:].reshape(1, -1), h.reshape(1, -1))
    FH = simps(dFH[:].reshape(1, -1), h.reshape(1, -1))
    F4_lift = simps (dF4_lift [:].reshape(1, -1), h.reshape(1, -1))						
    F4_drag = simps (dF4_drag [:].reshape(1, -1), h.reshape(1, -1))						
    F4 = simps(dF4[:].reshape(1, -1), h.reshape(1, -1)) # Total roll moment [Nm]						
	# Yaw moment [Nm]    
    F6 = FH*xg
    															
#    print(FD,FH,F4_lift,F4_drag,F4,F6)

    return FD,FH,F4_lift,F4_drag,F4,F6						
			
						
						

    
