##  This ship motion program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  This program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with this program.
##  If not, see <https://www.gnu.org/licenses/>.

# This file is adapted from Python code found in:
# - Tranell, J. (2021), “Seakeeping capabilities of sailing cruise 
# and passenger vessels (Master’s thesis in Marine Technology)”, NTNU, Trondheim


"""
    This function is the main function of the calculation of Flettner rotor 
    and wingsail wind forces 
    
    Inputs:  
        waps, integer (1 or 2), Wingsail (1) or Flettner rotor (2)
        Vs, scalar, Ship velocity [kn]
        AoA, scalar, Angle of Attack [deg] or SR [-]
        incl_stall, boolean, Include or ignore sail stall
        ABL, boolean, Account for the atmospheric boundary layer in tws
        if True (1)
        H, scalar, Height of sail or Flettner rotor
        c, scalar, Chord length (if waps == 1) or diameter (if waps =2)
        f, Scalar, Ship freeboard [m]
        zg, scalar, Position of Center of gravity above MWL [m]
        xg, scalar, Position of wingsail or rotor vs COG [m]
        TWS10, scalar, True wind speed at reference height 10 m [m / s]
        TWA10, scalar, True wind angle at reference height 10 m [0° - 360°]        

    Outputs:
        Flettner rotor and wingsail wind forces
"""
from Flettner_Wingsail_Forces import main, sailModel
import numpy as np
import matplotlib.pyplot as plt

waps = input('Wingsail (1) or Flettner rotor (2) (default value: 1): ')
if waps != '':
    waps = int(waps)
else:
    waps = int('1')
    
Vs = input('Ship velocity [knots] (default value: 0 kn): ')
if Vs != '':
    Vs = float(Vs)
else:
    Vs = float('0')

print('\nNote: There is a positive lift force (in the positive X-direction)' 
      +' contributing to positive driving force for wind angles between 0° and 180°,'
      +' at the following conditions:\n'
      +'- The Angle of Attack of wingsail is positive,\n'
      +'- The spin ratio (SR) of the Flettner rotor is positive, this means that'
      +'  the Flettner rotor spins in the anticlockwise direction\n'
      +'For a positive lift force for wind angles between 180° and 360°, the Angle of Attack'
      +' or the spin ratio are to be negative\n')

AoA = input('Angle of Attack [deg] or SR [-] (default value: 10 or 6 for SR): ')
if AoA != '':
    AoA = float(AoA)
else:
    if waps == 1:
        AoA = float('10')
    else:
        AoA = float('6')

print('\nNote: If Stall is included for the wingsail, it will occur for' 
      +' an Angle of Attack (positive or negative) greater than 20 degrees.'
      +' There is no Stall occuring for the Flettner rotor\n')

incl_stall = input('Include (if True) or ignore wingsail stall (default value: False): ')
if incl_stall != '':
    incl_stall = str(incl_stall)
else:
    incl_stall = str(False)

ABL = input('Account for the atmospheric boundary layer in tws' 
            +' (default value: False): ')
if ABL != '':
    ABL = str(ABL)
else:
    ABL = str(False)

H, c, asp, Ap, f = sailModel(waps)

if asp != 6 and waps == 2:
    print('\nNote: Flettner AR is not 6. Empirical formulae for force' 
          + ' coefficients might not be valid \n')

zg = input('Position of Center of gravity above MWL (default value: 6m): ')
if zg != '':
    zg = float(zg)
else:
    zg = float('6')

xg = input('Position of wingsail or rotor vs COG (default value: 30 m): ')
if xg != '':
    xg = float(xg)
else:
    xg = float('30')

TWS10 = input('True wind speed [m/s] at reference height 10 m'
              +' (default value: 10m/s): ')
if TWS10 != '':
    TWS10 = float(TWS10)
else:
    TWS10 = float('10.0')
TWA10 = input('True wind angle [deg] at reference height 10 m'
              +' (default value: 30°): ')
if TWA10 != '':
    TWA10 = float(TWA10)
else:
    TWA10 = float('30.0')    

FD,FH,F4_lift,F4_drag,F4,F6 = main(waps,Vs,AoA,incl_stall,ABL,H, c, asp, Ap, f,\
                                   TWS10,TWA10,zg,xg)
print("Driving force FD: {0:.2f} N, for true wind angle: {1:.2f} deg"\
      .format(float(FD), TWA10))
print("Side force FH: {0:.2f} N, for true wind angle: {1:.2f} deg"\
              .format(float(FH), TWA10))
print("Roll moment F4: {0:.2f} Nm, for true wind angle: {1:.2f} deg"\
              .format(float(F4), TWA10))
print("Yaw moment F6: {0:.2f} Nm, for true wind angle: {1:.2f} deg"\
              .format(float(F6), TWA10))

t = np.arange(0., 190., 10.)

FDa = np.zeros_like(t)
FHa = np.zeros_like(t)
F4a = np.zeros_like(t)
F6a = np.zeros_like(t)
for i in range(len(t)):
    FD,FH,F4_lift,F4_drag,F4,F6 = main(waps,Vs,AoA,incl_stall,ABL,H, c, asp, Ap,\
                                       f,TWS10,t[i],zg,xg)
    FDa[i] = FD
    FHa[i] = FH
    F4a[i] = F4
    F6a[i] = F6
#print(FDa,FHa)

Ecrit = np.zeros(8).astype(str)
Ecrit = ["Wingsail driving forces","Wingsail side forces",\
         "Flettner rotor driving forces","Flettner rotor side forces",\
         "Wingsail roll motion","Wingsail yaw motion",\
         "Flettner rotor roll motion","Flettner rotor yaw motion"]

try:
    plt.interactive(True)
    plt.figure()
    plt.xlim(0,t[-1])
    if waps== 1: plt.plot(t,FDa,'b--',label=Ecrit[0])
    if waps== 2: plt.plot(t,FDa,'b--',label=Ecrit[2])
    if waps== 1: plt.plot(t,FHa,'r--',label=Ecrit[1])
    if waps== 2: plt.plot(t,FHa,'r--',label=Ecrit[3])
    plt.title('Forces')
    plt.xlabel('True wind angle (deg.)')
    plt.ylabel('Forces (N)')
    plt.grid(True)
    plt.legend()
    plt.savefig("Forces.jpeg")
except:
    pass

try:
    plt.interactive(True)
    plt.figure()
    plt.xlim(0,t[-1])
    if waps== 1: plt.plot(t,F4a,'b--',label=Ecrit[4])
    if waps== 2: plt.plot(t,F4a,'b--',label=Ecrit[6])
    if waps== 1: plt.plot(t,F6a,'r--',label=Ecrit[5])
    if waps== 2: plt.plot(t,F6a,'r--',label=Ecrit[7])
    plt.title('Moments')
    plt.xlabel('True wind angle (deg.)')
    plt.ylabel('Moments (Nm)')
    plt.grid(True)
    plt.legend()
    plt.savefig("Moments.jpeg")
except:
    pass
