##  This file is part of SIMBAD pre-processing program.

##  SIMBAD pre-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD pre-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD pre-processing program.
##  If not, see <https://www.gnu.org/licenses/>.


# Import modules
import numpy as np
import matplotlib.pyplot as plt
import scipy as sp
import scipy.fft
import scipy.signal
from fourier import PSD_continuous

# Plot the wind velocity time series for verification.
# Set interactive
def Plot_WS(eta_t,eta):
    try:
        plt.interactive(True)
        plt.figure()
        plt.xlim(0,eta_t[-1])
        plt.plot(eta_t, eta,'r--')
        plt.grid(True)
        plt.title('Wind Velocity Time Series')
        plt.xlabel('Time (s)')
        plt.ylabel('Wind velocity (m/s)')
    except:
        pass

# Plot the Wave density spectrum for verification.
# Set interactive
def Plot_specSS(repons,freqs,specSS):
    Ecrit = np.zeros(6).astype(np.str)
    Ecrit = ['Davenport spectrum','Harris spectrum','Kaimal spectrum'
             ,'API spectrum','NPD spectrum','Ochi-Shin spectrum']
    try:
        plt.interactive(True)
        plt.figure()
        plt.xlim(0,0.5)
        if repons=='1': plt.plot(freqs, specSS, 'r--',label=Ecrit[0])
        if repons=='2': plt.plot(freqs, specSS, 'r--',label=Ecrit[1])
        if repons=='3': plt.plot(freqs, specSS, 'r--',label=Ecrit[2])
        if repons=='4': plt.plot(freqs, specSS, 'r--',label=Ecrit[3])
        if repons=='5': plt.plot(freqs, specSS, 'r--',label=Ecrit[4])
        if repons=='6': plt.plot(freqs, specSS, 'r--',label=Ecrit[5])
        plt.xlabel('Frequency (rad/s)')
        plt.ylabel('PSD (m2/s2/Hz)')
        plt.grid(True)
        plt.legend()
    except:
        pass

