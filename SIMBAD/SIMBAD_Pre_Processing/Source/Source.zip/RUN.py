##  This file is part of SIMBAD pre-processing program.

##  SIMBAD pre-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD pre-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD pre-processing program.
##  If not, see <https://www.gnu.org/licenses/>.


# Import modules
import numpy as np
import sys
from pdstrip import read
from output import write_hdf5
import matplotlib.pyplot as plt
import smooth as smh
from wave_excitation import wave_excitation
from wind_ts import wind_ts
import interpol as inpl

# Load PDSTRIP output data file
try:
    f = open('pdstrip.out')
    pdstrip_data = read(hydro_file='pdstrip.out')
except IOError:
    print("File pdstrip.out not accessible")
    input("Press the ENTER key to continue...")
    sys.exit()

# Reading of wave parameters for irregular waves
repons = input('Do you need to change the irregular wave parameters?: Yes or No (default: No)\n')
if repons !='':
    repons = str(repons)
else:
    repons = 'No'
if repons == 'No':
    with open('FreqDir.txt','r') as fid:
        raw = fid.readlines()
    temp = raw[0].split()
    reponsRadDamp = int(temp[0])
    iFreq_Fit = int(temp[1])
    temp = raw[1].split()
    Period = float(temp[0])
    Dir_Houl = float(temp[1])
    Ampl = float(temp[2])
else:
    print('The program is to be rerun!!\n')
    sys.exit()

Freq_Houl = 2*np.pi/Period
frequencies = pdstrip_data.body[0].w
num_frequencies = len(pdstrip_data.body[0].w)
iFreq = 0
Freq_inpl = False
while Freq_Houl != frequencies[iFreq]:
    if iFreq < (num_frequencies-1):
        iFreq +=1
        Freq_inpl = False
    else:
        print('Interpolation of coefficients in frequency')
        Freq_inpl = True
        break

wave_directions = pdstrip_data.body[0].wave_dir
num_wave_directions = len(pdstrip_data.body[0].wave_dir)
iDir = 0
Dir_inpl = False
while Dir_Houl != wave_directions[iDir]:
    if iDir < (num_wave_directions-1):
        iDir +=1
        Dir_inpl = False
    else:    
        print('Interpolation of coefficients in direction')
        Dir_inpl = True
        break

# Calculate IRF of excitation forces
pdstrip_data.body[0].calc_irf_excitation()

# Interpolation of excitation forces IRF

if Dir_inpl is True:
    exf_irf_inpl = inpl.interpolate_ad_rd(wave_directions,Dir_Houl,pdstrip_data.body[0].ex.irf.f)
else:
    exf_irf_inpl = inpl.interpolate_ad_rd(wave_directions,wave_directions[iDir],pdstrip_data.body[0].ex.irf.f)

# Calculate IRF of drift forces
# Choice of different types of calculation
reponsDrift = input('1: No wave drift forces,\n'
                   +'2: Mean wave drift forces,\n'
                   +'3: Calculation with Molin formulation,\n'
                   +'Default: 2\n')
if reponsDrift !='':
    reponsDrift = str(reponsDrift)
else:
    reponsDrift = '2'

pdstrip_data.body[0].calc_irf_drift(reponsDrift)

# Interpolation of drift forces IRF

if Dir_inpl is True:
    dr1f_irf_inpl = inpl.interpolate_ad_rd(wave_directions,Dir_Houl,pdstrip_data.body[0].ex.irf.dr1)
    dr2f_irf_inpl = inpl.interpolate_ad_rd(wave_directions,Dir_Houl,pdstrip_data.body[0].ex.irf.dr2)
    dr11f_irf_inpl = inpl.interpolate_ad_rd(wave_directions,Dir_Houl,pdstrip_data.body[0].ex.irf.dr11)
    dr22f_irf_inpl = inpl.interpolate_ad_rd(wave_directions,Dir_Houl,pdstrip_data.body[0].ex.irf.dr22)    
else:
    dr1f_irf_inpl = inpl.interpolate_ad_rd(wave_directions,wave_directions[iDir],pdstrip_data.body[0].ex.irf.dr1)
    dr2f_irf_inpl = inpl.interpolate_ad_rd(wave_directions,wave_directions[iDir],pdstrip_data.body[0].ex.irf.dr2)
    dr11f_irf_inpl = inpl.interpolate_ad_rd(wave_directions,wave_directions[iDir],pdstrip_data.body[0].ex.irf.dr11)
    dr22f_irf_inpl = inpl.interpolate_ad_rd(wave_directions,wave_directions[iDir],pdstrip_data.body[0].ex.irf.dr22)

# Plots of wave excitation IRF
repons = input('Do you want plots of Wave excitation IRF?: Yes or No (default: No)\n')
if repons !='':
    repons = str(repons)
else:
    repons = 'No'

if repons == 'Yes':
# Plots of excitation force IRF for the chosen direction
    Ecrit = np.zeros(6).astype(np.str)
    Ecrit = ['Surge','Sway','Heave', 'Roll','Pitch','Yaw']
    for i in range(6):
        try:      
            plt.interactive(True)
            plt.figure()
            plt.plot(pdstrip_data.body[0].ex.irf.t,exf_irf_inpl[i,:],'r-',label=Ecrit[i])
            plt.xlabel('Time (s)')
            if i<3: plt.ylabel('Excitation force IRF(N/m/s)')
            if i>=3: plt.ylabel('Excitation force IRF(N.m/m/s)')
            plt.grid(True)
            plt.legend()
            plt.title('Wave excitation force IRF for direction: {}'.format(Dir_Houl))
        except:
            pass

# Plots of drift force IRF
repons = input('Do you want plots of drift force IRF?: Yes or No (default: No)\n')
if repons !='':
    repons = str(repons)
else:
    repons = 'No'

if repons == 'Yes':

# Plots of drift force IRF for the chosen direction
    Ecrit = np.zeros(6).astype(np.str)
    Ecrit = ['Surge','Sway','Heave', 'Roll','Pitch','Yaw']
    for i in range(6):
        try:      
            plt.interactive(True)
            plt.figure()
            plt.plot(pdstrip_data.body[0].ex.irf.drt,dr1f_irf_inpl[i,:],'r',label=Ecrit[i]+' Drift Cos. part')
            plt.plot(pdstrip_data.body[0].ex.irf.drt,dr11f_irf_inpl[i,:],'r--',label=Ecrit[i]+' Cos. part with Fd sign')
            if reponsDrift == '3':
                plt.plot(pdstrip_data.body[0].ex.irf.drt,dr2f_irf_inpl[i,:],'b',label=Ecrit[i]+' Drift Sin. part')
                plt.plot(pdstrip_data.body[0].ex.irf.drt,dr22f_irf_inpl[i,:],'b--',label=Ecrit[i]+' Sin. part with Fd sign')                
            plt.xlabel('Time (s)')
            if i<3: plt.ylabel('Drift force IRF(sqrt(N/m2)/s)')
            if i>=3: plt.ylabel('Drift force IRF(sqrt(N.m/m2)/s)')
            plt.grid(True)
            plt.legend()
            plt.title('Wave drift force IRF for direction: {}'.format(Dir_Houl))
        except:
            pass

# Calculate IRF for radiation damping coefficients
# Plots of all radiation damping IRF i, j
t_end = input('Calculation range for the radiation damping IRF (default value: 95s): ')
if t_end != '':
    t_end = np.float(t_end)
else:
    t_end = np.float('95.0')
#n_t = 1 + t_end/0.1
n_t = 1 + t_end/0.2
n_t = int(n_t)
#n_w = n_t #n_w est fixé à 1001 par défaut
pdstrip_data.body[0].calc_irf_radiation(reponsRadDamp, iFreq_Fit, t_end, n_t)
repons = input('Do you want plots of Radiation damping IRF?: Yes or No (default: No)\n')
if repons !='':
    repons = str(repons)
else:
    repons = 'No'

if repons == 'Yes':
    for i in range(6):
        for j in range(6):
            if all(0 == a for a in pdstrip_data.body[0].rd.irf.K[i,j,:]) is False:
                try:      
                    plt.interactive(True)
                    plt.figure() 
                    plt.plot(pdstrip_data.body[0].rd.irf.t,pdstrip_data.body[0].rd.irf.K[i,j,:],'r-',
                             label='Radiation damping {} {}'.format(i+1,j+1))
                    #plt.xlim(0,pdstrip_data.body[0].rd.irf.t[-1])
                    plt.grid(True)
                    plt.xlabel('Time (s)')
                    if i<3 and j<3: plt.ylabel('Radiation damping IRF (kg/s2)')
                    if i<3 and j>=3: plt.ylabel('Radiation damping IRF (kg.m/s2)')
                    if i>=3 and j<3: plt.ylabel('Radiation damping IRF (kg.m/s2)')
                    if i>=3 and j>=3: plt.ylabel('Radiation damping IRF (kg.m2/s2)')
                    plt.legend()
                    plt.title('Radiation damping IRF')
                except:
                    pass
# Writing of non-zero radiation damping IRF in a txt file
with open('rad_IRF.txt','w') as f:
    ndt = len(pdstrip_data.body[0].rd.irf.t)
    #print(ndt)
    np.savetxt(f,[ndt],fmt='%.1i')
    irow = 0
    for i in range(6):
        for j in range(6):
            if all(0 == a for a in pdstrip_data.body[0].rd.irf.K[i,j,:]) is False:
                irow += 1
    np.savetxt(f,[irow],fmt='%.1i')
    for i in range(6):
        for j in range(6):
            if all(0 == a for a in pdstrip_data.body[0].rd.irf.K[i,j,:]) is False:
                tmp = np.array([i,j])
                np.savetxt(f,[tmp],fmt='%.1i')
                for irow in range(ndt):
                    tmpa = pdstrip_data.body[0].rd.irf.t[irow]
                    tmpb = pdstrip_data.body[0].rd.irf.K[i,j,irow]
                    np.savetxt(f,[(tmpa,tmpb)],fmt='%.6e')

# Calculate infinite added masses

pdstrip_data.body[0].calc_inf_addedmass(pdstrip_data.body[0].rd.irf.t, pdstrip_data.body[0].rd.irf.K, w_max = pdstrip_data.body[0].w[iFreq_Fit])
#print(pdstrip_data.body[0].am.totinf)

# Calculate state space coefficients
# pdstrip_data.body[0].calc_ss_radiation(max_order=3, r2_thresh=0.5 )

# Write hydrodynamic data to HDF5 file format
write_hdf5(pdstrip_data)

#Calculation of wave time series and wave excitation forces
wave_excitation(Period,Dir_Houl,Ampl,exf_irf_inpl,dr1f_irf_inpl,dr2f_irf_inpl,dr11f_irf_inpl,dr22f_irf_inpl,reponsDrift)

#Calculation of wind velocity time series
wind_ts()
#
input("Press the ENTER key to continue...")
