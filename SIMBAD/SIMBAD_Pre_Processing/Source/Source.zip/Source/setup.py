from cx_Freeze import setup, Executable
base = None
#Remplacer "monprogramme.py" par le nom du script qui lance votre programme
executables = [Executable("RUN.py", base=base)]
#Renseignez ici la liste complète des packages utilisés par votre application
packages = ["idna",
            "amoroul.py",
            "fourier.py",
            "bem.py",
            "excitation_convol.py",
            "interpol.py",
            "models.py",
            "output.py",
            "pdstrip.py",
            "plot_WSS.py",
            "raddamp_fit.py",
            "smooth.py",
            "wave_excitation.py",
            "waveFunctions.py"
            ]
options = {
    'build_exe': {    
        'packages':packages,
    },
}
#Adaptez les valeurs des variables "name", "version", "description" à votre programme.
setup(
    name = "Inputs_SIMBAD",
    options = options,
    version = "0.1",
    author = "RP-PFD",
    description = 'Inputs from PDSTRIP',
    executables = executables
)
