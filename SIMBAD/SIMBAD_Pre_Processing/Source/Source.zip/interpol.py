##  This file is part of SIMBAD pre-processing program.

##  SIMBAD pre-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD pre-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD pre-processing program.
##  If not, see <https://www.gnu.org/licenses/>.

import numpy as np
from scipy import interpolate


def interpolate_ad_rd(w_orig, w_interp, mat_in):
  '''
  Interpolate matrices of the added mass and radiation coefficients

    w_orig : table of frequency values

    w_interp : interpolation frequency

    mat_in : added mass or radiation damping matrices

    mat_interp : interpolated matrix
  
  '''
  mat_interp = np.zeros([mat_in.shape[1], mat_in.shape[2]])

  flip = False

# Inversion de l'ordre des valeurs dans le tableau des fréquences avec fonction flipud
  if w_orig[0] > w_orig[1]:

    w_tmp = np.flipud(w_orig)
    flip = True

  else:

    w_tmp = w_orig

# Interpolation des valeurs de masse ajoutée ou d'amortissement en fonction 
# de la valeur de fréquence demandée (w_interp)
# L'indice i représente le nombre de degrés de libertés(6)
# L'indice j représente le nombre de degrés de liberté (6)

  for i in range(mat_in.shape[1]):

    for j in range(mat_in.shape[2]):

# Inversion éventuelle de l'ordre des valeurs 
      if flip is True:
          
          rdTmp = np.flipud(mat_in[:, i, j])

      else:

          rdTmp = mat_in[:, i, j]

      f = interpolate.interp1d(x=w_tmp, y=rdTmp)
      mat_interp[i, j] = f(w_interp)

  return mat_interp


def interpolate_exf(w_orig, w_interp, mat_in):
  '''
  Interpolate matrices of the excitation and drift forces in direction,

    w_orig : table of direction values

    w_interp : interpolation direction

    mat_in : excitation or drift forces matrices

    mat_interp : interpolated matrix for one direction
  
  '''
  mat_interp = np.zeros([mat_in.shape[2],mat_in.shape[0]])

  flip = False

# Inversion de l'ordre des valeurs dans le tableau des directions avec fonction flipud
  if w_orig[0] > w_orig[1]:

    w_tmp = np.flipud(w_orig)
    flip = True

  else:

    w_tmp = w_orig

# Interpolation des valeurs d'efforts en fonction 
# de la valeur de direction demandée (w_interp)
# L'indice i représente le nombre de degrés de libertés(6)
# L'indice j représente le nombre de fréquences

  for i in range(mat_in.shape[2]):
    for j in range(mat_in.shape[0]):

# Inversion éventuelle de l'ordre des valeurs 
      if flip is True:
          
          rdTmp = np.flipud(mat_in[j, :, i])

      else:

          rdTmp = mat_in[j, :, i]

      f = interpolate.interp1d(x=w_tmp, y=rdTmp)
      mat_interp[i, j] = f(w_interp)

  return mat_interp
