##  This file is part of SIMBAD pre-processing program.

##  SIMBAD pre-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD pre-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD pre-processing program.
##  If not, see <https://www.gnu.org/licenses/>.


# Import modules
import numpy as np
import math as mt
import sys
import scipy.fft


#---------------------------------------------------------------------------
# SPECTRAL VALUES
#---------------------------------------------------------------------------

def spectralValue(Hs,fp,freqs,iFreq):
    # Determine necessary parameters    
    gamma = 3.3
    alpha = 0.0624/(0.230 + 0.0336*gamma - (0.185/(1.9+gamma))) 
    freq_n = len(freqs)
    beta = np.zeros(freq_n)
    specSS = np.zeros(freq_n)
    # Calculate spectrum
    for iS in range(0,freq_n):
        if freqs[iS] < fp:
            sigma = 0.07
        else:
            sigma = 0.09
        beta[iS] = np.exp(-(freqs[iS]-fp)**2/(2*sigma**2*fp**2))
        specSS[iS] = alpha*Hs**2*fp**4*freqs[iS]**(-5)*gamma**beta[iS]*np.exp(-5/4.0*(fp/freqs[iS])**4)
    # Zero-out the wave spectrum above the cut-off frequency.
    # We must cut-off the frequency in order to avoid nonphysical values
    # Two ways to cut-off frequency: Omega > 3*Omegap or S(Omega) > S(Omegap)/100
##        if freqs[iS] > 3*fp: specSS[iS] = 0.0
##
    for iS in range(0,freq_n):
        if specSS[iS] < (specSS[iFreq]/100): specSS[iS] = 0.0

    # Return values
    return specSS
    
def makeWavex(t,f,S,phase):
    # Make new frequencies and spectrum, with interpolated values
    deltaf = 2*np.pi/t[-1] # Frequency step
    nf = int(mt.ceil(f[-1]/deltaf))
    f_new = np.linspace(f[0],f[-1],nf)
    S = np.interp(f_new,f,S)
    
    # Pre allocation
    zta = np.sqrt(2*S*deltaf)
    wave = np.zeros((len(t),len(f_new)))
    wave1 = np.zeros((len(t),len(f_new)))
    phase = list(reversed(phase)) 

    # Loop over all frequencies
    for iF in range(0,len(f_new)):
        wave[:,iF] = zta[iF]*np.cos(f_new[iF]*t + phase[iF])
        wave1[:,iF] = zta[iF]*np.sin(f_new[iF]*t + phase[iF])
    # Sum over all frequencies
    tot_wave = np.sum(wave,axis=1)
    tot_wave1 = np.sum(wave1,axis=1)
    
    return tot_wave, tot_wave1

##def makeDrFo(t,f,S,phase,qtf):
##    # Make new frequencies, spectrum and qtf, with interpolated values
##    deltaf = 2*np.pi/t[-1] # Frequency step
##    nf = int(mt.ceil(f[-1]/deltaf))
##    f_new = np.linspace(f[0],f[-1],nf)
##    qtf_new = np.interp(f_new,f,qtf)
##    S = np.interp(f_new,f,S)
##    
##    # Pre allocation
##    zta = np.sqrt(2*S*deltaf)
##    FD1 = np.zeros((len(t),len(f_new)))
##    FD11 = np.zeros((len(t),len(f_new)))
##    FD2 = np.zeros((len(t),len(f_new)))
##    FD22 = np.zeros((len(t),len(f_new)))
##    phase = list(reversed(phase)) 
##    print('coucou')
##    # Loop over all frequencies
##    for iF in range(0,len(f_new)):
##        FD1[:,iF] = zta[iF]*np.sqrt(np.abs(qtf_new[iF]))*np.cos(f_new[iF]*t + phase[iF])
##        FD11[:,iF] = FD1[:,iF]*np.sign(qtf_new[iF])
##        FD2[:,iF] = zta[iF]*np.sqrt(np.abs(qtf_new[iF]))*np.sin(f_new[iF]*t + phase[iF])
##        FD22[:,iF] = FD2[:,iF]*np.sign(qtf_new[iF])
##        
##    # Sum over all frequencies
##    tot_FD = np.sum(FD1,axis=1)*np.sum(FD11,axis=1)+np.sum(FD2,axis=1)*np.sum(FD22,axis=1)
##    
##    return tot_FD

def makeWavexReg(t,Hs,fp,f,S):
    # Make new frequencies and spectrum, with interpolated values
    S = np.interp(fp,f,S)
    wave = Hs/2.0*np.cos(fp*t)
    return wave

    
def makePhase(t,f):
    # Frequency step
    deltaf = 2*np.pi/t[-1]
    # With the seed reset (every time), the same set of numbers will appear every time
    # Otherwise do not use seed or with no argument seed()
    np.random.seed()
    nf = int(mt.ceil(f[-1]/deltaf))
    phaseVector = np.zeros(nf).astype(np.float)
    phaseVector = 2*np.pi*np.random.random(nf)

##    nPhase = np.random.randint(1,100)
##    print(nPhase)
##    pathFile = './phaseVectors.dat' 
##    with open(pathFile,'r') as f:
##        phaseRaw = f.readlines()
##    
##    phaseOK = phaseRaw[nPhase]
##    phaseOK = phaseOK.split()
##    phaseVector = [float(iP) for iP in phaseOK]
##    print(phaseVector)
    
    return phaseVector

def makeWave_Fast(dt,num_dt,t,f,S):

    '''Function to calculate a Gaussian-distributed wave elevation with
    a uniformly distributed random phase and also a normally distributed
    amplitude
    For more information please see §2.4.2 in:

            Dynamics Modeling and Loads Analysis of an Offshore Floating Wind
            Turbine, J. M Jonkman, 2007, NREL/TP-500-41958'''
    
    # Number of frequency components for the FFT
    num_dt2 = int(num_dt/2)
    num_dt2 = num_dt2+1
    # Make new frequencies and spectrum, with interpolated values
    deltaf = 2*np.pi/t[-1] # Frequency step
    nf = int(mt.ceil(f[-1]/deltaf))
    f_new = np.linspace(f[0],f[-1],nf)
    S = np.interp(f_new,f,S)
    S1Sd = np.zeros(num_dt2).astype(float)
    if num_dt2 > nf:
        for iS in range(nf): S1Sd[iS] = S[iS]
    else:
        print('Number of frequency components for FFT less than available frequencies')
        sys.exit()

    #Calculate the factors needed by the discrete time inverse Fourier
    #transform in the calculations of the White Gaussian Noise (WGN) and
    #the two-sided power spectral density of the wave spectrum per unit time:

    WGNC_F = np.sqrt(np.pi/(deltaf*dt) )   # This factor is needed by the discrete time inverse Fourier transform to ensure that the time series WGN process has unit variance
    S2Sd_F = 1.0/dt                        # This factor is also needed by the discrete time inverse Fourier transform

    
    # Compute the two-sided power spectral density of the wave spectrum per unit time:

    S2Sd  = 0.5*S1Sd

    # Compute the Fourier transform of the realization of a White Gaussian Noise
    # (WGN) time series process with unit variance:
    # NOTE: For the time series process to be real with zero mean, the values at
    # Omega == 0.0 and Omega == num_dt2*deltaf must be zero.

    WGNC = np.zeros(num_dt2).astype(complex)
    for iS in range (1,num_dt2-1):
        WGNC[iS] = BoxMuller()

    # Compute the Fourier transform of the instantaneous elevation of incident waves:

    WaveElevC0 = np.zeros(num_dt2).astype(complex)
    for iS in range (num_dt2):
        WaveElevC0[iS] = (WGNC_F*WGNC[iS])*np.sqrt(2*np.pi*(S2Sd_F*S2Sd[iS]))

    # Compute the inverse Fourier transform to find the time-domain
    # representation of the wave elevation:
    
    WaveElev0 = np.zeros(num_dt).astype(float)
    WaveElev0 = scipy.fft.irfft(WaveElevC0)
    
    return WaveElev0

def BoxMuller():

    ##This FUNCTION uses the Box-Muller method to turn two uniformly
    ##distributed randoms into two unit normal randoms, which are
    ##returned as real and imaginary components.

    ##Compute the two uniformly distributed randoms:
    ##NOTE: The first random, U1, cannot be zero else the LOG() function
    ##below will blow up; there is no restriction on the value of the
    ##second random, U2.    

    U1 = 0.0
    np.random.seed()
    while U1 == 0.0:
        U1 = np.random.random()

    np.random.seed()
    U2 = np.random.random()
    
    # Compute intermediate variables:

    C1 = np.sqrt(-2.0*mt.log(U1))
    C2 = 2*np.pi*U2
    
    #Compute the unit normal randoms:

    BoxMuller = complex( C1*np.cos(C2), C1*np.sin(C2) )

    return BoxMuller

   
def calcRAO(Fe,M,Ma,B,c,w):
    rao = np.absolute(Fe/(-w**2*(M+Ma) + 1j*w*(B) + c))
    return rao
