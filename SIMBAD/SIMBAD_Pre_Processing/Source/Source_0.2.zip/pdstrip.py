# This file is an adaptation of one file of the Bemio software
# (see https://wec-sim.github.io/bemio/)

# Copyright 2014 the National Renewable Energy Laboratory and Sandia Corporation

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at

#     http://www.apache.org/licenses/LICENSE-2.0

# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

import numpy as np
import bem
import sys
from math import ceil

import matplotlib.pyplot as plt
import smooth as smh
import raddamp_fit as rdft
import interpol as inpl

from amoroul import RolDamp as RD

class PdstripOutput(object):
    '''
    Class to read and interact with PDSTRIP simulation data

    Parameters:
        hydro_file : str
            Name of the PDSTRIP.OUT output file
        scale : bool, optional
            Boolean value to determine if the hydrodynamic data is scaled.
            See the bemio.data_structures.bem.scale function for more
            information

    Examples:
        The following example assumes there are PDSTRIP output files named pdstrip.out

        >>> pdstrip_data = read(hydro_file=pdstrip.out)

    '''
    def __init__(self, hydro_file, scale=False):

        print('\nReading the PDSTRIP results in the ' + hydro_file + ' file')

        self.files = bem.generate_file_names(hydro_file) # Génére les chemins d'accès et différents noms de fichier
        self.scaled_at_read = scale 
        self.scaled = False # Pour éviter de prendre des valeurs adimensionnelles
        self.body = {} # Génére un dictionnaire sur le nombre de corps hydrodynamiques

        self._read()

    def _read(self):
        code = 'PDSTRIP'

        with open(self.files['out'],'r') as fid:  # Ouverture du fichier hydro en lecture avec pour nom de fichier 'fid'
            raw = fid.readlines() # Renvoie une liste ordonnée de toutes les lignes du fichier
        print('\nReading the PDSTRIP results in the ' + self.files['out'] + ' file,\n')

# Nombre de corps flottants bloqué à 1
        num_bodies = int(1)
        
# Enumerate: renvoie un itérateur i devant chaque ligne du fichier 'raw' (donc le fichier hydro)
        for i, line in enumerate(raw, start=0):

## Passage de la densité de t/m3 en kg/m3
            if 'Water density' in line:
                density = raw[i].split()[-1]
                density = np.float(density)
                if density < 10:
                    density = 1000*density
                #print(density)
## Lecture de la profondeur d'eau
            if 'z of still waterline' in line:
                draft = raw[i].split()[-1]
                draft = np.float(draft)
            if 'z of water bottom' in line:
                water_depth = raw[i].split()[-1]                
                water_depth = np.float(water_depth)
                water_depth = -water_depth+draft
                #print (water_depth)
## Directions de la houle
            if 'Number of wave angles' in line:
                num_wave_directions = raw[i].split()[-1]
                num_wave_directions = int(num_wave_directions)
                num_lines_wave_directions = int(ceil(num_wave_directions/10.))
                #print(num_wave_directions,num_lines_wave_directions)

            if 'Wave encounter angles' in line:
                if num_wave_directions == 1: wave_directions = np.array(raw[i].split()[-1]).astype(np.float) 
                if num_wave_directions>1:
                    for j in range(num_lines_wave_directions):
                        if j == 0:
                            wave_directions = np.array(raw[i].split()[3]).astype(np.float)
                            indic = 3+num_wave_directions
                            if (indic>13): indic=13
                            for k in range(4,indic):
                               tmp = np.float(raw[i].split()[k])
                               wave_directions = np.append(wave_directions,tmp)
                        else:
                            tmp = np.array(raw[i+j].split()).astype(np.float)
                            wave_directions = np.append(wave_directions,tmp)
                #print(wave_directions)
# Test de vérification des directions qui doivent se trouver entre +90° et -90°
                temp = wave_directions[0]
                if temp!= 90.:
                    print('First wave direction not equal to +90°')
                    sys.exit()
                temp = wave_directions[-1]
                if temp!= -90.:
                    print('Last wave direction not equal to -90°')
                    sys.exit()
# Ajout des valeurs à +180° et changement des valeurs négatives en positives
                for j in range(num_wave_directions):
                    tmp = wave_directions[j]+180.0
                    wave_directions = np.append(wave_directions,tmp)
                    if wave_directions[j]<0: wave_directions[j] = wave_directions[j]+360.0                
# Elimination des valeurs identiques de la liste
                wave_directions = list(set(wave_directions))
# Classement par ordre croissant
                wave_directions = np.array(sorted(wave_directions)).astype(np.float)
                num_wave_directions = len(wave_directions)
                #print(wave_directions)
                #print(num_wave_directions)
## Caractéristiques du navire: LOA, tirant d'eau, masse, rayons d'inertie,
## COG (xg,0,Og) par rapport à la première section arrière (A bien vérifier dans le fichier initial!)
## et au plan d'eau (Og)

            if 'Reference draft' in line:
                draft = raw[i].split()[-1]
                draft = np.float(draft)
                #print(draft)

            if 'Number of sections' in line:
                num_sections = raw[i].split()[-1]
                num_sections = int(num_sections)
                #print(num_sections)

            if 'Section no.' in line:
##                print(raw[i].split())
                isec = int(raw[i].split()[2])
                if isec == 1:
                    lmoins = raw[i].split()[-1]
                    lmoins = float(lmoins)
##                    print(lmoins)
                if isec == num_sections:
                    lplus = raw[i].split()[-1]
                    lplus = float(lplus)
                    LOA = lplus-lmoins
                    Lpp = LOA
                   #print(LOA)

            if 'Inter-' in line:
                # Masse
                Mass = raw[i+2].split()[1]
                Mass = np.float(Mass)
                #print(Mass)
                # xg, yg, zg
                xb = raw[i+2].split()[2]
                xb = np.float(xb)-lmoins
                xg = xb
                yg = 0.0
                #print(xg)
                # Og
                Og = raw[i+2].split()[4]
                Og = np.float(Og)-draft
                #print(Og)   
                # rayons d'inertie
                k44 = raw[i+2].split()[5]
                k44 = np.sqrt(np.float(k44))
                k55 = raw[i+2].split()[6]
                k55 = np.sqrt(np.float(k55))
                k66 = raw[i+2].split()[7]
                k66 = np.sqrt(np.float(k66))
                #print (k44,k55,k66)      
# Largeur du navire
            if 'Section        x          yb          zb ' in line:
                breadth = np.float(raw[i+1].split()[5])
                for isec in range(num_sections):
                    if np.float(raw[i+isec+1].split()[5]) >= breadth:
                        breadth = np.float(raw[i+isec+1].split()[5])
                #print('br:',breadth)
               
## Fréquences min et max et nombre de fréquences
            if 'Number of frequencies' in line:
                num_frequencies = raw[i].split()[-1]
                num_frequencies = int(num_frequencies)
                num_lines_frequencies = int(ceil(num_frequencies/10.))
                #print(num_frequencies,num_lines_frequencies)

            if 'Wave frequency' in line:
                if num_frequencies == 1: frequencies = np.array(raw[i].split()[-1]).astype(np.float) 
                if num_frequencies>1:
                    for j in range(num_lines_frequencies):
                        if j == 0:
                            frequencies = np.array(raw[i].split()[2]).astype(np.float)
                            indic = 2+num_frequencies
                            if (indic>12): indic=12
                            for k in range(3,indic):
                               tmp = np.float(raw[i].split()[k])
                               frequencies = np.append(frequencies,tmp)
                        else:
                            tmp = np.array(raw[i+j].split()).astype(np.float)
                            frequencies = np.append(frequencies,tmp)
                #print(frequencies)
                minfreq = frequencies[0]
                #print(minfreq)
                maxfreq = frequencies[-1]
                #print(maxfreq)

## Vitesses d'avance (message d'erreur si nbre>1 ou v>0)
            if 'Number of velocities' in line:
                num_speeds = raw[i].split()[-1]
                num_speeds = int(num_speeds)
                if num_speeds>1:
                    print('Number of speeds greater than 1')
                    sys.exit()
                #print(num_speeds)

            if 'Velocities' in line:
               speeds = raw[i].split()[-1]
               speeds = np.float(speeds)
               if speeds!=0.0:
                   print('Speed not equal to zero')
                   sys.exit()
               #print(speeds)

# Matrice contenant les masses et les inerties (matrice 6x6). 
            if 'Masses' in line:
                mass_matrix = {}
                mass_matrix = np.zeros((6,6)).astype(np.float)
                for j in range(6):
                   for k in range(6):
                       tmp = np.float(raw[i+2+j].split()[k])
                       mass_matrix[j][k] = 1000*tmp
                #print(mass_matrix)
               
# Matrice contenant les hydrostatiques (matrice 6x6). Comme pour les masses et inerties,
# cette matrice ne dépend pas des fréquences ni des directions de houle
            if 'Hydrost.' in line:
                stiffness_matrix = {}
                stiffness_matrix = np.zeros((6,6)).astype(np.float)
                for j in range(6):
                   for k in range(6):
                       tmp = np.float(raw[i+2+j].split()[k])
##                       if abs(tmp)<100.:
                # Suppression des valeurs négatives
                       if tmp<0.:
                           tmp=0.
                       stiffness_matrix[j][k] = 1000*tmp
                #print(stiffness_matrix)            

# Tableaux contenant les longueurs d'onde, les masses ajoutées et les amortissements(matrices 6x6).
# Ces matrices dépendent des fréquences de houle mais pas des directions.
        added_mass = {}
        radiation_damping = {}
        wave_lengths = {}
        wave_number = {}
        added_mass = np.zeros((num_frequencies,6,6)).astype(np.float)
        radiation_damping = np.zeros((num_frequencies,6,6)).astype(np.float)                
        wave_lengths = np.zeros(num_frequencies).astype(np.float)
        wave_number = np.zeros(num_frequencies).astype(np.float)

# Tableaux contenant les efforts d'excitation de houle (parties rélle et imaginaire)
# et les efforts de dérive dans les directions du plan (X, Y, MZ)
# Ces efforts dépendent de la direction et des fréquences de houle
# Amplitude et phase des efforts d'excitation en cos(wt + phi).
#  ATTENTION ! Le signe (-) pour le sinus sera mis lors de l'interpolation de l'IRF!
        excitation_magnitude = {}
        excitation_phase = {}
        drift_forces = {} 
        excitation_magnitude = np.zeros((num_frequencies,num_wave_directions,6)).astype(np.float)
        excitation_phase = np.zeros((num_frequencies,num_wave_directions,6)).astype(np.float)
        drift_forces = np.zeros((num_frequencies,num_wave_directions,6)).astype(np.float)
        excitation_real = {}
        excitation_imag = {}
        excitation_real = np.zeros((num_frequencies,num_wave_directions,6)).astype(np.float)
        excitation_imag = np.zeros((num_frequencies,num_wave_directions,6)).astype(np.float)

        print ('Enter a minimum value for the added masses,\n'
              +'Below this value, the added mass values ​​will not be considered,\n'
              +'ATTENTION!, it will be necessary to check with the graphs,\n'
              +'that one does not lose information with a too high value\n')
        tmp3lim = input('Enter the minimum value (Default value: 100.):\n')
        if tmp3lim !='':                                           
            tmp3lim = np.float(tmp3lim)
        else:
            tmp3lim = 100.
        print ('Enter a minimum value for the radiation dampings,\n'
              +'Below this value, the radiation damping values ​​will not be considered,\n'
              +'ATTENTION!, it will be necessary to check with the graphs,\n'
              +'that one does not lose information with a too high value\n')
        tmp4lim = input('Enter the minimum value (Default value: 25.):\n')
        if tmp4lim !='':                                           
            tmp4lim = np.float(tmp4lim)
        else:
            tmp4lim = 25.

# Enumerate: renvoie un itérateur i devant chaque ligne du fichier 'raw' (donc le fichier hydro)
        for i, line in enumerate(raw, start=0):
            
            for iFreq in range(num_frequencies):
                for iDir in range(num_wave_directions):
                    if'Wave circ. frequency' in line:
                        tmp1 = np.float(raw[i].split()[3])
                        tmp2 = np.float(raw[i].split()[15])
                        if tmp1==frequencies[iFreq]:
                            if tmp2==wave_directions[iDir]:
                                wave_lengths[iFreq] = np.float(raw[i].split()[9])
                                wave_number[iFreq] = np.float(raw[i].split()[12])
                                for j in range(6):
                                   for k in range(6):
                                       # Masses ajoutées 
                                       tmp3 = np.float(raw[i+8+j].split()[k])
                                       if abs(tmp3)<tmp3lim:
                                           tmp3=0.
                                       added_mass[iFreq][j][k] = 1000*tmp3
                                       # Amortissements de radiation 
                                       tmp4 = np.float(raw[i+17+j].split()[k])
                                       if abs(tmp4)<tmp4lim:
                                           tmp4=0.
                                       radiation_damping[iFreq][j][k] = -1000*tmp4
                                       #tmpp = radiation_damping[iFreq][5][2]

                                for k in range(6):
                                    tmp5 = np.float(raw[i+26].split()[k])
                                    excitation_real[iFreq][iDir][k] = 1000*tmp5                                  
                                    tmp6 = np.float(raw[i+27].split()[k])
                                    excitation_imag[iFreq][iDir][k] = 1000*tmp6 
                                    excitation_magnitude[iFreq][iDir][k] = 1000*np.sqrt(tmp5**2+tmp6**2)
                                    excitation_phase[iFreq][iDir][k] = np.arctan2(tmp6,tmp5)*180./np.pi

                                if tmp1>0.05:
                                    #print(tmp1,tmp2)
                                    tmp7 = np.float(raw[i+28].split()[9])
                                    tmp8 = np.float(raw[i+28].split()[10])
                                    tmp9 = np.float(raw[i+29].split()[7])
                                    drift_forces[iFreq][iDir][0] = 1000*tmp7
                                    drift_forces[iFreq][iDir][1] = 1000*tmp8
                                    drift_forces[iFreq][iDir][5] = 1000*tmp9
                                else:
                                    drift_forces[iFreq][iDir][0] = 0.
                                    drift_forces[iFreq][iDir][1] = 0.
                                    drift_forces[iFreq][iDir][5] = 0.

## Calcul de l'amortissement en cavalement B11t
        coef_rad = 0.5*(Lpp/breadth)
        for iFreq in range(num_frequencies):
            if frequencies[iFreq] <= 1.75:
                radiation_damping[iFreq][0][0] = radiation_damping[iFreq][1][1] / coef_rad
                                    
##        cel_wave = {}
##        cel_group = {}
##        alpha_C = {}
##        alpha_Cderiv = {}
##        cel_wave = np.zeros(num_frequencies).astype(np.float)
##        cel_group = np.zeros(num_frequencies).astype(np.float)
##        alp_C = np.zeros(num_frequencies).astype(np.float)
##        alp_Cdom = np.zeros(num_frequencies).astype(np.float)
##
##        Xdrift_dom = {}
##        Xdrift_dom1 = {}
##        Xdrift_dom = np.zeros(num_frequencies).astype(np.float)
##        Xdrift_dom1 = np.zeros(num_frequencies).astype(np.float)
##
##        # Amortissement visqueux en cavalement
##        Mswet = pow(Mass,1/3)
##        Swet = (3.4*Mswet+0.515*Lpp)*Mswet  # Surface mouillée du navire
##        Nu = density * pow(10,-4)
##        B11v = Nu* (5+0.75*pow(Swet,3/2))# Amortissement visqueux
##        
##        for iFreq in range(num_frequencies-1):
##            cel_wave[iFreq] = frequencies[iFreq]/wave_number[iFreq] # Célérité de vague C
##            tmp = 4*np.pi*water_depth/wave_lengths[iFreq]
##            cel_group[iFreq] = (cel_wave[iFreq]*(1+tmp/np.sinh(tmp)))/2 # Célérité de groupe Cg
##            alp_C[iFreq] = cel_group[iFreq]/cel_wave[iFreq] # Cg/C
##
##        for iFreq in range(1,num_frequencies-1):
##            # Dérivée de Cg/C en fonction de la fréquence
##            alp_Cdom[iFreq] = (alp_C[iFreq+1] - alp_C[iFreq]) / (frequencies[iFreq+1] - frequencies[iFreq])
##            # Dérivée de l'effort de dérive longitudinal (X) en fonction de la fréquence
##            #Xdrift_dom1[iFreq] = (drift_forces[iFreq+1][0][0]-drift_forces[iFreq][0][0]) / (frequencies[iFreq+1]-frequencies[iFreq])
##            Xdrift_dom[iFreq] = (excitation_magnitude[iFreq+1][0][0]-excitation_magnitude[iFreq][0][0]) / (frequencies[iFreq+1]-frequencies[iFreq])
##            # Amortissement de radiation en cavalement.
##            # Attention! l'amortissement est maximal du fait que l'on ne tient pas compte de la direction de la houle (houle dans l'axe du navire)
##            tmp = (2 - frequencies[iFreq]*alp_Cdom[iFreq])/cel_group[iFreq]
##            radiation_damping[iFreq][0][0] = abs(tmp*excitation_magnitude[iFreq][0][0]+wave_number[iFreq]*Xdrift_dom[iFreq])
##            #radiation_damping[iFreq][0][0] = abs(tmp*drift_forces[iFreq][0][0]+wave_number[iFreq]*Xdrift_dom1[iFreq])
##            radiation_damping[iFreq][0][0] = radiation_damping[iFreq][0][0] + B11v

        
##        print(alp_C[10],alp_C[11],alp_Cdom[10])
##        print(cel_group[10],Xdrift_dom[10],B11v,radiation_damping[10][0][0])
# Matrice des amortissements pour laquelle on a rajouté deux valeurs nulles
# pour omega = 0 et omega = 15 rad/s
        raddamp_mod = np.zeros((num_frequencies+2,6,6)).astype(np.float)
        freq_mod = np.zeros(num_frequencies+2).astype(np.float)
        for iFreq in range(num_frequencies):
            raddamp_mod[iFreq+1,:,:] = radiation_damping[iFreq,:,:]
            freq_mod[iFreq+1] = frequencies[iFreq]
        freq_mod[num_frequencies+1] = 15.0
## Coordonnées du centre de gravité cg
        cg = {}
        cg = np.array([xg,yg,Og])

        #print(mass_matrix)
        #print(stiffness_matrix)
# Ecriture des matrices de masses ajoutées
        #print(added_mass)        
# Ecriture des matrices de amortissements
        #print(radiation_damping)
# Ecriture des efforts d'excitation de houle
        #print(excitation_real)
        #print(excitation_imag)
        #print(drift_forces)

# 
        for i in range(num_bodies):


            print('body' + str(i+1) + ':')

            self.body[i] = bem.HydrodynamicData()
            self.body[i].scaled = self.scaled

            self.body[i].rho = density
            self.body[i].g = 'not_defined'
            self.body[i].wave_dir = wave_directions
            self.body[i].num_bodies = num_bodies

            self.body[i].cg = cg
            self.body[i].cb = 'not_defined'
            self.body[i].k = stiffness_matrix
            self.body[i].T = 2*np.pi/frequencies
            self.body[i].w = frequencies
            self.body[i].wmod = freq_mod

            self.body[i].wp_area = 'not_defined'
            self.body[i].buoy_force = 'not_defined'
            self.body[i].disp_vol = 'not_defined'
            self.body[i].water_depth = water_depth
            self.body[i].body_num = i

            self.body[i].name = 'body' + str(i+1)
            self.body[i].bem_code = code
            self.body[i].bem_raw_data = raw

            self.body[i].am.all = np.copy(added_mass)
            print('   * Setting added mass at infinite frequency to added mass at omega = ' + str(frequencies[-1]))
            self.body[i].am.inf = np.copy(added_mass[-1,:,:])
#            print(added_mass[-1,:,:])
            print('   * Setting added mass at zero frequency to added mass at omega = ' + str(frequencies[0]))
            self.body[i].am.zero = np.copy(added_mass[0,:,:])
            self.body[i].rd.all = radiation_damping
            self.body[i].rd.mod = raddamp_mod
            self.body[i].ex.mag = excitation_magnitude
            self.body[i].ex.phase = excitation_phase
            print('   * Setting real and imaginary excitation components.')
            self.body[i].ex.re = excitation_real
            self.body[i].ex.im = excitation_imag
            print('   * Setting drift forces.')
            self.body[i].ex.dr = drift_forces
            
            self.body[i].scale(self.scaled_at_read)

        ###############################################################################
        #               Plots of ADDED MASS coefficients
        ###############################################################################

        repons = input('Do you want plots of Added mass coefficients?: Yes or No (default: No)\n')
        if repons !='':
            repons = str(repons)
        else:
            repons = 'No'

        if repons == 'Yes':
            am_replac = np.zeros((num_frequencies,6,6)).astype(np.float)
            Windowlen = input('Enter the dimension of the smoothing window - odd integer (Default value: 11): ')
            if Windowlen !='':
                Windowlen = np.int(Windowlen)
            else:
                Windowlen = np.int('11')
            for i in range(6):
                for j in range(6):
                    if all(0 == a for a in self.body[0].am.all[:,i,j]) is False:
                        try:
                            ynew = smh.smooth(self.body[0].am.all[:,i,j],Windowlen,'hamming')
                            plt.interactive(True)
                            plt.figure()
                            plt.plot(self.body[0].w,self.body[0].am.all[:,i,j],'r',self.body[0].w,ynew,'b--',
                                     label='Added mass coefficient {} {}'.format(i+1,j+1))               
                            plt.grid(True)
                            plt.legend()
                            plt.title('Added Mass')
                            plt.xlabel('Frequency (rad/s)')
                            if i<3 and j<3: plt.ylabel('Added mass (kg)')
                            if i<3 and j>=3: plt.ylabel('Added mass (kg.m)')
                            if i>=3 and j<3: plt.ylabel('Added mass (kg.m)')
                            if i>=3 and j>=3: plt.ylabel('Added mass (kg.m2)')
                            am_replac[:,i,j] = ynew
                        except:
                            pass

            repons = input('Replace the Added mass values by the smoothed ones?: Yes or No (default: No)\n')
            if repons !='':
                repons = str(repons)
            else:
                repons = 'No'
            if repons == 'Yes':
                self.body[0].am.all = np.copy(am_replac)
        
        ###############################################################################
        #       Plots, fitting or smoothing of RADIATION DAMPING coefficients
        ###############################################################################
        
        repons = input('Plots of Radiation damping coefficients with smoothing or fitting (default: 1):\n'
                       +'1: Fitting to an exponential curve,\n'
                       +'2: Smoothing with hamming method,\n'
                       )
        if repons !='':
            repons = str(repons)
        else:
            repons = '1'

        reponsRadDamp = int(repons)
        
        if '1' in repons:
            rd_replac = np.zeros((num_frequencies,6,6)).astype(np.float)
            
        # Extension and fitting of radiation damping data to an exponential curve
        # Choice of frequency limit for the radiation damping fitting

            Frlim = input('Enter the value of frequency limit in rad/s (Default value: 1.75 rad/s):\n')
            if Frlim !='':
                Frlim = np.float(Frlim)
                iFreq = 0
                while self.body[0].w[iFreq] < Frlim:
                    if iFreq < (num_frequencies-1):
                        iFreq +=1
                    else:    
                        print('Frequency not in the list')
                        sys.exit()
            else:
                iFreq = 0
                while self.body[0].w[iFreq] < 1.75:
                    if iFreq < (num_frequencies-1):
                        iFreq +=1
                    else:    
                        print('Frequency not in the list')
                        sys.exit()

            iFreq_Fit = iFreq
            indic = 0

            for i in range(6):
                for j in range(6):
                    if all(0 == a for a in self.body[0].rd.all[:,i,j]) is False:
                        y_fit = rdft.raddamp_fit(self.body[0].w[iFreq:],self.body[0].rd.all[iFreq:,i,j],i,j,indic)
                        rd_replac[iFreq:,i,j] = y_fit
                        indic += 1

            repons = input('Do you want plots of Radiation damping coefficients?: Yes or No (default: No)\n')
            if repons !='':
                repons = str(repons)
            else:
                repons = 'No'

            if repons == 'Yes':
                for i in range(6):
                    for j in range(6):
                        if all(0 == a for a in self.body[0].rd.all[:,i,j]) is False:
                            try:
                                plt.interactive(True)
                                plt.figure()
                                plt.plot(self.body[0].w[:iFreq],self.body[0].rd.all[:iFreq,i,j],'r',
                                    label='Initial data {} {}'.format(i+1,j+1))
                                plt.plot(self.body[0].w[iFreq:],self.body[0].rd.all[iFreq:,i,j],'ro',
                                     markersize=3)
                                plt.plot(self.body[0].w[iFreq:],rd_replac[iFreq:,i,j],'b--',
                                    label='Fitted curve {} {}'.format(i+1,j+1))
                                plt.grid(True)
                                plt.xlabel('Frequency (rad/s)')
                                if i<3 and j<3: plt.ylabel('Damping coefficient (kg/s)')
                                if i<3 and j>=3: plt.ylabel('Damping coefficient (kg.m/s)')
                                if i>=3 and j<3: plt.ylabel('Damping coefficient (kg.m/s)')
                                if i>=3 and j>=3: plt.ylabel('Damping coefficient (kg.m2/s)')
                                plt.legend()
                                plt.title('Radiation damping coefficient')
                            except:
                                pass
            
            repons = input('Replace the Radiation damping values by the fitted ones?: Yes or No (default: No)\n')
            if repons !='':
                repons = str(repons)
            else:
                repons = 'No'
            if repons == 'Yes':
                self.body[0].rd.all[iFreq:,:,:] = np.copy(rd_replac[iFreq:,:,:])
            
        # Smoothing of radiation damping curves with hamming method

        if '2' in repons:
            rd_replac = np.zeros((num_frequencies,6,6)).astype(np.float)

            # Determination of smoothing window dimension
            Windowlen = input('Enter the dimension of the smoothing window - odd integer (Default value: 11):\n')
            if Windowlen !='':
                Windowlen = np.int(Windowlen)
            else:
                Windowlen = np.int('11')

            # Determination of minimum frequency limit for smoothing
            Frlim = input('Enter the value of frequency limit in rad/s (Default value: 0):\n')
            if Frlim !='':
                Frlim = np.float(Frlim)
                iFreq = 0
                while self.body[0].w[iFreq] < Frlim:
                    if iFreq < (num_frequencies-1):
                        iFreq +=1
                    else:    
                        print('Frequency not in the list')
                        sys.exit()
            else:
                iFreq = np.int('0')

            iFreq_Fit = iFreq # Not used here; Only for writing in FreqDir.txt file
                
            for i in range(6):
                for j in range(6):
                    if all(0 == a for a in self.body[0].rd.all[:,i,j]) is False:
                        ynew = smh.smooth(self.body[0].rd.all[iFreq:,i,j],Windowlen,'hamming')
                        rd_replac[iFreq:,i,j] = ynew

            repons = input('Do you want plots of Radiation damping coefficients?: Yes or No (default: No)\n')
            if repons !='':
                repons = str(repons)
            else:
                repons = 'No'

            if repons == 'Yes':
                for i in range(6):
                    for j in range(6):
                        if all(0 == a for a in self.body[0].rd.all[:,i,j]) is False:
                            try:
                                plt.interactive(True)
                                plt.figure()
                                plt.plot(self.body[0].w[:iFreq],self.body[0].rd.all[:iFreq,i,j],'r',
                                    label='Initial data {} {}'.format(i+1,j+1))
                                plt.plot(self.body[0].w[iFreq:],self.body[0].rd.all[iFreq:,i,j],'ro',
                                     markersize=3)
                                plt.plot(self.body[0].w[iFreq:],rd_replac[iFreq:,i,j],'b--',
                                    label='Smoothed curve {} {}'.format(i+1,j+1))
                                plt.grid(True)
                                plt.xlabel('Frequency (rad/s)')
                                if i<3 and j<3: plt.ylabel('Damping coefficient (kg/s)')
                                if i<3 and j>=3: plt.ylabel('Damping coefficient (kg.m/s)')
                                if i>=3 and j<3: plt.ylabel('Damping coefficient (kg.m/s)')
                                if i>=3 and j>=3: plt.ylabel('Damping coefficient (kg.m2/s)')
                                plt.legend()
                                plt.title('Radiation damping coefficient')
                            except:
                                pass

            repons = input('Replace the Radiation damping values by the smoothed ones?: Yes or No (default: Yes)\n')
            if repons !='':
                repons = str(repons)
            else:
                repons = 'Yes'
            if repons == 'Yes':
                self.body[0].rd.all[iFreq:,:,:] = np.copy(rd_replac[iFreq:,:,:])

##            for i in range(6):
##                for j in range(6):
##                    if all(0 == a for a in self.body[0].rd.mod[:,i,j]) is False:
##                        print(i,j)
##                        print(self.body[0].rd.mod[:,i,j])
##                        try:
##                            plt.interactive(True)
##                            plt.figure()
##                            plt.plot(self.body[0].wmod,self.body[0].rd.mod[:,i,j],'r',
##                                    label='Initial data {} {}'.format(i,j))
##                            plt.grid(True)
##                            plt.legend()
##                            plt.title('Radiation damping coefficient')
##                        except:
##                            pass

        ###############################################################################
        #           Plots of EXCITATION FORCE magnitude
        ###############################################################################
        
        repons = input('Do you want plots of Excitation force real and imag. values?: Yes or No (default: No)\n')
        if repons !='':
            repons = str(repons)
        else:
            repons = 'No'

        if repons == 'Yes':

            print('Wave directions:\n',wave_directions)
            Dir_Houl = input('Wave direction chosen (default value: 90): ')
            if Dir_Houl !='':
                Dir_Houl = np.float(Dir_Houl)
            else:
                Dir_Houl = np.float('90')
            iDir = 0
            while Dir_Houl != wave_directions[iDir]:
                if iDir < (num_wave_directions-1):
                    iDir +=1
                else:    
                    print('Wave direction not in the list')
                    sys.exit()
                    
            ex_re_replac = np.zeros((num_frequencies,num_wave_directions,6)).astype(np.float)
            ex_im_replac = np.zeros((num_frequencies,num_wave_directions,6)).astype(np.float)
            Windowlen = input('Enter the dimension of the smoothing window - odd integer (Default value: 11): ')
            if Windowlen !='':
                Windowlen = np.int(Windowlen)
            else:
                Windowlen = np.int('11')
            for i in range(6):                
                if all(0 == a for a in self.body[0].ex.re[:,iDir,i]) is False:                    
                    try:
                        ynew_re = smh.smooth(self.body[0].ex.re[:,iDir,i],Windowlen,'hamming')
                        ynew_im = smh.smooth(self.body[0].ex.im[:,iDir,i],Windowlen,'hamming')
                        plt.interactive(True)
                        plt.figure()
                        plt.plot(self.body[0].w,self.body[0].ex.re[:,iDir,i],'r',label='Excitation force real part {}'.format(i+1))
                        plt.plot(self.body[0].w,ynew_re,'r--',label='Smoothed curve real part {}'.format(i+1))
                        plt.plot(self.body[0].w,self.body[0].ex.im[:,iDir,i],'b',label='Excitation force imag. part {}'.format(i+1))
                        plt.plot(self.body[0].w,ynew_im,'b--',label='Smoothed curve imag. part {}'.format(i+1))
                        plt.plot(self.body[0].w,self.body[0].ex.mag[:,iDir,i],'g',
                                    label='Excitation force magnitude {}'.format(i+1))
                        plt.grid(True)
                        plt.xlabel('Frequency (rad/s)')
                        if i<3: plt.ylabel('Excitation force (N/m)')
                        if i>=3: plt.ylabel('Excitation force (N.m/m)')
                        plt.legend()
                        plt.title('Excitation Force')
                        ex_re_replac[:,iDir,i] = ynew_re
                        ex_im_replac[:,iDir,i] = ynew_im
                    except:
                        pass


            repons = input('Replace the Excitation force real and imag. values by the smoothed ones?: Yes or No (default: No)\n')
            if repons !='':
                repons = str(repons)
            else:
                repons = 'No'
            if repons == 'Yes':
                self.body[0].ex.re[:,iDir,:] = ex_re_replac[:,iDir,:]
                self.body[0].ex.im[:,iDir,:] = ex_im_replac[:,iDir,:]               

        ###############################################################################
        #               Plots of DRIFT forces
        ###############################################################################
        
        repons = input('Do you want plots of Drift force?: Yes or No (default: No)\n')
        if repons !='':
            repons = str(repons)
        else:
            repons = 'No'

        if repons == 'Yes':

            print('Wave directions:\n',wave_directions)
            Dir_Houl = input('Wave direction chosen (default value: 90): ')
            if Dir_Houl !='':
                Dir_Houl = np.float(Dir_Houl)
            else:
                Dir_Houl = np.float('90')
            iDir = 0
            while Dir_Houl != wave_directions[iDir]:
                if iDir < (num_wave_directions-1):
                    iDir +=1
                else:    
                    print('Wave direction not in the list')
                    sys.exit()

            ex_dr_replac = np.zeros((num_frequencies,num_wave_directions,6)).astype(np.float)                    
            Windowlen = input('Enter the dimension of the smoothing window - odd integer (Default value: 11): ')
            if Windowlen !='':
                Windowlen = np.int(Windowlen)
            else:
                Windowlen = np.int('11')
            for i in range(6):                
                if all(0 == a for a in self.body[0].ex.dr[:,iDir,i]) is False:                    
                    try:
                        ynew = smh.smooth(self.body[0].ex.dr[:,iDir,i],Windowlen,'hamming')
                        plt.interactive(True)
                        plt.figure()
                        plt.plot(self.body[0].w,self.body[0].ex.dr[:,iDir,i],'r',label='Drift force {}'.format(i+1))
                        plt.plot(self.body[0].w,ynew,'b--',label='Smoothed curve {}'.format(i+1))
                        plt.grid(True)
                        plt.xlabel('Frequency (rad/s)')
                        if i<3: plt.ylabel('Drift force (N/m2)')
                        if i>=3: plt.ylabel('Drift force (N.m/m2)')
                        plt.legend()
                        plt.title('Drift Force')
                        ex_dr_replac[:,iDir,i] = ynew
                    except:
                        pass

            repons = input('Replace the Drift force values by the smoothed ones?: Yes or No (default: No)\n')
            if repons !='':
                repons = str(repons)
            else:
                repons = 'No'
            if repons == 'Yes':
                self.body[0].ex.dr[:,iDir,:] = ex_dr_replac[:,iDir,:]

        ###############################################################################
        # Ecriture d'un fichier pour le modèle Simbad en houle régulière
        ###############################################################################

        #repons = input('Do you want a Simbad file for regular wave?: Yes or No (default: No)\n')
        repons = ''
        if repons !='':
            repons = str(repons)
        else:
            repons = 'No'
        if repons == 'Yes':

            print('Wave directions:\n',wave_directions)
            Dir_Houl = input('Wave direction chosen (default value: 90): ')
            if Dir_Houl !='':
                Dir_Houl = np.float(Dir_Houl)
            else:
                Dir_Houl = np.float('90')

            print('Wave frequencies:\n',frequencies)            
            Freq_Houl = input('Wave frequency chosen (default value: 0.5): ')
            if Freq_Houl !='':
                Freq_Houl = np.float(Freq_Houl)
            else:
                Freq_Houl = np.float('0.5')

            iFreq = 0
            while Freq_Houl != frequencies[iFreq]:
                if iFreq < (num_frequencies-1):
                    iFreq +=1
                    Freq_inpl = False
                else:
                    if Freq_Houl > frequencies[0] and Freq_Houl < frequencies[-1]:
                        print('Interpolation of coefficients in frequency')
                        Freq_inpl = True
                        am_inpl = inpl.interpolate_ad_rd(frequencies,Freq_Houl,added_mass)
                        rd_inpl = inpl.interpolate_ad_rd(frequencies,Freq_Houl,radiation_damping)
                        exreal_Freqinpl = inpl.interpolate_ad_rd(frequencies,Freq_Houl,excitation_real)
                        eximag_Freqinpl = inpl.interpolate_ad_rd(frequencies,Freq_Houl,excitation_imag)
                        drf_Freqinpl = inpl.interpolate_ad_rd(frequencies,Freq_Houl,drift_forces)
                        break
                    else:
                        print('Wave frequency not in the list')
                        sys.exit()

            iDir = 0
            while Dir_Houl != wave_directions[iDir]:
                if iDir < (num_wave_directions-1):
                    iDir +=1
                    Dir_inpl = False
                else:    
                    if Dir_Houl > wave_directions[0] and Dir_Houl < wave_directions[-1]:
                        print('Interpolation of coefficients in direction')
                        Dir_inpl = True
                        if Freq_inpl is True:
                            exreal_FreqDir_inpl = inpl.interpolate_exf(wave_directions,Dir_Houl,exreal_Freqinpl)
                            eximag_FreqDir_inpl = inpl.interpolate_exf(wave_directions,Dir_Houl,eximag_Freqinpl)
                            drf_FreqDir_inpl = inpl.interpolate_exf(wave_directions,Dir_Houl,drf_Freqinpl)
                            break
                        else:
                            exreal_Freqinpl = inpl.interpolate_ad_rd(frequencies,Freq_Houl,excitation_real)
                            eximag_Freqinpl = inpl.interpolate_ad_rd(frequencies,Freq_Houl,excitation_imag)
                            drf_Freqinpl = inpl.interpolate_ad_rd(frequencies,Freq_Houl,drift_forces)
                            exreal_FreqDir_inpl = inpl.interpolate_exf(wave_directions,Dir_Houl,exreal_Freqinpl)
                            eximag_FreqDir_inpl = inpl.interpolate_exf(wave_directions,Dir_Houl,eximag_Freqinpl)
                            drf_FreqDir_inpl = inpl.interpolate_exf(wave_directions,Dir_Houl,drf_Freqinpl)
                            break
                    else:
                        print('Wave direction not in the list')
                        sys.exit()

            print()
            Ampl = input('Wave amplitude (H/2) in m: ')
            Ampl = np.float(Ampl)
            if Freq_inpl is False:
                Period = 2*np.pi/frequencies[iFreq]
            else:
                Period = 2*np.pi/Freq_Houl
            Cddeb = 0.0 # Coefficient d'amortissement de débattement
            with open('Houl_reg.txt','w') as fid:
                tmp = np.array([Lpp,num_bodies,xg,yg,Og])
                np.savetxt(fid,[tmp],fmt='%10.2f')
                tmp = np.array([Period,Dir_Houl,Ampl])
                np.savetxt(fid,[tmp],fmt='%10.2f')
                tmp = np.array([draft,Cddeb])
                np.savetxt(fid,[tmp],fmt='%10.2f')
                for i in range(6):
                    tmp = mass_matrix[i]
                    np.savetxt(fid,[tmp],fmt='%.5e')
                for i in range(6):
                    tmp = stiffness_matrix[i]
                    np.savetxt(fid,[tmp],fmt='%.5e')
                # Deux cas si interpolation en fréquence
                if Freq_inpl is False:
                    for i in range(6):
                        tmp = added_mass[iFreq][i][:]
                        np.savetxt(fid,[tmp],fmt='%.5e')
                    for i in range(6):
                        tmp = radiation_damping[iFreq][i][:]
                        np.savetxt(fid,[tmp],fmt='%.5e')
                else:
                    for i in range(6):
                        tmp = am_inpl[i][:]
                        np.savetxt(fid,[tmp],fmt='%.5e')
                    for i in range(6):
                        tmp = rd_inpl[i][:]
                        np.savetxt(fid,[tmp],fmt='%.5e')
                # Trois cas si interpolation en fréquence ou/et en direction
                if Freq_inpl is False and Dir_inpl is False:
                    tmp = excitation_real[iFreq][iDir][:]
                    np.savetxt(fid,[tmp],fmt='%.5e')
                    # Signe (-) mis pour la partie imaginaire!!
                    tmp = -excitation_imag[iFreq][iDir][:]
                    np.savetxt(fid,[tmp],fmt='%.5e')
                    tmp = drift_forces[iFreq][iDir][:]
                    np.savetxt(fid,[tmp],fmt='%.5e')
                if Freq_inpl is True and Dir_inpl is False:
                    tmp = exreal_Freqinpl[iDir][:]
                    np.savetxt(fid,[tmp],fmt='%.5e')
                    # Signe (-) mis pour la partie imaginaire!!
                    tmp = -eximag_Freqinpl[iDir][:]
                    np.savetxt(fid,[tmp],fmt='%.5e')
                    tmp = drf_Freqinpl[iDir][:]
                    np.savetxt(fid,[tmp],fmt='%.5e')
                if Dir_inpl is True:
                    tmp = exreal_FreqDir_inpl[:]
                    np.savetxt(fid,[tmp],fmt='%.5e')
                    # Signe (-) mis pour la partie imaginaire!!
                    tmp = -eximag_FreqDir_inpl[:]
                    np.savetxt(fid,[tmp],fmt='%.5e')
                    tmp = drf_FreqDir_inpl[:]
                    np.savetxt(fid,[tmp],fmt='%.5e')

        ##########################################################################################
        # Ecriture d'un fichier pour le modèle Simbad en houle irrégulière (hors efforts de houle)
        ##########################################################################################
        
        repons = input('Do you want a Simbad file for irregular wave?: Yes or No (default: Yes)\n')

        if repons !='':
            repons = str(repons)
        else:
            repons = 'Yes'
        if repons == 'Yes':

            print('Wave directions:\n',wave_directions)
            Dir_Houl = input('Wave direction chosen (default value: 90): ')
            if Dir_Houl !='':
                Dir_Houl = np.float(Dir_Houl)
                if Dir_Houl < wave_directions[0] or Dir_Houl > wave_directions[-1]:
                    print('Wave direction not in the list')
                    sys.exit()
            else:
                Dir_Houl = np.float('90')

            print('Wave frequencies:\n',frequencies)            
            Freq_Houl = input('Wave frequency chosen (default value: 0.5): ')
            if Freq_Houl !='':
                Freq_Houl = np.float(Freq_Houl)
                if Freq_Houl < frequencies[0] or Freq_Houl > frequencies[-1]:
                    print('Wave frequency not in the list')
                    sys.exit()                    
            else:
                Freq_Houl = np.float('0.5')

            print()
            Ampl = input('Wave height Hs in m (default value:0.001 m): ')
            if Ampl !='':
                Ampl = np.float(Ampl)
            else:
                Ampl = np.float('0.001')
            
            Period = 2*np.pi/Freq_Houl
            # Coefficients d'amortissement en roulis
            # Formulation non testée et non utilisée dans SIMBAD
            #B44OM, B44PHI = RD(breadth, mass_matrix[2,2], mass_matrix[3,3], self.body[0].am.inf[3,3])
            B44OM = 0.0
            B44PHI = 0.0
            
            with open('Houl_irr.txt','w') as fid:
                tmp = np.array([Lpp,num_bodies,xg,yg,Og])
                np.savetxt(fid,[tmp],fmt='%10.2f %.1i %10.2f %10.2f %10.2f')
                tmp = np.array([Period,Dir_Houl,Ampl])
                np.savetxt(fid,[tmp],fmt='%10.2f')
                tmp = np.array([draft,B44OM,B44PHI])
                np.savetxt(fid,[tmp],fmt='%10.2f %.8e %.8e')
                for i in range(6):
                    tmp = mass_matrix[i]
                    np.savetxt(fid,[tmp],fmt='%.5e')
                for i in range(6):
                    tmp = stiffness_matrix[i]
                    np.savetxt(fid,[tmp],fmt='%.5e')
                # Writing of added mass at infinite frequency in a txt file
                np.savetxt(fid,self.body[0].am.inf,fmt='%.6e')
                #print(self.body[0].am.inf)

            with open('FreqDir.txt','w') as fid:
                tmp = np.array([reponsRadDamp,iFreq_Fit])
                np.savetxt(fid,[tmp],fmt='%.1i')
                tmp = np.array([Period,Dir_Houl,Ampl])
                np.savetxt(fid,[tmp],fmt='%10.2f')

def enumerate(sequence, start=0):
    n = start
    for elem in sequence:
        yield n, elem
        n += 1

def read(hydro_file, scale=False):
    '''
    Function to read pdstrip data into a data object of type(pdstripOutput)

    Parameters:
        hydro_file : str
            Name of the pdstrip .OUT output file
        scale : bool, optional
            Boolean value to determine if the hydrodynamic data is scaled.
            See the bemio.data_structures.bem.scale function for more
            information

    Returns:
        pdstrip_data
            A pdstripOutput object that contains hydrodynamic data

    Examples:
        The following example assumes there are pdstrip output files named pdstrip.out

        >>> pdstrip_data = read(hydro_file=pdstrip.out)
    '''
    pdstrip_data = PdstripOutput(hydro_file, scale)

    return pdstrip_data
