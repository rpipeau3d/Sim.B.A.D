##  This file is part of SIMBAD pre-processing program.

##  SIMBAD pre-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD pre-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD pre-processing program.
##  If not, see <https://www.gnu.org/licenses/>.


# Import modules
import numpy as np
import h5py
import waveFunctions as wf
import matplotlib.pyplot as plt
from math import ceil
import plot_WSS as plW
import models as ms
import sys

## import convolution
from excitation_convol import convolution

def wave_excitation(Period,Dir_Houl,Ampl,exf_irf_inpl,dr1f_irf_inpl,dr2f_irf_inpl,dr11f_irf_inpl,dr22f_irf_inpl,reponsDrift):
# Load hydrodynamic data (file *.h5)
    hydro_data_f = h5py.File('pdstrip.h5','r+')

# Read characteristics of calculation: Hs, Tp, time (total duration of simulation), dt time step...

    Hs = Ampl
    print('Wave height Hs in m: ',Hs,'m')

    Tp = Period
    print('Peak period Tp in s: ',Tp,'s')

# Read wave direction

    wave_directions = np.array(hydro_data_f['/simulation_parameters/wave_dir'])
    print('Wave directions:\n',wave_directions)
    print('Wave direction chosen: ',Dir_Houl,'°')
    wavType = 'irregular'

# Read total duration of simulation (time) and time step dt
    time = input('Simulation duration in s (default value: 14400): ')
    if time != '':
        time = np.float(time)
    else:
        time = np.float('14400.0')
    dt = input('Time step between 0.1 and 1 s (default value: 0.5): ')
    if dt != '':
        dt = np.float(dt)
    else:
        dt = np.float('0.5')
    if dt != 0.0:
        num_dt = int(ceil(time/dt))
    else:
        print('Time step equal to zero')
        sys.exit()
    if num_dt%2==1: num_dt = num_dt+1 # num_dt should be an even integer

    eta_t = np.zeros(num_dt)
    for istep in range (num_dt-1):
        eta_t[istep+1] = eta_t[istep] + dt
    #print(eta_t)

# Get the wave frequencies out of the Pdstrip results
    freqs = np.array(hydro_data_f['/simulation_parameters/w'])
    #print('Wave frequencies:\n',freqs)
    fp = 2*np.pi/Tp
    iFreq = 0
    while fp > freqs[iFreq]:
        iFreq +=1
    else:
        freqs[iFreq] = fp
    #print('Wave frequencies:\n',freqs)
# Choice of spectrum model and calculation of spectral values
    reponsSM = input('1: Jonswap spectrum density model,\n'
                   +'2: Bretschneider spectrum density model,\n'
                   +'3: Torsethaugen spectrum density model,\n'
                   +'4: McCormick spectrum density model,\n'
                   +'5: OchiHubble spectrum density model,\n'
                   +'6: Wallop spectrum density model,\n'
                   +'Default: 1\n')
    if reponsSM !='':
        reponsSM = str(reponsSM)
    else:
        reponsSM = '1'
        
    if '1' in reponsSM:
#       Modification 02/22
#        specSS = wf.spectralValue(Hs,fp,freqs,iFreq)
        gam = ms.jonswap_peakfact(Hs,Tp)
        specSS = ms.Jonswap(Hm0=Hs, Tp=Tp, gamma=gam)
        specSS = specSS(freqs)
    elif '2' in reponsSM:
        specSS = ms.Bretschneider(Hm0=Hs, Tp=Tp)
        specSS = specSS(freqs)
    elif '3' in reponsSM:
        specSS = ms.Torsethaugen(Hm0=Hs, Tp=Tp)
        specSS = specSS(freqs)
    elif '4' in reponsSM:
        specSS = ms.McCormick(Hm0=Hs, Tp=Tp)
        specSS = specSS(freqs)
    elif '5' in reponsSM:
        specSS = ms.OchiHubble(Hm0=Hs, par=2)
        specSS = specSS(freqs)
    elif '6' in reponsSM:
        specSS = ms.Wallop(Hm0=Hs, Tp=Tp)
        specSS = specSS(freqs)

# Choice of wave time series calculation type
    reponsWTS = input('1: Wave time series with random phase,\n'
                   +'2: Wave time series with the Fast method,\n'
                   +'3: Wave time series from a specific file,\n'
                   +'4: Wave time series from a specific density spectrum,\n'
                   +'5: Regular waves (Amplitude=0.5*Hs),\n'
                   +'Default: 2\n')
    if reponsWTS !='':
        reponsWTS = str(reponsWTS)
    else:
        reponsWTS = '2'

###########################################################
# Calculate wave time series with random phase
###########################################################
    if '1' in reponsWTS:
# Construct phaseVector
        phaseVector = wf.makePhase(eta_t,freqs)
# Calculate Wave Excitation Signal (eta in cosinus; eta1 in sinus)
        plW.Plot_specSS(reponsSM,freqs,specSS)
        eta, eta1 = wf.makeWavex(eta_t,freqs,specSS,phaseVector)

# Plot the data for verification (only eta)
        plW.Plot_WS(reponsWTS,eta_t,eta,Hs)
        #plW.Plot_WS(reponsWTS,eta_t,eta1,Hs)

# Calculation of Spectral density value
# The suitable value for fs would be 1/dt
        plW.Plot_SS(reponsWTS,eta_t,eta,dt,freqs,method='2')

############################################################
# Wave excitation signal from FAST program
############################################################
    if '2' in reponsWTS:
        if wavType=='irregular':
            plW.Plot_specSS(reponsSM,freqs,specSS)
            eta = wf.makeWave_Fast(dt,num_dt,eta_t,freqs,specSS)
# Plot the data for verification.
        plW.Plot_WS(reponsWTS,eta_t,eta,Hs)

# Calculation of Spectral density value
# The suitable value for fs would be 1/dt
        plW.Plot_SS(reponsWTS,eta_t,eta,dt,freqs,method='2')

############################################################
# Wave excitation signal from a specific file
############################################################
    if '3' in reponsWTS:
        wave_data = np.loadtxt('wave_elev_South.dat')
        eta = wave_data[:,1]
        eta_t = wave_data[:,0]
        dt = eta_t[1]-eta_t[0]

# Plot the data for verification.
        plW.Plot_WS(reponsWTS,eta_t,eta,Hs)

# Calculation of Spectral density value
# The suitable value for fs would be 1/dt
        plW.Plot_SS(reponsWTS,eta_t,eta,dt,freqs,method='2')

############################################################
# Wave excitation signal from a specific density spectrum
############################################################
    if '4' in reponsWTS:
        tmp = np.loadtxt('spectre.dat')
        specVO = tmp[:,1]
        freqVO = tmp[:,0]
        plW.Plot_specSS('0',freqVO,specVO)
# Construct phaseVector
        phaseVector = wf.makePhase(eta_t,freqVO)
        eta, eta1 = wf.makeWavex(eta_t,freqVO,specVO,phaseVector)
        #eta = wf.makeWave_Fast(dt,num_dt,eta_t,freqVO,specVO)
# Plot the data for verification.
        plW.Plot_WS(reponsWTS,eta_t,eta,Hs)

# Calculation of Spectral density value
# The suitable value for fs would be 1/dt
        plW.Plot_SS(reponsWTS,eta_t,eta,dt,freqs,method='2')

###########################################################
# Regular waves
###########################################################
    if '5' in reponsWTS:
# Calculate Wave Excitation Signal
        eta = wf.makeWavexReg(eta_t,Hs,fp,freqs,specSS)

# Plot the data for verification.
        plW.Plot_WS(reponsWTS,eta_t,eta,Hs)

############################################################
# Load excitation forces
############################################################
    excit_force = np.zeros((6,len(eta_t))).astype(np.float)
    excit_force_t = np.zeros((6,len(eta_t))).astype(np.float)
    for i in range(6):
        #irf_f = np.array(hydro_data_f['/body1/hydro_coeffs/excitation/impulse_response_fun/f'])[iDir,i,:]
        irf_f = np.array(exf_irf_inpl)[i,:]
        irf_t_f = np.array(hydro_data_f['/body1/hydro_coeffs/excitation/impulse_response_fun/t'])
        ex_f = convolution(irf=irf_f, irf_t=irf_t_f, eta=eta, eta_t=eta_t)
        excit_force_t[i,:] = ex_f.excitation_force.t
        excit_force[i,:] = ex_f.excitation_force.f

# Plot the wave excitation forces for verification.
# Set interactive
    repons = input('Do you want plots of Wave excitation forces?: Yes or No (default: No)\n')
    if repons !='':
        repons = str(repons)
    else:
        repons = 'No'

    if repons == 'Yes':
        Ecrit = np.zeros(6).astype(np.str)
        Ecrit = ['Surge','Sway','Heave', 'Roll','Pitch','Yaw']
        for i in range(6):
            try:      
                plt.interactive(True)
                plt.figure()
                plt.plot(excit_force_t[i,:],excit_force[i,:],'r-',label=Ecrit[i])
                plt.xlabel('Time (s)')
                if i<3: plt.ylabel('Wave force (N)')
                if i>=3: plt.ylabel('Wave force (N.m)')
                plt.grid(True)
                plt.legend()
                plt.title('Wave excitation force')
            except:
                pass
# Writing of wave excitation forces in a txt file
    with open('wave_for.txt','w') as f:
        ndt = len(eta_t)
        #print(ndt)
        np.savetxt(f,[ndt],fmt='%.1i')
        for i in range(6):
            np.savetxt(f,[i],fmt='%.1i')
            for irow in range(ndt):
                tmpa = excit_force_t[i,irow]
                tmpb = excit_force[i,irow]
                np.savetxt(f,[(tmpa,tmpb)],fmt='%.6e')
############################################################
#           Calculation of drift forces
############################################################
    drift_force = np.zeros((6,len(eta_t))).astype(np.float)
    drift_force_t = np.zeros((6,len(eta_t))).astype(np.float)
    for i in range(6):
        irf_dr1 = np.array(dr1f_irf_inpl)[i,:]
        irf_dr2 = np.array(dr2f_irf_inpl)[i,:]
        irf_dr11 = np.array(dr11f_irf_inpl)[i,:]
        irf_dr22 = np.array(dr22f_irf_inpl)[i,:]
        irf_t_dr = np.array(hydro_data_f['/body1/hydro_coeffs/drift/impulse_response_fun/t'])

        ex_dr1 = convolution(irf=irf_dr1, irf_t=irf_t_dr, eta=eta, eta_t=eta_t)

        if reponsWTS == '1' or reponsWTS == '4':
            ex_dr2 = convolution(irf=irf_dr1, irf_t=irf_t_dr, eta=eta1, eta_t=eta_t)
        else:
            ex_dr2 = convolution(irf=irf_dr2, irf_t=irf_t_dr, eta=eta, eta_t=eta_t)

        ex_dr11 = convolution(irf=irf_dr11, irf_t=irf_t_dr, eta=eta, eta_t=eta_t)

        if reponsWTS == '1' or reponsWTS == '4':
            ex_dr22 = convolution(irf=irf_dr11, irf_t=irf_t_dr, eta=eta1, eta_t=eta_t)
        else:
            ex_dr22 = convolution(irf=irf_dr22, irf_t=irf_t_dr, eta=eta, eta_t=eta_t)

        drift_force_t[i,:] = ex_dr1.excitation_force.t
        for j in range(len(ex_dr1.excitation_force.t)):
            if reponsDrift == '2':
                drift_force[i,j] = ex_dr1.excitation_force.f[j]*ex_dr1.excitation_force.f[j]
            if reponsDrift == '3':
                drift_force[i,j] = ex_dr1.excitation_force.f[j]*ex_dr11.excitation_force.f[j] + ex_dr2.excitation_force.f[j]*ex_dr22.excitation_force.f[j]

    if reponsDrift == '2':
        if Dir_Houl > 90.0 and Dir_Houl < 270.0:
            drift_force[0,:] = - drift_force[0,:]
        if Dir_Houl < 90.0:   
            drift_force[5,:] = - drift_force[5,:]
        else:
            if Dir_Houl > 180.0 and Dir_Houl < 270.0:
               drift_force[5,:] = - drift_force[5,:]
        if Dir_Houl > 180.0:   
            drift_force[1,:] = - drift_force[1,:]

### Autre formulation pour les efforts de dérive, uniquement avec options 1 et 4 du signal de houle
### Formulation peu satisfaisante!
##    if reponsDrift == '3':
##        if reponsWTS == '1' or reponsWTS == '4':
### Wave drift forces (i=frequency, j=direction, k=movement)
##            valfo_dr = np.array(hydro_data_f['/body1/hydro_coeffs/drift/dr'])
### Interpolation of wave drift forces as function of direction (i=movement, j=frequency)
##            valfo_dr_inpl = inpl.interpolate_exf(wave_directions,Dir_Houl,valfo_dr)
##            for i in range(6):
##                if all(0 == a for a in valfo_dr_inpl[i,:]) is False:
##                    qtf = valfo_dr_inpl[i,:]
##                    if reponsWTS == '1':                    
##                        drift_force[i,:] = wf.makeDrFo(eta_t,freqs,specSS,phaseVector,qtf)
##                    if reponsWTS == '4':
##                        # Attention! incompatibilité de specVO fonction de specVO et qtf fonction de freqs (à corriger)
##                        drift_force[i,:] = wf.makeDrFo(eta_t,freqVO,specVO,phaseVector,qtf)
##        else:
##            print('Wave time series option not compatible with Molin formulation. No wave drift forces\n')

    
# Plot the drift excitation forces for verification.
# Set interactive
    repons = input('Do you want plots of Drift excitation forces?: Yes or No (default: No)\n')
    if repons !='':
        repons = str(repons)
    else:
        repons = 'No'

    if repons == 'Yes':
        Ecrit = np.zeros(6).astype(np.str)
        Ecrit = ['Surge','Sway','Heave', 'Roll','Pitch','Yaw']
        for i in range(6):
            if all(0 == a for a in drift_force[i,:]) is False:
                try:      
                    plt.interactive(True)
                    plt.figure()
                    plt.plot(drift_force_t[i,:],drift_force[i,:],'r-',label=Ecrit[i])
                    plt.xlabel('Time (s)')
                    if i<3: plt.ylabel('Drift force (N)')
                    if i>=3: plt.ylabel('Drift force (N.m)')
                    plt.grid(True)
                    plt.legend()
                    plt.title('Drift excitation force')
                except:
                    pass
# Writing drift forces in a txt file
    with open('drift_for.txt','w') as f:
        ndt = len(eta_t)
        #print(ndt)
        np.savetxt(f,[ndt],fmt='%.1i')
        for i in range(6):
#            if all(0 == a for a in drift_force[i,:]) is False:
                np.savetxt(f,[i],fmt='%.1i')
                for irow in range(ndt):
                    tmpa = drift_force_t[i,irow]
                    tmpb = drift_force[i,irow]
                    np.savetxt(f,[(tmpa,tmpb)],fmt='%.6e')
