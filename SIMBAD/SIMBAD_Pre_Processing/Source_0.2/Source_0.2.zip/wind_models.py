##  This file is part of SIMBAD pre-processing program.

##  SIMBAD pre-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD pre-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD pre-processing program.
##  If not, see <https://www.gnu.org/licenses/>.



"""
Wind spectrum module
-------------

Model spectra
-------------
Davenport    - Davenport spectral density
Harris       - Harris spectral density
Kaimal       - Kaimal spectral density
API          - API spectral density
NPD          - NPD spectral density
Ochi-Shin    - Ochi-Shin spectrum model

"""

import warnings
import math as mt
import numpy as np


class WindSpectrum(object):
    type = 'WindSpectrum'

    def __init__(self, U10=0.0):
        self.U10 = U10

    def freq(self, wmin=0.001, wmax=0.5, nw=400):
        """
        Return vector of angular frequencies from WindSpectrum

        Parameter
        ---------
        wmin : scalar
               minimum cut off frequency
        wmax : scalar
               maximum cut off frequency
        nw :   int
               number of frequencies

        Returns
        -------
        w : arraylike
            vector of angular frequencies used in discretization of spectrum
        ---
        """

        w = np.linspace(wmin, wmax, nw)
        return w

    def chk_windstate(self):
        """ Check if windstate is valid
        """

        if self.U10 < 0:
            raise ValueError('U10 can not be negative!')

        if self.U10 == 0.0:
            warnings.warn('U10 is zero!')


class Davenport(WindSpectrum):

    """
    Davenport spectral density model

    Member variables
    ----------------
    U10 : 10 minutes mean wind velocity at 10m height [m/s]
    w : array-like
        angular frequencies [Hz]

    Returns
    -------
    SD: Davenport spectrum [m2/s2/Hz]
    
    The Davenport spectrum is defined as

         SD(w) = G(f)*U10**2/w
    where:
         G(f)  = Gust factor = 4*Cd*f**2/(1+f**2)**4/3
         f     = w*Lv/U10 Normalized frequency
         Lv    = representative length scale [1200 m]
         Cd    = sea surface drag coefficient = 0.00104 + 0.0015/(1+exp(-(U10-12.5)/1.564))   
         w     = frequency [Hz]

    """

    type = 'Davenport'

    def __init__(self, U10=0.0, Lv=1200.0, chk_windstate=True):
        super(Davenport, self).__init__(U10)
        self.Lv = Lv

        if chk_windstate:
            self.chk_windstate()

    def spectre(self):
        """ Return Davenport spectrum
        """
        w = self.freq()
        Cd = 0.003
        #Cd = 0.00104 + 0.0015/(1+mt.exp(-(self.U10-12.5)/1.564))
        if self.U10 > 0:
            f = w*self.Lv/self.U10
            G = 4*Cd*f**2/(1+f**2)**(4/3)
            SD = G*(self.U10**2)/w           
        else:
            SD = np.zeros_like(w)
        return SD

class Harris(WindSpectrum):

    """
    Harris spectral density model

    Member variables
    ----------------
    U10 : 10 minutes mean wind velocity at 10m height [m/s]
    w : array-like
        angular frequencies [Hz]

    Returns
    -------
    SH: Harris spectrum [m2/s2/Hz]
    
    The Harris spectrum is defined as

         SH(w) = G(f)*U10**2/w
    where:
         G(f)  = Gust factor = 4*Cd*f/(2+f**2)**5/6
         f     = w*Lv/U10 Normalized frequency
         Lv    = representative length scale [1800 m]
         Cd    = sea surface drag coefficient = 0.003   
         w     = frequency [Hz]

    """

    type = 'Harris'

    def __init__(self, U10=0.0, Lv=1800.0, chk_windstate=True):
        super(Harris, self).__init__(U10)
        self.Lv = Lv

        if chk_windstate:
            self.chk_windstate()

    def spectre(self):
        """ Return Harris spectrum
        """
        w = self.freq()
        Cd = 0.0025
        if self.U10 > 0:
            f = w*self.Lv/self.U10
            G = 4*Cd*f/(2+f**2)**(5/6)
            SH = G*(self.U10**2)/w           
        else:
            SH = np.zeros_like(w)
        return SH

class Kaimal(WindSpectrum):

    """
    Kaimal spectral density model

    Member variables
    ----------------
    U10 : 10 minutes mean wind velocity at 10m height [m/s]
    w : array-like
        angular frequencies [Hz]

    Returns
    -------
    SK: Kaimal spectrum [m2/s2/Hz]
    
    The Kaimal spectrum is defined as

         SK(w) = G(f)*sigv**2/w
    where:
         G(f)  = Gust factor = A*f/(1+B*f)**5/3
         f     = w*10/U10 Normalized frequency
         sigv  = velocity RMS = 0.16 to 0.165* U10  
         w     = frequency [Hz]

    """

    type = 'Kaimal'

    def __init__(self, U10=0.0, chk_windstate=True):
        super(Kaimal, self).__init__(U10)

        if chk_windstate:
            self.chk_windstate()

    def spectre(self):
        """ Return Kaimal spectrum
        """
        w = self.freq()
        sigv = 0.15*self.U10
        if self.U10 > 0:
            f = w*10.0/self.U10
            G = 33.3*f/(1+50.0*f)**(5/3)
            SK = G*(sigv**2)/w           
        else:
            SK = np.zeros_like(w)
        return SK

class API(WindSpectrum):

    """
    API spectral density model

    Member variables
    ----------------
    U10 : 10 minutes mean wind velocity at 10m height [m/s]
    U0  : 1 hour mean wind velocity at 10m height [m/s]
    w   : array-like
          angular frequencies [Hz]

    Returns
    -------
    SA: API spectrum [m2/s2/Hz]
    
    The API spectrum is defined as

         SA(w) = G(f)*sigv**2/w
    where:
         G(f)  = Gust factor = A*f/(1+B*f)**5/3
         f     = w*10/U10 Normalized frequency
         sigv  = velocity RMS = 0.15*(10/20)**-0.125* U10  
         w     = frequency [Hz]

    """

    type = 'API'

    def __init__(self, U10=0.0, chk_windstate=True):
        super(API, self).__init__(U10)

        if chk_windstate:
            self.chk_windstate()

    def spectre(self):
        """ Return API spectrum
        """
        w = self.freq()
        # Determination of mean hour wind speed
        A = 0.41*0.06*np.log(1/6)
        B = A*0.043
        U0 = (A-1 + np.sqrt((1-A)**2-4*B*self.U10))/(-2*B)
        sigv = 0.15*(0.5**(-0.125))*U0
        if U0 > 0:
            f = w*10.0/U0
            G = 40.0*f/(1+60.0*f)**(5/3)
            SA = G*(sigv**2)/w           
        else:
            SA = np.zeros_like(w)
        return SA

class NPD(WindSpectrum):

    """
    NPD spectral density model

    Member variables
    ----------------
    U10 : 10 minutes mean wind velocity at 10m height [m/s]
    U0  : 1 hour mean wind velocity at 10m height [m/s]
    w   : array-like
          angular frequencies [Hz]

    Returns
    -------
    SN: NPD spectrum [m2/s2/Hz]
    
    The NPD spectrum is defined as

         SN(w) = G(f)*(U0/10)**2
    where:
         G(f)  = Gust factor = A/(1+f**n)**5/(3*n)
         f     = w*B*(U0/10)**-3/4 Normalized frequency
         w     = frequency [Hz]

    """

    type = 'NPD'

    def __init__(self, U10=0.0, chk_windstate=True):
        super(NPD, self).__init__(U10)

        if chk_windstate:
            self.chk_windstate()

    def spectre(self):
        """ Return NPD spectrum
        """
        w = self.freq()
        nw = len(w)
        # Determination of mean hour wind speed
        A = 0.41*0.06*np.log(1/6)
        B = A*0.043
        U0 = (A-1 + np.sqrt((1-A)**2-4*B*self.U10))/(-2*B)
        n = 5/(3*0.468)
        if U0 > 0:
            f = w*172.0*(U0/10)**(-3/4)
            G = 320.0/(1+f**0.468)**n
            SN = G*(U0/10)**2
            # Spectrum is 0 above 0.5 Hz and limited below 1/600 Hz
            for iw in range(0,nw):
                if w[iw] > 0.5:
                    SN[iw] = 0.0
                if w[iw] < 0.001666:
                    w[iw] = 1/600
                    f[iw] = w[iw]*172.0*(U0/10)**(-3/4)
                    G[iw] = 320.0/(1+f[iw]**0.468)**n
                    SN[iw] = G[iw]*(U0/10)**2
        else:
            SN = np.zeros_like(w)
        return SN

class Ochi_Shin(WindSpectrum):

    """
    Ochi-Shin spectral density model

    Member variables
    ----------------
    U10 : 10 minutes mean wind velocity at 10m height [m/s]
    U0  : 1 hour mean wind velocity at 10m height [m/s]
    w   : array-like
          angular frequencies [Hz]

    Returns
    -------
    SOS: Ochi-Shin spectrum [m2/s2/Hz]
    
    The Ochi-Shin spectrum is defined as

         SOS(w) = G(f)*Cd*U0**2/w
    where:
         G(f)  = Gust factor = 583*f (0<= f <=0.003)
         G(f)  = Gust factor = A*f**n/(1+f**0.35)**11.5 (A=420, n=0.7 for 0.003<= f <=0.1)
         G(f)  = Gust factor = A*f**n/(1+f**0.35)**11.5 (A=838, n=1 for 0.1<= f)
         f     = w*10/U0 Normalized frequency
         w     = frequency [Hz]

    """

    type = 'Ochi-Shin'

    def __init__(self, U10=0.0, chk_windstate=True):
        super(Ochi_Shin, self).__init__(U10)

        if chk_windstate:
            self.chk_windstate()

    def spectre(self):
        """ Return Ochi_Shin spectrum
        """
        w = self.freq()
        nw = len(w)
        # Determination of mean hour wind speed
        A = 0.41*0.06*np.log(1/6)
        B = A*0.043
        U0 = (A-1 + np.sqrt((1-A)**2-4*B*self.U10))/(-2*B)
        f = w*10/U0
        SOS = np.zeros(nw).astype(np.float)
        Cd = (750+69*U0)*1E-6
        if U0 > 0:
            for iw in range(0,nw):
                if w[iw] <= 0.003:
                    G = 583.0*Cd*f[iw]
                    SOS[iw] = G*U0**2/w[iw]
                elif 0.003 < w[iw] <= 0.1:
                    G = 420.0*Cd*f[iw]**0.7/(1+f[iw]**0.35)**11.5
                    SOS[iw] = G*U0**2/w[iw]
                elif 0.1 < w[iw]:
                    G = 838.0*Cd*f[iw]/(1+f[iw]**0.35)**11.5
                    SOS[iw] = G*U0**2/w[iw]
        else:
            SOS = np.zeros_like(w)
        return SOS

def makePhase(t,f):
    # Frequency step
    deltaf = 2*np.pi/t[-1]
    # With the seed reset (every time), the same set of numbers will appear every time
    # Otherwise do not use seed or with no argument seed()
    np.random.seed()
    nf = int(mt.ceil(f[-1]/deltaf))
    phaseVector = np.zeros(nf).astype(np.float)
    phaseVector = 2*np.pi*np.random.random(nf)
    return phaseVector

def makeWindx(t,f,S,phase):
    # Make new frequencies and spectrum, with interpolated values
    deltaf = 2*np.pi/t[-1] # Frequency step
    nf = int(mt.ceil(f[-1]/deltaf))
    f_new = np.linspace(f[0],f[-1],nf)
    S = np.interp(f_new,f,S)
    
    # Pre allocation
    zta = np.sqrt(2*S*deltaf/(2*np.pi))
    wave = np.zeros((len(t),len(f_new)))
    phase = list(reversed(phase)) 

    # Loop over all frequencies
    for iF in range(0,len(f_new)):
        wave[:,iF] = zta[iF]*np.cos(f_new[iF]*t + phase[iF])
    # Sum over all frequencies
    tot_wave = np.sum(wave,axis=1)    
    return tot_wave

def _test_some_spectra():

    import matplotlib.pyplot as plt

    S1 = Davenport(U10=17.0)
    S2 = Harris(U10=17.0)
    S3 = Kaimal(U10=17.0)
    S4 = API(U10=17.0)
    S5 = NPD(U10=17.0)
    S6 = Ochi_Shin(U10=17.0)
    SD = S1.spectre()
    SH = S2.spectre()
    SK = S3.spectre()
    SA = S4.spectre()
    SN = S5.spectre()
    SOS = S6.spectre()
    w = S1.freq()
    plt.xlim(0,0.1)
##    plt.plot(w, SD, w, SH, w, SK, w, SA, w, SN, w, SOS)
    plt.plot(w, SH, w, SD)
    plt.grid(True)
    plt.show()
    plt.close()



def main():
    if True:
        _test_some_spectra()

    else:
        test_docstrings()


if __name__ == '__main__':
    main()
