##  This file is part of SIMBAD pre-processing program.

##  SIMBAD pre-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD pre-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD pre-processing program.
##  If not, see <https://www.gnu.org/licenses/>.

# Import modules
from numpy import exp,array,savetxt
from lmfit import Model


def expon_fit(x, a, b):
    """exponential a.exp(b.omega)"""
    return (a*exp(b*x))


def raddamp_fit(x,y,i,j,indic):
    """
    Extension and fitting of radiation damping data to an exponential curve

    Parameters
    ----------
    x : array
        independent variable 
    y(x): array
        dependent variable

    Returns
    -------
    Fitted signal : array
        The fitted signal. Same length as y array.
    """

    gmodel = Model(expon_fit)
    result = gmodel.fit(y, x=x, a=y[0], b=1)

    y_fit = result.best_fit

    #print(result.fit_report())

    #print(result.params)
    a = result.params['a']
    b = result.params['b']
    
    #print(expon_fit(50,a,b))

    if indic ==0:
        with open('Rad_Fit.txt','w') as fid:
            tmp = array([i,j])
            savetxt(fid,[tmp],fmt='%.1i')
            tmp = array([a,b])
            savetxt(fid,[tmp],fmt='%.7e')
    else:
        with open('Rad_Fit.txt','a') as fid:
            tmp = array([i,j])
            savetxt(fid,[tmp],fmt='%.1i')
            tmp = array([a,b])
            savetxt(fid,[tmp],fmt='%.7e')
    fid.close()

    return y_fit
