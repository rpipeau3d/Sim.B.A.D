# This file is an adaptation of one file of the Wafo software
# (see https://pypi.org/project/wafo/)

# WAFO is free software; it can be redistributed and/or modified under the terms
# of the GNU General Public License (GPL version 3 of the License)
# as published by the Free Software Foundation 
# WAFO is distributed WITHOUT ANY WARRANTY;
# without even the implied warranty of MERCHANTABILITY
# or FITNESS FOR A PARTICULAR PURPOSE. 

#!/usr/bin/env python
"""
Models module
-------------

Dispersion relation
-------------------
k2w - Translates from wave number to frequency
w2k - Translates from frequency to wave number

Model spectra
-------------
Bretschneider    - Bretschneider spectral density.
Jonswap          - JONSWAP spectral density
McCormick        - McCormick spectral density.
OchiHubble       - OchiHubble bimodal spectral density model.
Tmaspec          - JONSWAP spectral density for finite water depth
Torsethaugen     - Torsethaugen  double peaked (swell + wind) spectrum model
Wallop           - Wallop spectral density.
demospec         - Loads a precreated spectrum of chosen type
jonswap_peakfact - Jonswap peakedness factor Gamma given Hm0 and Tp

"""

import warnings
#from scipy.interpolate import interp1d
import scipy.optimize as optimize
import scipy.integrate as integrate
import scipy.special as sp
#from scipy.fftpack import fft
import numpy as np
from numpy import (inf, atleast_1d, newaxis, minimum, maximum, array,
                   asarray, exp, log, sqrt, where, pi, arange, linspace, sin,
                   cos, sinh, isfinite, mod, expm1, tanh, cosh, finfo,
                   ones, ones_like, isnan, zeros_like, flatnonzero, sinc,
                   hstack, vstack, real, flipud, clip,sign)


__all__ = ['Bretschneider', 'Jonswap', 'Torsethaugen', 'Wallop', 'McCormick',
           'OchiHubble', 'Tmaspec', 'jonswap_peakfact', 'w2k', 'k2w', 'phi1']

_EPS = finfo(float).eps


def sech(x):
    return 1.0 / cosh(x)


def _gengamspec(wn, N=5, M=4):
    """ Return Generalized gamma spectrum in dimensionless form

    Parameters
    ----------
    wn : arraylike
        normalized frequencies, w/wp.
    N  : scalar
        defining the decay of the high frequency part.
    M  : scalar
        defining the spectral width around the peak.

    Returns
    -------
    S   : arraylike
        spectral values, same size as wn.

    The generalized gamma spectrum in non-
    dimensional form is defined as:

      S = G0.*wn.**(-N).*exp(-B*wn.**(-M))  for wn > 0
        = 0                              otherwise
    where
        B  = N/M
        C  = (N-1)/M
        G0 = B**C*M/gamma(C), Normalizing factor related to Bretschneider form

    Note that N = 5, M = 4 corresponds to a normalized
    Bretschneider spectrum.

    Examples
    --------
    >>> import wafo.spectrum.models as wsm
    >>> import numpy as np
    >>> wn = np.linspace(0,4,5)
    >>> wsm._gengamspec(wn, N=6, M=2)
    array([ 0.        ,  1.16765216,  0.17309961,  0.02305179,  0.00474686])

    See also
    --------
    Bretschneider
    Jonswap,
    Torsethaugen


    References
    ----------
    Torsethaugen, K. (2004)
    "Simplified Double Peak Spectral Model for Ocean Waves"
    In Proc. 14th ISOPE
    """
    w = atleast_1d(wn)
    S = zeros_like(w)

    k = flatnonzero(w > 0.0)
    if k.size > 0:
        B = N / M
        C = (N - 1.0) / M

        # A = Normalizing factor related to Bretschneider form
        # A = B**C*M/gamma(C)
        # S[k] = A*wn[k]**(-N)*exp(-B*wn[k]**(-M))
        logwn = log(w.take(k))
        logA = (C * log(B) + log(M) - sp.gammaln(C))  #pylint: disable=no-member
        S.put(k, exp(logA - N * logwn - B * exp(-M * logwn)))
    return S


class ModelSpectrum(object):
    type = 'ModelSpectrum'

    def __init__(self, Hm0=7.0, Tp=11.0, **kwds):  # @UnusedVariable
        self.Hm0 = Hm0
        self.Tp = Tp

    def tospecdata(self, w=None, wc=None, nw=257):
        """
        Return SpecData1D object from ModelSpectrum

        Parameter
        ---------
        w : arraylike
            vector of angular frequencies used in discretization of spectrum
        wc : scalar
            cut off frequency (default 33/Tp)
        nw : int
            number of frequencies

        Returns
        -------
        ---
        """

        if w is None:
            if wc is None:
                wc = 33. / self.Tp
            w = linspace(0, wc, nw)

    def chk_seastate(self):
        """ Check if seastate is valid
        """

        if self.Hm0 < 0:
            raise ValueError('Hm0 can not be negative!')

        if self.Tp <= 0:
            raise ValueError('Tp must be positve!')

        if self.Hm0 == 0.0:
            warnings.warn('Hm0 is zero!')

        self._chk_extra_param()

    def _chk_extra_param(self):
        pass

    def __call__(self, w):
        raise NotImplementedError


class Bretschneider(ModelSpectrum):

    """
    Bretschneider spectral density model

    Member variables
    ----------------
    Hm0 : significant wave height (default 7 (m))
    Tp  : peak period             (default 11 (sec))
    N   : scalar defining decay of high frequency part.   (default 5)
    M   : scalar defining spectral width around the peak. (default 4)

    Parameters
    ----------
    w : array-like
        angular frequencies [rad/s]


    The Bretschneider spectrum is defined as

         S(w) = A * G0 * wn**(-N)*exp(-N/(M*wn**M))
    where
         G0  = Normalizing factor related to Bretschneider form
         A   = (Hm0/4)**2 / wp     (Normalization factor)
         wn  = w/wp
         wp  = 2*pi/Tp,  angular peak frequency

    This spectrum is a suitable model for fully developed sea,
    i.e. a sea state where the wind has been blowing long enough over a
    sufficiently open stretch of water, so that the high-frequency waves have
    reached an equilibrium. In the part of the spectrum where the frequency is
    greater than the peak frequency (w>wp), the energy distribution is
    proportional to w**-5.
    The spectrum is identical with ITTC (International Towing Tank
    Conference), ISSC (International Ship and Offshore Structures Congress)
    and Pierson-Moskowitz, wave spectrum given Hm0 and Tm01. It is also
    identical with JONSWAP when the peakedness factor, gamma, is one.
    For this spectrum, the following relations exist between the mean
    period Tm01 = 2*pi*m0/m1, the peak period Tp and the mean
    zero-upcrossing period Tz:

           Tm01 = 1.086*Tz, Tp = 1.408*Tz and Tp=1.2965*Tm01

    Examples
    --------
    >>> import wafo.spectrum.models as wsm
    >>> S = wsm.Bretschneider(Hm0=6.5,Tp=10)
    >>> S((0,1,2,3))
    array([ 0.        ,  1.69350993,  0.06352698,  0.00844783])

    See also
    --------
    Jonswap,
    Torsethaugen
    """

    type = 'Bretschneider'

    def __init__(self, Hm0=7.0, Tp=11.0, N=5, M=4, chk_seastate=True, **kwds):
        super(Bretschneider, self).__init__(Hm0, Tp)
        self.N = N
        self.M = M

        if chk_seastate:
            self.chk_seastate()

    def __call__(self, wi):
        """ Return Bretschnieder spectrum
        """
        w = atleast_1d(wi)
        if self.Hm0 > 0:
            wp = 2 * pi / self.Tp
            wn = w / wp
            S = (self.Hm0 / 4.0) ** 2 / wp * _gengamspec(wn, self.N, self.M)
        else:
            S = zeros_like(w)
        return S


def jonswap_peakfact(Hm0, Tp):
    """ Jonswap peakedness factor, gamma, given Hm0 and Tp

    Parameters
    ----------
    Hm0 : significant wave height [m].
    Tp  : peak period [s]

    Returns
    -------
    gamma : Peakedness parameter of the JONSWAP spectrum

    Details
    -------
    A standard value for GAMMA is 3.3. However, a more correct approach is
    to relate GAMMA to Hm0 and Tp:
         D = 0.036-0.0056*Tp/sqrt(Hm0)
        gamma = exp(3.484*(1-0.1975*D*Tp**4/(Hm0**2)))
    This parameterization is based on qualitative considerations of deep water
    wave data from the North Sea, see Torsethaugen et. al. (1984)
    Here GAMMA is limited to 1..7.

    NOTE: The size of GAMMA is the common shape of Hm0 and Tp.

    Examples
    --------
    >>> import wafo.spectrum.models as wsm
    >>> import numpy as np
    >>> Tp,Hs = np.meshgrid(range(4,8),range(2,6))
    >>> gam = wsm.jonswap_peakfact(Hs,Tp)

    >>> Hm0 = np.linspace(1,20)
    >>> Tp = Hm0
    >>> [T,H] = np.meshgrid(Tp,Hm0)
    >>> gam = wsm.jonswap_peakfact(H,T)
    >>> v = np.arange(0,8)

    >>> Hm0 = np.arange(1,11)
    >>> Tp  = np.linspace(2,16)
    >>> T,H = np.meshgrid(Tp,Hm0)
    >>> gam = wsm.jonswap_peakfact(H,T)

    import matplotlib.pyplot as plt
    h = plt.contourf(Tp,Hm0,gam,v);h=plb.colorbar()
    h = plt.plot(Tp,gam.T)
    h = plt.xlabel('Tp [s]')
    h = plt.ylabel('Peakedness parameter')

    plt.close('all')

    See also
    --------
    jonswap
    """
    Hm0, Tp = atleast_1d(Hm0, Tp)

    x = Tp / sqrt(Hm0)

    gam = ones_like(x)

    k1 = flatnonzero(x <= 5.14285714285714)
    if k1.size > 0:  # limiting gamma to [1 7]
        xk = x.take(k1)
        D = 0.036 - 0.0056 * xk  # approx 5.061*Hm0**2/Tp**4*(1-0.287*log(gam))
        # gamma
        gam.put(k1, minimum(exp(3.484 * (1.0 - 0.1975 * D * xk ** 4.0)), 7.0))

    return gam

class Jonswap(ModelSpectrum):

    """
    Jonswap spectral density model

    Member variables
    ----------------
    Hm0    : significant wave height (default 7 (m))
    Tp     : peak period             (default 11 (sec))
    gamma  : peakedness factor determines the concentraton
            of the spectrum on the peak frequency.
            Usually in the range  1 <= gamma <= 7.
            default depending on Hm0, Tp, see jonswap_peakedness)
    sigmaA : spectral width parameter for w<wp (default 0.07)
    sigmaB : spectral width parameter for w<wp (default 0.09)
    Ag     : normalization factor used when gamma>1:
    N      : scalar defining decay of high frequency part.   (default 5)
    M      : scalar defining spectral width around the peak. (default 4)
    method : String defining method used to estimate Ag when gamma>1
            'integration': Ag = 1/gaussq(Gf*ggamspec(wn,N,M),0,wnc) (default)
            'parametric' : Ag = (1+f1(N,M)*log(gamma)**f2(N,M))/gamma
            'custom'     : Ag = Ag
    wnc    : wc/wp normalized cut off frequency used when calculating Ag
                by integration (default 6)
    Parameters
    ----------
    w : array-like
        angular frequencies [rad/s]

    Description
    -----------
     The JONSWAP spectrum is defined as

             S(w) = A * Gf * G0 * wn**(-N)*exp(-N/(M*wn**M))
        where
             G0  = Normalizing factor related to Bretschneider form
             A   = Ag * (Hm0/4)**2 / wp     (Normalization factor)
             Gf  = j**exp(-.5*((wn-1)/s)**2) (Peak enhancement factor)
             wn  = w/wp
             wp  = angular peak frequency
             s   = sigmaA      for wn <= 1
                   sigmaB      for 1  <  wn
             j   = gamma,     (j=1, => Bretschneider spectrum)

    The JONSWAP spectrum is assumed to be especially suitable for the North
    Sea, and does not represent a fully developed sea. It is a reasonable model
    for wind generated sea when the seastate is in the so called JONSWAP range,
    i.e., 3.6*sqrt(Hm0) < Tp < 5*sqrt(Hm0)

    The relation between the peak period and mean zero-upcrossing period
    may be approximated by
             Tz = Tp/(1.30301-0.01698*gamma+0.12102/gamma)

    Examples
    --------
    >>> import matplotlib.pyplot as plt
    >>> import wafo.spectrum.models as wsm
    >>> S = wsm.Jonswap(Hm0=7, Tp=11,gamma=1)
    >>> S2 = wsm.Bretschneider(Hm0=7, Tp=11)
    >>> w = np.linspace(0,5)
    >>> all(np.abs(S(w)-S2(w))<1.e-7)
    True

    h = plt.plot(w,S(w))
    plt.close('all')

    See also
    --------
    Bretschneider
    Tmaspec
    Torsethaugen


    References
    -----------
    Torsethaugen et al. (1984)
    "Characteristica for extreme Sea States on the Norwegian continental shelf."
    Report No. STF60 A84123. Norwegian Hydrodyn. Lab., Trondheim

     Hasselmann et al. (1973)
     Measurements of Wind-Wave Growth and Swell Decay during the Joint
     North Sea Project (JONSWAP).
     Ergansungsheft, Reihe A(8), Nr. 12, Deutschen Hydrografischen Zeitschrift.
    """

    type = 'Jonswap'

    def __init__(self, Hm0=7.0, Tp=11.0, gamma=None, sigmaA=0.07, sigmaB=0.09,
                 Ag=None, N=5, M=4, method='integration', wnc=6.0,
                 chk_seastate=True):
        super(Jonswap, self).__init__(Hm0, Tp)
        self.N = N
        self.M = M
        self.sigmaA = sigmaA
        self.sigmaB = sigmaB
        self.gamma = gamma
        self.Ag = Ag
        self.method = method
        self.wnc = wnc

        if self.gamma is None or not isfinite(self.gamma) or self.gamma < 1:
            self.gamma = jonswap_peakfact(Hm0, Tp)

        self._pre_calculate_ag()

        if chk_seastate:
            self.chk_seastate()

    def _chk_extra_param(self):
        Tp = self.Tp
        Hm0 = self.Hm0
        gam = self.gamma
        outsideJonswapRange = Tp > 5 * sqrt(Hm0) or Tp < 3.6 * sqrt(Hm0)
        if outsideJonswapRange:
            txt0 = """
            Hm0=%g,Tp=%g is outside the JONSWAP range.
            The validity of the spectral density is questionable.
            """ % (Hm0, Tp)
            warnings.warn(txt0)

        if gam < 1 or 7 < gam:
            txt = """
            The peakedness factor, gamma, is possibly too large.
            The validity of the spectral density is questionable.
            """
            warnings.warn(txt)

    def _localspec(self, wn):
        Gf = self.peak_e_factor(wn)
        return Gf * _gengamspec(wn, self.N, self.M)

    def _check_parametric_ag(self, N, M, gammai):
        parameters_ok = 3 <= N <= 50 or 2 <= M <= 9.5 and 1 <= gammai <= 20
        if not parameters_ok:
            raise ValueError('Not knowing the normalization because N, ' +
                             'M or peakedness parameter is out of bounds!')
        if self.sigmaA != 0.07 or self.sigmaB != 0.09:
            warnings.warn('Use integration to calculate Ag when ' + 'sigmaA!=0.07 or sigmaB!=0.09')

    def _parametric_ag(self):
        """
        Original normalization

        NOTE: that  Hm0**2/16 generally is not equal to intS(w)dw
              with this definition of Ag if sa or sb are changed from the
              default values
        """
        self.method = 'parametric'

        N = self.N
        M = self.M
        gammai = self.gamma
        f1NM = 4.1 * (N - 2 * M ** 0.28 + 5.3) ** (-1.45 * M ** 0.1 + 0.96)
        f2NM = ((2.2 * M ** (-3.3) + 0.57) * N ** (-0.58 * M ** 0.37 + 0.53) -
                1.04 * M ** (-1.9) + 0.94)
        self.Ag = (1 + f1NM * log(gammai) ** f2NM) / gammai
        # if N == 5 && M == 4,
        #     options.Ag = (1+1.0*log(gammai).**1.16)/gammai
        #     options.Ag = (1-0.287*log(gammai))
        #     options.normalizeMethod = 'Three'
        # elseif  N == 4 && M == 4,
        #     options.Ag = (1+1.1*log(gammai).**1.19)/gammai

        self._check_parametric_ag(N, M, gammai)

    def _custom_ag(self):
        self.method = 'custom'
        if self.Ag <= 0:
            raise ValueError('Ag must be larger than 0!')

    def _integrate_ag(self):
        # normalizing by integration
        self.method = 'integration'
        if self.wnc < 1.0:
            raise ValueError('Normalized cutoff frequency, wnc, ' +
                             'must be larger than one!')
        area1, unused_err1 = integrate.quad(self._localspec, 0, 1)
        area2, unused_err2 = integrate.quad(self._localspec, 1, self.wnc)
        area = area1 + area2
        self.Ag = 1.0 / area

    def _pre_calculate_ag(self):
        """ PRECALCULATEAG Precalculate normalization.
        """
        if self.gamma == 1:
            self.Ag = 1.0
            self.method = 'parametric'
        elif self.Ag is not None:
            self._custom_ag()
        else:
            norm_ag = dict(i=self._integrate_ag,
                           p=self._parametric_ag,
                           c=self._custom_ag)[self.method[0]]
            norm_ag()

    def peak_e_factor(self, wn):
        """ PEAKENHANCEMENTFACTOR
        """
        w = maximum(atleast_1d(wn), 0.0)
        sab = where(w > 1, self.sigmaB, self.sigmaA)

        wnm12 = 0.5 * ((w - 1.0) / sab) ** 2.0
        Gf = self.gamma ** (exp(-wnm12))
        return Gf

    def __call__(self, wi):
        """ JONSWAP spectral density
        """
        w = atleast_1d(wi)
        if (self.Hm0 > 0.0):

            N = self.N
            M = self.M
            wp = 2 * pi / self.Tp
            wn = w / wp
            Ag = self.Ag
            Hm0 = self.Hm0
            Gf = self.peak_e_factor(wn)
            S = ((Hm0 / 4.0) ** 2 / wp * Ag) * Gf * _gengamspec(wn, N, M)
        else:
            S = zeros_like(w)
        return S


def phi1(wi, h, g=9.81):
    """ Factor transforming spectra to finite water depth spectra.

    Input
    -----
         w : arraylike
            angular frequency [rad/s]
         h : scalar
            water depth [m]
         g : scalar
            acceleration of gravity [m/s**2]
    Returns
    -------
        tr : arraylike
            transformation factors

    Examples
    --------
    Transform a JONSWAP spectrum to a spectrum for waterdepth = 30 m
    >>> import wafo.spectrum.models as wsm
    >>> S = wsm.Jonswap()
    >>> w = np.arange(3.0)
    >>> S(w)*wsm.phi1(w,30.0)
    array([ 0.        ,  1.0358056 ,  0.03796281])


    References
    ----------
    Buows, E., Gunther, H., Rosenthal, W. and Vincent, C.L. (1985)
     'Similarity of the wind wave spectrum in finite depth water:
     1 spectral form.'
      J. Geophys. Res., Vol 90, No. C1, pp 975-986

    """
    w = atleast_1d(wi)
    if h == inf:  # % special case infinite water depth
        return ones_like(w)

    k1 = w2k(w, 0, inf, g=g)[0]
    dw1 = 2.0 * w / g  # % dw/dk|h=inf
    k2 = w2k(w, 0, h, g=g)[0]

    k2h = k2 * h
    den = where(k1 == 0, 1, (tanh(k2h) + k2h / cosh(k2h) ** 2.0))
    dw2 = where(k1 == 0, 0, dw1 / den)  # dw/dk|h=h0
    return where(k1 == 0, 0, (k1 / k2) ** 3.0 * dw2 / dw1)


class Tmaspec(Jonswap):

    """ JONSWAP spectrum for finite water depth

    Member variables
    ----------------
     h     = water depth             (default 42 [m])
     g     : acceleration of gravity [m/s**2]
     Hm0   = significant wave height (default  7 [m])
     Tp    = peak period (default 11 (sec))
     gamma = peakedness factor determines the concentraton
              of the spectrum on the peak frequency.
              Usually in the range  1 <= gamma <= 7.
              default depending on Hm0, Tp, see getjonswappeakedness)
     sigmaA = spectral width parameter for w<wp (default 0.07)
     sigmaB = spectral width parameter for w<wp (default 0.09)
     Ag     = normalization factor used when gamma>1:
     N      = scalar defining decay of high frequency part.   (default 5)
     M      = scalar defining spectral width around the peak. (default 4)
     method = String defining method used to estimate Ag when gamma>1
             'integrate' : Ag = 1/gaussq(Gf.*ggamspec(wn,N,M),0,wnc) (default)
              'parametric': Ag = (1+f1(N,M)*log(gamma)^f2(N,M))/gamma
              'custom'    : Ag = Ag
     wnc    = wc/wp normalized cut off frequency used when calculating Ag
               by integration (default 6)
    Parameters
    ----------
    w : array-like
        angular frequencies [rad/s]

    Description
    ------------
    The evaluated spectrum is
         S(w) = Sj(w)*phi(w,h)
    where
         Sj  = jonswap spectrum
         phi = modification due to water depth

    The concept is based on a similarity law, and its validity is verified
    through analysis of 3 data sets from: TEXEL, MARSEN projects (North
    Sea) and ARSLOE project (Duck, North Carolina, USA). The data include
    observations at water depths ranging from 6 m to 42 m.

    Examples
    --------
    >>> import wafo.spectrum.models as wsm
    >>> import numpy as np
    >>> w = np.linspace(0,2.5)
    >>> S = wsm.Tmaspec(h=10,gamma=1) # Bretschneider spectrum Hm0=7, Tp=11

    import matplotlib.pyplot as plt
    o=plt.plot(w,S(w))
    o=plt.plot(w,S(w,h=21))
    o=plt.plot(w,S(w,h=42))
    plt.show()
    plt.close('all')

    See also
    ---------
    Bretschneider,
    Jonswap,
    phi1,
    Torsethaugen

    References
    ----------
    Buows, E., Gunther, H., Rosenthal, W., and Vincent, C.L. (1985)
    'Similarity of the wind wave spectrum in finite depth water:
    1 spectral form.'
    J. Geophys. Res., Vol 90, No. C1, pp 975-986

    Hasselman et al. (1973)
    Measurements of Wind-Wave Growth and Swell Decay during the Joint
    North Sea Project (JONSWAP).
    Ergansungsheft, Reihe A(8), Nr. 12, deutschen Hydrografischen
    Zeitschrift.

    """

    def __init__(self, Hm0=7.0, Tp=11.0, gamma=None, sigmaA=0.07, sigmaB=0.09,
                 Ag=None, N=5, M=4, method='integration', wnc=6.0,
                 chk_seastate=True, h=42, g=9.81):
        self.g = g
        self.h = h
        super(Tmaspec, self).__init__(Hm0, Tp, gamma, sigmaA, sigmaB, Ag, N,
                                      M, method, wnc, chk_seastate)
        self.type = 'TMA'

    def phi(self, w, h=None, g=None):
        if h is None:
            h = self.h
        if g is None:
            g = self.g
        return phi1(w, h, g)

    def __call__(self, w, h=None, g=None):
        jonswap = super(Tmaspec, self).__call__(w)
        return jonswap * self.phi(w, h, g)


class Torsethaugen(ModelSpectrum):

    """
    Torsethaugen  double peaked (swell + wind) spectrum model

    Member variables
    ----------------
    Hm0   : significant wave height (default 7 (m))
    Tp    : peak period (default 11 (sec))
    wnc   : wc/wp normalized cut off frequency used when calculating Ag
            by integration (default 6)
    method : String defining method used to estimate normalization factors, Ag,
             in the modified JONSWAP spectra when gamma>1
            'integrate' : Ag = 1/quad(Gf.*gengamspec(wn,N,M),0,wnc)
            'parametric': Ag = (1+f1(N,M)*log(gamma)**f2(N,M))/gamma
    Parameters
    ----------
    w : array-like
        angular frequencies [rad/s]

    Description
    -----------
    The double peaked (swell + wind) Torsethaugen spectrum is
    modelled as  S(w) = Ss(w) + Sw(w) where Ss and Sw are modified
    JONSWAP spectrums for swell and wind peak, respectively.
    The energy is divided between the two peaks according
    to empirical parameters, which peak that is primary depends on parameters.
    The empirical parameters are found for classes of Hm0 and Tp,
    originating from a dataset consisting of 20 000 spectra divided
    into 146 different classes of Hm0 and Tp. (Data measured at the
    Statfjord field in the North Sea in a period from 1980 to 1989.)
    The range of the measured  Hm0 and Tp for the dataset
    are from 0.5 to 11 meters and from 3.5 to 19 sec, respectively.

    Preliminary comparisons with spectra from other areas indicate that
    some of the empirical parameters are dependent on geographical location.
    Thus the model must be used with care for other areas than the
    North Sea and sea states outside the area where measured data
    are available.

    Examples
    --------
    >>> import wafo.spectrum.models as wsm
    >>> import numpy as np
    >>> w = np.linspace(0,4)
    >>> S = wsm.Torsethaugen(Hm0=6, Tp=8)

    import matplotlib.pyplot as plt
    h=plt.plot(w,S(w),w,S.wind(w),w,S.swell(w))

    See also
    --------
    Bretschneider
    Jonswap


    References
    ----------
    Torsethaugen, K. (2004)
    "Simplified Double Peak Spectral Model for Ocean Waves"
    In Proc. 14th ISOPE

    Torsethaugen, K. (1996)
    Model for a doubly peaked wave spectrum
    Report No. STF22 A96204. SINTEF Civil and Environm. Engineering, Trondheim

    Torsethaugen, K. (1994)
    'Model for a doubly peaked spectrum. Lifetime and fatigue strength
    estimation implications.'
    International Workshop on Floating Structures in Coastal zone,
    Hiroshima, November 1994.

    Torsethaugen, K. (1993)
    'A two peak wave spectral model.'
    In proceedings OMAE, Glasgow

    """

    type = 'Torsethaugen'

    def __init__(self, Hm0=7, Tp=11, method='integration', wnc=6, gravity=9.81,
                 chk_seastate=True, **kwds):
        super(Torsethaugen, self).__init__(Hm0, Tp)

        self.method = method
        self.wnc = wnc
        self.gravity = gravity
        self.wind = None
        self.swell = None
        if chk_seastate:
            self.chk_seastate()

        self._init_spec()

    def __call__(self, w):
        """ TORSETHAUGEN spectral density
        """
        return self.wind(w) + self.swell(w)

    def _chk_extra_param(self):
        Hm0 = self.Hm0
        Tp = self.Tp
        if Hm0 > 11 or Hm0 > max((Tp / 3.6) ** 2, (Tp - 2) * 12 / 11):
            txt0 = """Hm0 is outside the valid range.
                    The validity of the spectral density is questionable"""
            warnings.warn(txt0)

        if Tp > 20 or Tp < 3:
            txt1 = """Tp is outside the valid range.
                    The validity of the spectral density is questionable"""
            warnings.warn(txt1)

    def _init_spec(self):
        """ Initialize swell and wind part of Torsethaugen spectrum
        """
        monitor = 0
        Hm0 = self.Hm0
        Tp = self.Tp
        gravity1 = self.gravity  # m/s**2

        min = minimum  # @ReservedAssignment
        max = maximum  # @ReservedAssignment

        # The parameter values below are found comparing the
        # model to average measured spectra for the Statfjord Field
        # in the Northern North Sea.
        Af = 6.6  # m**(-1/3)*sec
        AL = 2  # sec/sqrt(m)
        Au = 25  # sec
        KG = 35
        KG0 = 3.5
        KG1 = 1     # m
        r = 0.857  # 6/7
        K0 = 0.5  # 1/sqrt(m)
        K00 = 3.2

        M0 = 4
        B1 = 2  # sec
        B2 = 0.7
        B3 = 3.0  # m
        S0 = 0.08  # m**2*s
        S1 = 3  # m

        # Preliminary comparisons with spectra from other areas indicate that
        # the parameters on the line below can be dependent on geographical
        # location
        A10 = 0.7
        A1 = 0.5
        A20 = 0.6
        A2 = 0.3
        A3 = 6

        Tf = Af * (Hm0) ** (1.0 / 3.0)
        Tl = AL * sqrt(Hm0)   # lower limit
        Tu = Au             # upper limit

        # Non-dimensional scales
        # New call pab April 2005
        El = min(max((Tf - Tp) / (Tf - Tl), 0), 1)  # wind sea
        Eu = min(max((Tp - Tf) / (Tu - Tf), 0), 1)  # Swell

        if Tp < Tf:  # Wind dominated seas
            # Primary peak (wind dominated)
            Nw = K0 * sqrt(Hm0) + K00             # high frequency exponent
            Mw = M0                           # spectral width exponent
            Rpw = min((1 - A10) * exp(-(El / A1) ** 2) + A10, 1)
            Hpw = Rpw * Hm0                      # significant waveheight wind
            Tpw = Tp                           # primary peak period
            # peak enhancement factor
            gammaw = KG * (1 + KG0 * exp(-Hm0 / KG1)) * \
                (2 * pi / gravity1 * Rpw * Hm0 / (Tp ** 2)) ** r
            gammaw = max(gammaw, 1)
            # Secondary peak (swell)
            Ns = Nw                # high frequency exponent
            Ms = Mw                # spectral width exponent
            Rps = sqrt(1.0 - Rpw ** 2.0)
            Hps = Rps * Hm0           # significant waveheight swell
            Tps = Tf + B1
            gammas = 1.0

            if monitor:
                if Rps > 0.1:
                    print('     Spectrum for Wind dominated sea')
                else:
                    print('     Spectrum for pure wind sea')
        else:  # swell dominated seas

            # Primary peak (swell)
            Ns = K0 * sqrt(Hm0) + K00  # high frequency exponent
            Ms = M0  # spectral width exponent
            Rps = min((1 - A20) * exp(-(Eu / A2) ** 2) + A20, 1)
            Hps = Rps * Hm0                      # significant waveheight swell
            Tps = Tp                           # primary peak period
            # peak enhancement factor
            gammas = KG * (1 + KG0 * exp(-Hm0 / KG1)) * \
                (2 * pi / gravity1 * Hm0 / (Tf ** 2)) ** r * (1 + A3 * Eu)
            gammas = max(gammas, 1)

            # Secondary peak (wind)
            Nw = Ns                       # high frequency exponent
            Mw = M0 * (1 - B2 * exp(-Hm0 / B3))   # spectral width exponent
            Rpw = sqrt(1 - Rps ** 2)
            Hpw = Rpw * Hm0                  # significant waveheight wind

            C = (Nw - 1) / Mw
            B = Nw / Mw
            G0w = B ** C * Mw / sp.gamma(C)  # normalizing factor
            # G0w = exp(C*log(B)+log(Mw)-gammaln(C))
            # G0w  = Mw/((B)**(-C)*gamma(C))

            if Hpw > 0:
                Tpw = (16 * S0 * (1 - exp(-Hm0 / S1)) * (0.4) **
                       Nw / (G0w * Hpw ** 2)) ** (-1.0 / (Nw - 1.0))
            else:
                Tpw = inf

            # Tpw  = max(Tpw,2.5)
            gammaw = 1
            if monitor:
                if Rpw > 0.1:
                    print('     Spectrum for swell dominated sea')
                else:
                    print('     Spectrum for pure swell sea')

        if monitor:
            if (3.6 * sqrt(Hm0) <= Tp & Tp <= 5 * sqrt(Hm0)):
                print('     Jonswap range')

            print('Hm0 = %g' % Hm0)
            print('Ns, Ms = %g, %g  Nw, Mw = %g, %g' % (Ns, Ms, Nw, Mw))
            print('gammas = %g gammaw = %g' % (gammas, gammaw))
            print('Rps = %g Rpw = %g' % (Rps, Rpw))
            print('Hps = %g Hpw = %g' % (Hps, Hpw))
            print('Tps = %g Tpw = %g' % (Tps, Tpw))

        # G0s=Ms/((Ns/Ms)**(-(Ns-1)/Ms)*gamma((Ns-1)/Ms )) #normalizing factor

        self.wind = Jonswap(Hm0=Hpw, Tp=Tpw, gamma=gammaw, N=Nw, M=Mw,
                            method=self.method, chk_seastate=False)
        self.swell = Jonswap(Hm0=Hps, Tp=Tps, gamma=gammas, N=Ns, M=Ms,
                             method=self.method, chk_seastate=False)


class McCormick(Bretschneider):

    """ McCormick spectral density model

    Member variables
    ----------------
    Hm0  = significant wave height (default 7 (m))
    Tp   = peak period (default 11 (sec))
    Tz   = zero-down crossing period (default  0.8143*Tp)
    M    = scalar defining spectral width around the peak.
           (default depending on Tp and Tz)

    Parameters
    ----------
    w : array-like
        angular frequencies [rad/s]

    Description
    -----------
    The McCormick spectrum parameterization is a modification of the
    Bretschneider spectrum and defined as

        S(w) = (M+1)*(Hm0/4)^2/wp*(wp./w)^(M+1)*exp(-(M+1)/M*(wp/w)^M)
    where
        Tp/Tz=(1+1/M)^(1/M)/gamma(1+1/M)


    Examples
    --------
    >>> import wafo.spectrum.models as wsm
    >>> S = wsm.McCormick(Hm0=6.5,Tp=10)
    >>> S(range(4))
    array([ 0.        ,  1.87865908,  0.15050447,  0.02994663])


    See also
    --------
    Bretschneider
    Jonswap,
    Torsethaugen


    References:
    -----------
    M.E. McCormick (1999)
    "Application of the Generic Spectral Formula to Fetch-Limited Seas"
    Marine Technology Society, Vol 33, No. 3, pp 27-32
    """

    type = 'McCormick'

    def __init__(self, Hm0=7, Tp=11, Tz=None, M=None, chk_seastate=True):
        if Tz is None:
            Tz = 0.8143 * Tp
        self.Tz = Tz

        if M is None and Hm0 > 0:
            self._TpdTz = Tp / Tz
            M = 1.0 / optimize.fminbound(self._localoptfun, 0.01, 5)
        N = M + 1.0
        super(McCormick, self).__init__(Hm0, Tp, N, M, chk_seastate)

    def _localoptfun(self, x):
        # LOCALOPTFUN Local function to optimize.
        y = 1.0 + x
        return (y ** (x) / sp.gamma(y) - self._TpdTz) ** 2.0


class OchiHubble(ModelSpectrum):

    """ OchiHubble bimodal spectral density model.

    Member variables
    ----------------

    Hm0   : significant wave height (default 7 (m))
    par   : integer defining the parametrization (default 0)
            0 : The most probable spectrum
            1,2,...10 : gives 95% Confidence spectra

    The OchiHubble  bimodal spectrum is modelled as
    S(w) = Ss(w) + Sw(w) where Ss and Sw are modified Bretschneider
    spectra for swell and wind peak, respectively.

    The OH spectrum is a six parameter spectrum, all functions of Hm0.
    The values of these parameters are determined from a analysis of data
    obtained in the North Atlantic. The source of the data is the same as
    that for the development of the Pierson-Moskowitz spectrum, but
    analysis is carried out on over 800 spectra including those in
    partially developed seas and those having a bimodal shape. From a
    statistical analysis of the data, a family of wave spectra consisting
    of 11 members is generated for a desired sea severity (Hm0) with the
    coefficient of 0.95.
    A significant advantage of using a family of spectra for design  of
    marine systems is that one of the family members yields the largest
    response such as motions or wave induced forces for a specified sea
    severity, while another yields the smallest response with confidence
    coefficient of 0.95.

    Examples
    --------
    >>> import wafo.spectrum.models as wsm
    >>> S = wsm.OchiHubble(par=2)
    >>> S(range(4))
    array([ 0.        ,  0.90155636,  0.04185445,  0.00583207])


    See also
    --------
    Bretschneider,
    Jonswap,
    Torsethaugen


    References
    ----------
    Ochi, M.K. and Hubble, E.N. (1976)
    'On six-parameter wave spectra.'
    In Proc. 15th Conf. Coastal Engng., Vol.1, pp301-328

    """

    type = 'Ochi Hubble'

    def __init__(self, Hm0=7, par=1, chk_seastate=True):
        super(OchiHubble, self).__init__(Hm0, Tp=1)

        self.par = par
        self.wind = None
        self.swell = None

        if chk_seastate:
            self.chk_seastate()
        self._init_spec()

    def __call__(self, w):
        return self.wind(w) + self.swell(w)

    def _init_spec(self):

        hp = array([[0.84, 0.54],
                    [0.84, 0.54],
                    [0.84, 0.54],
                    [0.84, 0.54],
                    [0.84, 0.54],
                    [0.95, 0.31],
                    [0.65, 0.76],
                    [0.90, 0.44],
                    [0.77, 0.64],
                    [0.73, 0.68],
                    [0.92, 0.39]])
        wa = array([[0.7, 1.15],
                    [0.93, 1.5],
                    [0.41, 0.88],
                    [0.74, 1.3],
                    [0.62, 1.03],
                    [0.70, 1.50],
                    [0.61, 0.94],
                    [0.81, 1.60],
                    [0.54, 0.61],
                    [0.70, 0.99],
                    [0.70, 1.37]])
        wb = array([[0.046, 0.039],
                    [0.056, 0.046],
                    [0.016, 0.026],
                    [0.052, 0.039],
                    [0.039, 0.030],
                    [0.046, 0.046],
                    [0.039, 0.036],
                    [0.052, 0.033],
                    [0.039, 0.000],
                    [0.046, 0.039],
                    [0.046, 0.039]])
        Lpar = array([[3.00, 1.54, -0.062],
                      [3.00, 2.77, -0.112],
                      [2.55, 1.82, -0.089],
                      [2.65, 3.90, -0.085],
                      [2.60, 0.53, -0.069],
                      [1.35, 2.48, -0.102],
                      [4.95, 2.48, -0.102],
                      [1.80, 2.95, -0.105],
                      [4.50, 1.95, -0.082],
                      [6.40, 1.78, -0.069],
                      [0.70, 1.78, -0.069]])
        Hm0 = self.Hm0
        Lpari = Lpar[self.par]
        Li = hstack((Lpari[0], Lpari[1] * exp(Lpari[2] * Hm0)))

        Hm0i = hp[self.par] * Hm0
        Tpi = 2 * pi * exp(wb[self.par] * Hm0) / wa[self.par]
        Ni = 4 * Li + 1
        Mi = [4, 4]

        self.swell = Bretschneider(Hm0=Hm0i[0], Tp=Tpi[0], N=Ni[0], M=Mi[0])
        self.wind = Bretschneider(Hm0=Hm0i[1], Tp=Tpi[1], N=Ni[1], M=Mi[1])

    def _chk_extra_param(self):
        if self.par < 0 or 10 < self.par:
            raise ValueError('Par must be an integer from 0 to 10!')


class Wallop(Bretschneider):

    """Wallop spectral density model.

    Member variables
    ----------------
    Hm0  = significant wave height (default 7 (m))
    Tp   = peak period (default 11 (sec))
    N   = shape factor, i.e. slope for the high frequency
%                     part (default depending on Hm0 and Tp, see below)

    Parameters
    ----------
    w : array-like
        angular frequencies [rad/s]

    Description
    -----------
    The WALLOP spectrum parameterization is a modification of the Bretschneider
    spectrum and defined as

            S(w) = A * G0 * wn**(-N)*exp(-N/(4*wn**4))
    where
        G0 = Normalizing factor related to Bretschneider form
        A  = (Hm0/4)^2 / wp     (Normalization factor)
        wn = w/wp
        wp = 2*pi/Tp,  angular peak frequency
        N  = abs((log(2*pi^2)+2*log(Hm0/4)-2*log(Lp))/log(2))
        Lp = wave length corresponding to the peak frequency, wp.

    If N=5 it becomes the same as the JONSWAP spectrum with
    peak enhancement factor gamma=1 or the Bretschneider
    (Pierson-Moskowitz) spectrum.

    Examples
    --------
    >>> import wafo.spectrum.models as wsm
    >>> S = wsm.Wallop(Hm0=6.5, Tp=10)
    >>> S(range(4))
    array([  0.00000000e+00,   9.36921871e-01,   2.76991078e-03,
             7.72996150e-05])

    See also
    --------
    Bretschneider
    Jonswap,
    Torsethaugen


    References
    ----------
    Huang, N.E., Long, S.R., Tung, C.C, Yuen, Y. and Bilven, L.F. (1981)
    "A unified two parameter wave spectral model for a generous sea state"
    J. Fluid Mechanics, Vol.112, pp 203-224
    """

    type = 'Wallop'

    def __init__(self, Hm0=7, Tp=11, N=None, chk_seastate=True):
        M = 4
        if N is None:
            wp = 2. * pi / Tp
            kp = w2k(wp, 0, inf)[0]  # wavenumber at peak frequency
            Lp = 2. * pi / kp  # wave length at the peak frequency
            N = np.abs((log(2. * pi ** 2.) + 2 * log(Hm0 / 4) - 2.0 * log(Lp)) / log(2))

        super(Wallop, self).__init__(Hm0, Tp, N, M, chk_seastate)

def k2w(k1, k2=0e0, h=inf, g=9.81, u1=0e0, u2=0e0):
    """ Translates from wave number to frequency using the dispersion relation

    Parameters
    ----------
    k1 : array-like
        wave numbers [rad/m].
    k2 : array-like, optional
        second dimension wave number
    h : real scalar, optional
        water depth [m].
    g : real scalar, optional
        acceleration of gravity, see gravity
    u1, u2 : real scalars, optional
        current velocity [m/s] along dimension 1 and 2.
        note: when u1!=0 | u2!=0 then theta is not calculated correctly

    Returns
    -------
    w : ndarray
        angular frequency [rad/s].
    theta : ndarray
        direction [rad].

    Dispersion relation
    -------------------
        w     = sqrt(g*K*tanh(K*h))   (  0 <   w   < inf)
        theta = arctan2(k2,k1)        (-pi < theta <  pi)
    where
        K = sqrt(k1**2+k2**2)

    The shape of w and theta is the common shape of k1 and k2 according to the
    numpy broadcasting rules.

    See also
    --------
    w2k

    Example
    -------
    >>> from numpy import arange
    >>> import wafo.wave_theory.dispersion_relation as wsd
    >>> wsd.k2w(arange(0.01,.5,0.2))[0]
    array([ 0.3132092 ,  1.43530485,  2.00551739])
    >>> wsd.k2w(arange(0.01,.5,0.2),h=20)[0]
    array([ 0.13914927,  1.43498213,  2.00551724])
    """

    k1i, k2i, hi, gi, u1i, u2i = np.broadcast_arrays(k1, k2, h, g, u1, u2)

    if np.size(k1i) == 0:
        return zeros_like(k1i)
    ku1 = k1i * u1i
    ku2 = k2i * u2i

    theta = np.arctan2(k2, k1)

    k = sqrt(k1i ** 2 + k2i ** 2)
    w = where(k > 0, ku1 + ku2 + sqrt(gi * k * tanh(k * hi)), 0.0)

    cond = (0 <= w)
    _assert_warn(np.all(cond), """
        Waves and current are in opposite directions
        making some of the frequencies negative.
        Here we are forcing the negative frequencies to zero.
        """)

    w = where(cond, w, 0.0)  # force w to zero
    return w, theta


def w2k(w, theta=0.0, h=inf, g=9.81, count_limit=100, rtol=1e-7, atol=1e-14):
    """
    Translates from frequency to wave number using the dispersion relation

    Parameters
    ----------
    w : array-like
        angular frequency [rad/s].
    theta : array-like, optional
        direction [rad].
    h : real scalar, optional
        water depth [m].
    g : real scalar or array-like of size 2.
        constant of gravity [m/s**2] or 3D normalizing constant

    Returns
    -------
    k1, k2 : ndarray
        wave numbers [rad/m] along dimension 1 and 2.

    Description
    -----------
    Uses Newton Raphson method to find the wave number k in the dispersion
    relation
        w**2= g*k*tanh(k*h).
    The solution k(w) => k1 = k(w)*cos(theta)
                         k2 = k(w)*sin(theta)
    The size of k1,k2 is the common shape of w and theta according to numpy
    broadcasting rules. If w or theta is scalar it functions as a constant
    matrix of the same shape as the other.

    Example
    -------
    >>> import pylab as plb
    >>> import wafo.wave_theory.dispersion_relation as wsd
    >>> w = plb.linspace(0,3);
    >>> wsd.w2k(range(4))[0]
    array([ 0.        ,  0.1019368 ,  0.4077472 ,  0.91743119])
    >>> wsd.w2k(range(4),h=20)[0]
    array([ 0.        ,  0.10503601,  0.40774726,  0.91743119])

    h = plb.plot(w,w2k(w)[0])
    plb.close('all')

    See also
    --------
    k2w
    """
    gi = atleast_1d(g)
    wi, th, hi = np.broadcast_arrays(w, theta, h)
    if wi.size == 0:
        return zeros_like(wi)

    k = 1.0 * sign(wi) * wi ** 2.0 / gi[0]  # deep water
    if (hi > 1e25).all():
        k2 = k * sin(th) * gi[0] / gi[-1]  # size np x nf
        k1 = k * cos(th)
        return k1, k2
    _assert(gi.size == 1, 'Finite depth in combination with 3D normalization'
            ' (len(g)=2) is not implemented yet.')

    oshape = k.shape
    wi, k, hi = wi.ravel(), k.ravel(), hi.ravel()

    # Newton's Method
    # Permit no more than count_limit iterations.
    hi = hi * ones_like(k)
    hn = zeros_like(k)
    ix = flatnonzero(((wi < 0) | (0 < wi)) & (hi < 1e25))

    # Break out of the iteration loop for three reasons:
    #  1) the last update is very small (compared to k*rtol)
    #  2) the last update is very small (compared to atol)
    #  3) There are more than 100 iterations. This should NEVER happen.
    count = 0
    while (ix.size > 0 and count < count_limit):
        ki = k[ix]
        kh = ki * hi[ix]
        coshkh2 = lazywhere(np.abs(kh) < 350, (kh, ),
                            lambda kh: cosh(kh) ** 2.0, fillvalue=np.inf)
        hn[ix] = (ki * tanh(kh) - wi[ix] ** 2.0 / gi) / (tanh(kh) + kh / coshkh2)
        knew = ki - hn[ix]
        # Make sure that the current guess is not zero.
        # When Newton's Method suggests steps that lead to zero guesses
        # take a step 9/10ths of the way to zero:
        ksmall = flatnonzero((np.abs(knew) == 0) | (np.isnan(knew)) )
        if ksmall.size > 0:
            knew[ksmall] = ki[ksmall] / 10.0
            hn[ix[ksmall]] = ki[ksmall] - knew[ksmall]

        k[ix] = knew
        # disp(['Iteration ',num2str(count),'  Number of points left:  '
        # num2str(length(ix)) ]),

        ix = flatnonzero((np.abs(hn) > rtol * np.abs(k)) *
                         (np.abs(hn) > atol))
        count += 1
    max_err = np.max(hn[ix]) if np.any(ix) else 0
    _assert_warn(count < count_limit, 'W2K did not converge. '
                 'Maximum error in the last step was: %13.8f' % max_err)

    k.shape = oshape

    k2 = k * sin(th)
    k1 = k * cos(th)
    return k1, k2

def _assert(cond, msg):
    if not cond:
        raise ValueError(msg)


def _assert_warn(cond, msg):
    if not cond:
        warnings.warn(msg)

def lazywhere(cond, arrays, f, fillvalue=None, f2=None):
    """
    np.where(cond, x, fillvalue) always evaluates x even where cond is False.
    This one only evaluates f(arr1[cond], arr2[cond], ...).
    For example,
    >>> a, b = np.array([1, 2, 3, 4]), np.array([5, 6, 7, 8])
    >>> def f(a, b):
    ...     return a*b
    >>> lazywhere(a > 2, (a, b), f, np.nan)
    array([ nan,  nan,  21.,  32.])
    >>> def f2(a, b):
    ...    return (a*b)**2
    >>> lazywhere(a > 2, (a, b), f, f2=f2)
    array([  25.,  144.,   21.,   32.])

    Notice it assumes that all `arrays` are of the same shape, or can be
    broadcasted together.

    """
    if fillvalue is None:
        _assert(f2 is not None, "One of (fillvalue, f2) must be given.")
        fillvalue = np.nan
    else:
        _assert(f2 is None, "Only one of (fillvalue, f2) can be given.")

    arrays = np.broadcast_arrays(*arrays)
    temp = tuple(np.extract(cond, arr) for arr in arrays)
    out = valarray(np.shape(arrays[0]), value=fillvalue)
    np.place(out, cond, f(*temp))
    if f2 is not None:
        temp = tuple(np.extract(~cond, arr) for arr in arrays)
        np.place(out, ~cond, f2(*temp))

    return out

def valarray(shape, value=np.NaN, typecode=None):
    """Return an array of all value.
    """
    if typecode is None:
        typecode = bool
    out = ones(shape, dtype=typecode) * value

    if not isinstance(out, np.ndarray):
        out = asarray(out)
    return out


def _test_some_spectra():
##    S = Jonswap()
##
##    w = np.linspace(0, 3.0)
##    S(w) * phi1(w, 30.0)
##    S1 = S.tospecdata(w)
##    S1.plot()

    import matplotlib.pyplot as plt
    w = np.linspace(0, 2.5)
    S = Tmaspec(h=10, gamma=1)  # Bretschneider spectrum Hm0=7, Tp=11
    plt.plot(w, S(w))
    plt.plot(w, S(w, h=21))
    plt.plot(w, S(w, h=42))
    plt.show()
    plt.close('all')

    w, th = np.ogrid[0:4, 0:6]
    k, k2 = w2k(w, th)

    plt.plot(w, k, w, k2)
    plt.title('w2k')
    plt.xlabel('w')

    plt.show()

    plt.close('all')
    w = np.linspace(0, 2, 100)
    S = Torsethaugen(Hm0=6, Tp=8)
    plt.plot(w, S(w), w, S.wind(w), w, S.swell(w))

    S1 = Jonswap(Hm0=7, Tp=11, gamma=1)
    w = np.linspace(0, 2, 100)
    plt.plot(w, S1(w))
    plt.show()
    plt.close('all')

    Hm0 = np.arange(1, 11)
    Tp = np.linspace(2, 16)
    T, H = np.meshgrid(Tp, Hm0)
    gam = jonswap_peakfact(H, T)
    plt.plot(Tp, gam.T)
    plt.xlabel('Tp [s]')
    plt.ylabel('Peakedness parameter')
    plt.show()

    Hm0 = np.linspace(1, 20)
    Tp = Hm0
    [T, H] = np.meshgrid(Tp, Hm0)
    gam = jonswap_peakfact(H, T)
    v = np.arange(0, 8)
    plt.contourf(Tp, Hm0, gam, v)
    plt.colorbar()
    plt.show()
    plt.close('all')


def main():
    if True:
        _test_some_spectra()

    else:
        test_docstrings()


if __name__ == '__main__':
    main()
