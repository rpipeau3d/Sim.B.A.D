##  This file is part of SIMBAD pre-processing program.

##  SIMBAD pre-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD pre-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD pre-processing program.
##  If not, see <https://www.gnu.org/licenses/>.


##  Simple Prediction Formula of Roll Damping on the Basis of article:    
##  "Martin Alexandersson, Wengang Mao & Jonas W. Ringsberg (2021) 
##  Analysis of roll damping model scale data,
##  Ships and Offshore Structures, DOI: 10.1080/17445302.2021.1907070"

# Import modules
import numpy as np

# Set interactive
def RolDamp(beam, mass, inert, inertaj):
    repons = input('Do you want a calculation of roll damping coefficients?: Yes or No (default: No)\n')

    B44OM = 0.0
    B44PHI = 0.0
    if repons !='':
        repons = str(repons)
    else:
        repons = 'No'
    if repons == 'Yes':
        GM = input('Enter the transverse metacentric height GM in m (default value:0.5 m): ')
        if GM !='':
            GM = np.float(GM)
        else:
            GM = np.float('0.5')
        # Calculation of natural roll frequency in rad/s
        OMEGA0 = np.sqrt(GM*mass*9.81/(inert+inertaj))
        T0 = 2*np.pi/OMEGA0
        print('Natural roll period (in s): ',T0)
        # Non-dimensional natural roll frequency
        OMEGA0HAT = OMEGA0*np.sqrt(beam/2/9.81)
        # Calculation of roll damping non-dimensional coefficients for ship speed V = 0
        B44OM = 0.007814*OMEGA0HAT**2 - 0.00106914
        B44PHI = 0.03882*OMEGA0HAT
        # Calculation of roll damping dimensional coefficients for ship speed V = 0
        DEBVIS = mass*beam**2/np.sqrt(beam/2/9.81)
        B44OM = B44OM*DEBVIS
        B44PHI = B44PHI*DEBVIS

    return B44OM, B44PHI
