##  This file is part of SIMBAD pre-processing program.

##  SIMBAD pre-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD pre-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD pre-processing program.
##  If not, see <https://www.gnu.org/licenses/>.


# Import modules
import numpy as np
import matplotlib.pyplot as plt
import scipy as sp
import scipy.fft
import scipy.signal
from fourier import PSD_continuous
import Sstat
import smooth as smh

# Plot the Wave signal data for verification.
# Set interactive
def Plot_WS(repons,eta_t,eta,Hs):
    Ecrit = np.zeros(5).astype(np.str)
    Ecrit = ['Wave Signal with random phase','Wave Signal FAST','Wave Signal from file','Wave signal from specific Spectrum','Regular waves']
    try:
        plt.interactive(True)
        plt.figure()
        plt.axis([0,eta_t[-1],-Hs,Hs])
        if repons=='1': plt.plot(eta_t, eta, 'r--',label=Ecrit[0])
        if repons=='2': plt.plot(eta_t, eta, 'r--',label=Ecrit[1])
        if repons=='3': plt.plot(eta_t, eta, 'r--',label=Ecrit[2])
        if repons=='4': plt.plot(eta_t, eta, 'r--',label=Ecrit[3])
        if repons=='5': plt.plot(eta_t, eta, 'r--',label=Ecrit[4])
        plt.title('Wave Time Series')
        plt.xlabel('Time (s)')
        plt.ylabel('Wave amplitude (m)')
        plt.grid(True)
        plt.legend()
        plt.savefig("WAV_SIG.pdf")
    except:
        pass

# Plot the Wave density spectrum for verification.
# Set interactive
def Plot_specSS(repons,freqs,specSS):
    Ecrit = np.zeros(7).astype(np.str)
    Ecrit = ['Specific density spectrum','Jonswap spectrum','Bretschneider spectrum',
             'Torsethaugen spectrum','McCormick spectrum','OchiHubble spectrum','Wallop spectrum']
    try:
        plt.interactive(True)
        plt.figure()
        plt.xlim(0,freqs[-1])
        if repons=='0': plt.plot(freqs, specSS, 'r--',label=Ecrit[0])
        if repons=='1': plt.plot(freqs, specSS, 'r--',label=Ecrit[1])
        if repons=='2': plt.plot(freqs, specSS, 'r--',label=Ecrit[2])
        if repons=='3': plt.plot(freqs, specSS, 'r--',label=Ecrit[3])
        if repons=='4': plt.plot(freqs, specSS, 'r--',label=Ecrit[4])
        if repons=='5': plt.plot(freqs, specSS, 'r--',label=Ecrit[5])
        if repons=='6': plt.plot(freqs, specSS, 'r--',label=Ecrit[6])
        plt.xlabel('Frequency (rad/s)')
        plt.ylabel('PSD (m2/(rad/s))')
        plt.grid(True)
        plt.legend()
        plt.savefig("WaveDS_Spec.pdf")
    except:
        pass

# Calculation of Spectral density value
# The suitable value for fs would be 1/dt
def Plot_SS(repons,eta_t,eta,dt,freqs,method):
    Ecrit = np.zeros(4).astype(np.str)
    Ecrit = ['Wave Signal with random phase','Wave Signal FAST','Wave Signal from file','Wave signal from specific Spectrum']
    if method=='1':
        fftfreq, eta_fft = PSD_continuous(eta_t,eta)
        fftfreq = fftfreq*2*np.pi # to be in rad/s
        # Determination of PSD: calculation of 2*H(f)^2 as real signal
        # Then: H(f) = H(2*PI*f) and PSD(2*PI*f) = 2*H^2/ 2 / 2*PI / 2T (m2.s2/s/rad)
        eta_fft = eta_fft/(2*np.pi)/(4*eta_t[-1]) # to be in m2/(rad/s)
        #   ynew = smh.smooth(eta_fft,5,'hamming')
    else:
        fftfreq, eta_fft = sp.signal.welch(eta, fs=1/dt, nperseg=256, return_onesided=True)
        fftfreq = fftfreq*2*np.pi # to be in rad/s
        eta_fft = eta_fft/(2*np.pi) # to be in m2/(rad/s)
        hs = Sstat.hs(fftfreq,eta_fft)
        print(f'Wave height Hs in m: {hs:.3f} m')
        hmax = Sstat.hmax(fftfreq,eta_fft,eta_t[-1])
        print(f'Wave height Hmax in m: {hmax:.3f} m')
        t1 = 2*np.pi*Sstat.tm01(fftfreq,eta_fft)
        print(f'Mean wave period T1 in s: {t1:.3f} s')
        tp = Sstat.tp(fftfreq,eta_fft)
        print(f'Peak wave period Tp in s: {tp:.3f} s')

    try:
        plt.interactive(True)
        plt.figure()
        plt.xlim(0,freqs[-1])
        if repons=='1': plt.plot(fftfreq,eta_fft,'b--',label=Ecrit[0])
        if repons=='2': plt.plot(fftfreq,eta_fft,'b--',label=Ecrit[1])
        if repons=='3': plt.plot(fftfreq,eta_fft,'b--',label=Ecrit[2])
        if repons=='4': plt.plot(fftfreq,eta_fft,'b--',label=Ecrit[3])
        plt.title('Wave Spectrum')
        plt.xlabel('Frequency (rad/s)')
        plt.ylabel('PSD (m2/(rad/s))')
        plt.grid(True)
        plt.legend()
        plt.savefig("WaveDS_Calc.pdf")
    except:
        pass
