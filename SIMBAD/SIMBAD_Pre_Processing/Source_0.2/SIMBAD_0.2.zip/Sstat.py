##  This file is part of SIMBAD pre-processing program.

##  SIMBAD pre-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD pre-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD pre-processing program.
##  If not, see <https://www.gnu.org/licenses/>.


# Import modules
import numpy as np

def hs(freqs,Spec):
    """Spectral significant wave height Hm0.

    Args:
        - freqs: frequency array
        - Spec: calculated wave spectrum

    """
    E = momf(freqs,Spec,mom=0)
    hs = 4 * np.sqrt(E)

    return hs

def momf(freqs, Spec, mom=None):
    """Calculate given frequency moment.

    Args:
        - freqs: frequency array
        - Spec: calculated wave spectrum

    """
    fp = freqs ** mom
# df darray with freq dimension
    df = np.diff(freqs)
    dfarr = 0.5 * (np.hstack((df[0], df)) + np.hstack((df, df[-1])))    

    mf = dfarr * fp * Spec
    mom = sum(mf)
    return mom

def hmax(freqs, Spec, D, k=None):
    """Maximum wave height Hmax.

    Args:
        - freqs: frequency array
        - Spec: calculated wave spectrum
        - k (float): factor to multiply hs by
        - D (float): time duration considered in the estimation (assumed stationary conditions)

    hmax is the most probable value of the maximum individual wave height
    . Note that maximum wave height can be higher (but not by much since
    the probability density function is rather narrow).

    Note: k = 1.86  assumes N = 3*3600 / 10.8 (1000 crests)

    Reference:
        - Holthuijsen LH (2005). Waves in oceanic and coastal waters (page 82).

    """
    if not k:
        N = (
            D / (2*np.pi*tm02(freqs, Spec))
        ).round()  # N is the number of waves in a sea state
        k = np.sqrt(0.5 * np.log(N))
    hmax = k * hs(freqs, Spec)

    return hmax

def tm01(freqs, Spec):
    """Mean absolute wave period Tm01.

    True average period from the 1st spectral moment.

    Args:
        - freqs: frequency array
        - Spec: calculated wave spectrum

    """
    tm01 = momf(freqs, Spec, mom=0) / momf(freqs, Spec, mom=1)

    return tm01

def tm02(freqs, Spec):
    """Mean absolute wave period Tm02.

    Average period of zero up-crossings (Zhang, 2011).

    Args:
        - freqs: frequency array
        - Spec: calculated wave spectrum

    """
    tm02 = np.sqrt(
        momf(freqs, Spec, mom=0) / momf(freqs, Spec, mom=2)
    )

    return tm02

def tp(freqs, Spec):
    """Peak wave period Tp corresponding to the maxima in the spectra.

    Args:
        - freqs: frequency array
        - Spec: calculated wave spectrum

    """

    maxi, ipeak = Maximum(Spec)
    fp = freqs[ipeak]
    tp = (2*np.pi / fp)

    return tp

# Function maximum
def Maximum(liste):
    maxi = liste[0]
    longueur=len(liste)
    for i in range(0,longueur):
        if liste[i] >= maxi:
            maxi = liste[i]
            ipeak = i
    return maxi, ipeak
