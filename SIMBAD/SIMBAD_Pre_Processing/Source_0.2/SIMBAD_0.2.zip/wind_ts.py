##  This file is part of SIMBAD pre-processing program.

##  SIMBAD pre-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD pre-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD pre-processing program.
##  If not, see <https://www.gnu.org/licenses/>.


# Import modules
import numpy as np
import wind_models as wm
from math import ceil
import plot_WindS as pWS
import sys

def wind_ts():
    """
    Return wind velocity time series from a chosen wind spectrum

    Member variables
    ----------------
    U10 : 10 minutes mean wind velocity at 10m height [m/s]
    Dwind : wind direction [°]

    Returns
    -------
    file of wind velocity time series

    ---
    """
# Read wind velocity and direction
    U10 = input('Ten min. mean wind velocity at 10m height in m/s(default value: 0.0): ')
    if U10 != '':
        U10 = np.float(U10)
    else:
        U10 = np.float('0.0')
    Dwind = input('Wind direction at 10m height in °(default value: 0.0): ')
    if Dwind != '':
        Dwind = np.float(Dwind)
    else:
        Dwind = np.float('0.0')

# Read total duration of simulation (time) and time step dt
    time = input('Simulation duration in s (default value: 10800): ')
    if time != '':
        time = np.float(time)
    else:
        time = np.float('10800.0')
    dt = input('Time step between 0.5 and 2 s (default value: 1): ')
    if dt != '':
        dt = np.float(dt)
    else:
        dt = np.float('1.0')
    if dt != 0.0:
        num_dt = int(ceil(time/dt))
    else:
        print('Wind time step equal to zero')
        sys.exit()
    if num_dt%2==1: num_dt = num_dt+1 # num_dt should be an even integer

    eta_t = np.zeros(num_dt)
    for istep in range (num_dt-1):
        eta_t[istep+1] = eta_t[istep] + dt

# Choice of spectrum model and calculation of spectral values
    reponsSM = input('0: No wind,\n'
                   +'1: Davenport spectral density model,\n'
                   +'2: Harris spectral density model,\n'
                   +'3: Kaimal spectral density model,\n'
                   +'4: API spectral density model,\n'
                   +'5: NPD spectral density model,\n'
                   +'6: Ochi-Shin spectral density model,\n'
                   +'Default: 0\n')
    if reponsSM !='':
        reponsSM = str(reponsSM)
    else:
        reponsSM = '0'
        U10 = 0.0
        
    if '1' in reponsSM:
        WindS = wm.Davenport(U10=U10)
        S1 = WindS.spectre()
        freqs = 2*np.pi*WindS.freq()       
    elif '2' in reponsSM:
        WindS = wm.Harris(U10=U10)
        S1 = WindS.spectre()
        freqs = 2*np.pi*WindS.freq() 
    elif '3' in reponsSM:
        WindS = wm.Kaimal(U10=U10)
        S1 = WindS.spectre()
        freqs = 2*np.pi*WindS.freq() 
    elif '4' in reponsSM:
        WindS = wm.API(U10=U10)
        S1 = WindS.spectre()
        freqs = 2*np.pi*WindS.freq() 
    elif '5' in reponsSM:
        WindS = wm.NPD(U10=U10)
        S1 = WindS.spectre()
        freqs = 2*np.pi*WindS.freq() 
    elif '6' in reponsSM:
        WindS = wm.Ochi_Shin(U10=U10)
        S1 = WindS.spectre()
        freqs = 2*np.pi*WindS.freq()

# Plot the wind spectral density model
    if reponsSM !='0':
        pWS.Plot_specSS(reponsSM,freqs,S1)

###########################################################
# Calculate wind time series with random phase
###########################################################
# Construct phaseVector
        phaseVector = wm.makePhase(eta_t,freqs)
# Calculate wind velocity time series
        eta = U10 + wm.makeWindx(eta_t,freqs,S1,phaseVector)
# Plot the data for verification
        pWS.Plot_WS(eta_t,eta)
# Calculation of Spectral density value
# The suitable value for fs would be 1/dt
        pWS.Plot_SS(reponsSM,eta_t,eta,dt,freqs)

# Writing of wave excitation forces in a txt file
    with open('wind_vel.txt','w') as f:
        ndt = len(eta_t)
        np.savetxt(f,[Dwind],fmt='%.6e')
        if reponsSM !='0':
            for irow in range(ndt):
                tmpa = eta_t[irow]
                tmpb = eta[irow]
                np.savetxt(f,[(tmpa,tmpb)],fmt='%.6e')
            np.savetxt(f,[(-1.,0.)],fmt='%.6e')
        else:
            np.savetxt(f,[(0.,U10)],fmt='%.6e')
            np.savetxt(f,[(time,U10)],fmt='%.6e')
            np.savetxt(f,[(-1.,0.)],fmt='%.6e')

def main():
    if True:
        wind_ts()

    else:
        test_docstrings()


if __name__ == '__main__':
    main()
