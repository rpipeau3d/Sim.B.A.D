!C***********************************************************************
      SUBROUTINE EFHOUIR(T,IND,K)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: SUBROUTINE EFHOUIR                               *
!*                                                                      *
!*      CALCUL DES EFFORTS DE HOULE ET DERIVE A L'INSTANT T             *
!*      PAR INTERPOLATION DANS LE SIGNAL CONNU POINT PAR POINT.         *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE COEF
      USE HIRR
      IMPLICIT NONE

!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
!C--- T: INSTANT T
!C--- IND: INDICE DU MOUVEMENT
!C--- K: INDICE DU CORPS FLOTTANT
      INTEGER::IND,K,I
      REAL::T,TT
!C----------------------------------------------------------------------
      TT=MOD(T,THOMAX)
!C***********************************************************************
      DO 1 I=2,NHIR
       IF(TT.GE.THOU(I))GOTO 1
        F(IND,K)=EFHOUL(IND,I-1,K)&
     &  +(EFHOUL(IND,I,K)-EFHOUL(IND,I-1,K))&
     &  *(TT-THOU(I-1))/(THOU(I)-THOU(I-1))
        FD(IND,NCOR)=EFDRIF(IND,I-1,K)&
     &  +(EFDRIF(IND,I,K)-EFDRIF(IND,I-1,K))&
     &  *(TT-THOU(I-1))/(THOU(I)-THOU(I-1))
       GOTO 2
 1    CONTINUE
!C***********************************************************************
 2    CONTINUE
      RETURN
      END
