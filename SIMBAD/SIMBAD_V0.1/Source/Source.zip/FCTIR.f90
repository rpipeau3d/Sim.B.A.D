!C***********************************************************************
      SUBROUTINE FCTIR(T,Y,DERY)
!************************************************************************
!*                                                                      *
!*  PROGRAMME SIMBAD: SOUS-PROGRAMME FCTIR POUR HOULE IRREGULIERE       *
!*                                                                      *
!*      CALCUL DE LA DERIVEE DE Y AU TEMPS T                            *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE PARA
      USE COEF
      USE AMAR
      USE VENT
      USE COURANT
      USE CHENAL
      USE MATR
      USE PTSC
      USE HIRR
      USE IRTN
      USE EFRD
      USE AMVIS
      USE AUTMO
      USE SHTEN
      IMPLICIT NONE
!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
!C--- T: INSTANT T
!C--- Y,DERY: MOUVEMENTS ET VITESSES DU CENTRE DE GRAVITE A L'INSTANT T
      REAL::T,Y(*),DERY(*)
!C--- VARIABLES LOCALES
      INTEGER::NC6,NC61,I,J,K,LK,IL
      REAL::EWT1,EWT2,FHS,FEH,FDH
      REAL::ALPC,CXV,CYV,CNV,CKV
      REAL::DELT,DELTP,DVL
      REAL::ROV2,V,FKV,FXV,FYV,FNV
      REAL::RLI,FAMAR,FAMOR,FAN1,FAN2,FAN3
      REAL::FAMO,FAMA,EFDALB
      REAL::XPMN,YPMN,ZPMN,VXMN,VYMN,VZMN,GXMN,GYMN,GZMN
      REAL::FMCX,FMCY,FMCZ
      REAL::ANCUC,ROCU2,VCU,CXCU,CYCU,CNCU,DCUL,FXCU,FYCU,FNCU
      REAL::DELST0(NLIG),DELST,EFFSHTEN0(NLIG)
!C----------------------------------------------------------------------
      NC6=NC*6
      NC61=NC6+1

!**** FONCTION DE DEMARRAGE
      IF(T.LE.DMAR)THEN
        EWT2=1./COSH(9.90348755*T/DMAR)
        EWT1=1.-EWT2
      ELSE
        EWT2=1./COSH(9.90348755)
        EWT1=1.-EWT2
      ENDIF

!**** CONSTITUTION DU SECOND MEMBRE
      DO K=1,NC
        DO I=1,6
            LK=I+6*(K-1)
!C--- HOULE
            FHS=0.
            DO J=1,6
                FHS=FHS+SH(I,J,K)*Y(J+6*(K-1))
            END DO
            CALL EFAMRAD(T,Y,I,K)
            CALL EFHOUIR(T,I,K)
            FEH=F(I,K)*EWT1
            FDH=FD(I,K)*EWT1
            AIJ(LK,NC61)=FDH+FEH-FHS-FAM(I,K)
        END DO
      END DO

!C--- MOMENT DE FROTTEMENT EN ROULIS DU A L'AMORTISSEMENT VISQUEUX
!C--- PAS UTILISE ACTUELLEMENT
      DO 4 K=1,NC
        LK=4+6*(K-1)
        AIJ(LK,NC61)=AIJ(LK,NC61)-(B44OM+B44PHI*ABS(Y(LK)))&
     &  *Y(LK+6*NC)
4     CONTINUE

!C--- COURANT
      DO 61 K=1,NC
        LK=6*(K-1)
        ROCU2=.5*RHOE*AL*TIREAU*VCU(T)**2
        DCUL=MOD((DCUR-Y(6))*180./PI,360.)
        DO 1223 I=2,37
            IF(DCUL.GE.ANCU(I))GOTO 1223
            ANCUC=(DCUL-ANCU(I-1))/(ANCU(I)-ANCU(I-1))
            CXCU=CUX(I-1)+(CUX(I)-CUX(I-1))*ANCUC
            CYCU=CUY(I-1)+(CUY(I)-CUY(I-1))*ANCUC
            CNCU=CUN(I-1)+(CUN(I)-CUN(I-1))*ANCUC
            GOTO 2223
 1223   CONTINUE
 2223   CONTINUE
        FXCU=ROCU2*CXCU*EWT1
        FYCU=ROCU2*CYCU*EWT1
        FNCU=ROCU2*CNCU*AL*EWT1
        AIJ(1+LK,NC61)=AIJ(1+LK,NC61)+FXCU*COS(Y(6))-FYCU*SIN(Y(6))
        AIJ(2+LK,NC61)=AIJ(2+LK,NC61)+FXCU*SIN(Y(6))+FYCU*COS(Y(6))
        AIJ(6+LK,NC61)=AIJ(6+LK,NC61)+FNCU
 61   CONTINUE

!C--- VENT
      DO 71 K=1,NC
        LK=6*(K-1)
        ROV2=.5*RHOA*V(T)**2
        DVL=MOD((DV-Y(6))*180./PI,360.)
        DO 1323 I=2,37
            IF(DVL.GE.ALP(I))GOTO 1323
            ALPC=(DVL-ALP(I-1))/(ALP(I)-ALP(I-1))
            CXV=CX(I-1)+(CX(I)-CX(I-1))*ALPC
            CYV=CY(I-1)+(CY(I)-CY(I-1))*ALPC
            CNV=CN(I-1)+(CN(I)-CN(I-1))*ALPC
            CKV=CK(I-1)+(CK(I)-CK(I-1))*ALPC
            GOTO 2323
 1323   CONTINUE
 2323 CONTINUE
        FXV=ROV2*CXV*SL*EWT1
        FYV=ROV2*CYV*ST*EWT1
        FKV=ROV2*CKV*ST*HR*EWT1
        FNV=ROV2*CNV*ST*ALR*EWT1
        AIJ(1+LK,NC61)=AIJ(1+LK,NC61)+FXV*COS(Y(6))-FYV*SIN(Y(6))
        AIJ(2+LK,NC61)=AIJ(2+LK,NC61)+FXV*SIN(Y(6))+FYV*COS(Y(6))
        AIJ(4+LK,NC61)=AIJ(4+LK,NC61)+FKV
        AIJ(6+LK,NC61)=AIJ(6+LK,NC61)+FNV
 71   CONTINUE

!C--- EFFORTS NAVIRE CHENALANT
      DO 81 K=1,NC
        LK=6*(K-1)
        CALL FMCH(T,FMCX,FMCY,FMCZ)
        AIJ(1+LK,NC61)=AIJ(1+LK,NC61)+FMCX
        AIJ(2+LK,NC61)=AIJ(2+LK,NC61)+FMCY
        AIJ(6+LK,NC61)=AIJ(6+LK,NC61)+FMCZ
 81   CONTINUE

!C--- AMARRAGE (LIGNES ET DEFENSES)
      DO 11 K=1,NC ! BOUCLE POUR LES LIGNES ET DEFENSES
      LK=6*(K-1)
      DO 9 IL=1,NAN
      CALL PVG(Y,DERY,XPM(IL),YPM(IL),ZPM(IL),XPMN,YPMN,ZPMN,&
     &VXMN,VYMN,VZMN,GXMN,GYMN,GZMN)
!C--- TYPE RESSORT
!*      IF(IK(IL).EQ.0)THEN
!*      RLI=SQRT((XPMN-XPF(IL))**2+(YPMN-YPF(IL))**2+(ZPMN-ZPF(IL))**2)
!*      DELTP=(VXMN*(XPMN-XPF(IL))+VYMN*(YPMN-YPF(IL))+&
!*     &VZMN*(ZPMN-ZPF(IL)))/RLI
!*      DELT=RLI-RL(IL)
!*      FAMAR=FAMA(IL,DELT)+PT(IL)*EWT1
!*      FAMOR=FAMO(IL,DELTP,EWT2)
!*      FAN1=(FAMAR+FAMOR)*(XPMN-XPF(IL))/RLI
!*      FAN2=(FAMAR+FAMOR)*(YPMN-YPF(IL))/RLI
!*      FAN3=(FAMAR+FAMOR)*(ZPMN-ZPF(IL))/RLI
!*      ENDIF
!C--- TYPE RESSORT EN TRACTION
      IF(IK(IL).EQ.1)THEN
      RLI=SQRT((XPMN-XPF(IL))**2+(YPMN-YPF(IL))**2+(ZPMN-ZPF(IL))**2)
      DELTP=(VXMN*(XPMN-XPF(IL))+VYMN*(YPMN-YPF(IL))+&
     &VZMN*(ZPMN-ZPF(IL)))/RLI
      DELT=RLI-RL(IL)
      FAMAR=MAX(FAMA(IL,DELT)+PT(IL)*EWT1,0.)
!*      FAMAR=MAX(FAMA(IL,DELT),0.)
      FAMOR=FAMO(IL,DELTP,EWT2)
      FAN1=(FAMAR+FAMOR)*(XPMN-XPF(IL))/RLI
      FAN2=(FAMAR+FAMOR)*(YPMN-YPF(IL))/RLI
      FAN3=(FAMAR+FAMOR)*(ZPMN-ZPF(IL))/RLI
      ENDIF
!C--- TYPE LIAISON RIGIDE (MOUVEMENT EN X ET Y)
      IF(IK(IL).EQ.2)THEN
       RLI=SQRT((XPMN-XPF(IL))**2+(YPMN-YPF(IL))**2+(ZPMN-ZPF(IL))**2)
       DELT=SQRT((XPMN-XPM(IL))**2+(YPMN-YPM(IL))**2)
       FAN1=0.
       FAN2=0.
       FAN3=0.
       IF((RLI-RL(IL)).GE.0.)THEN
        IF(DELT.NE.0.)THEN
         DELTP=(VXMN*(XPMN-XPM(IL))+VYMN*(YPMN-YPM(IL)))/DELT
         FAMAR=MAX(EFFAUTMO(IL)+PT(IL)*EWT1,0.)
         FAMOR=FAMO(IL,DELTP,EWT2)
         FAN1=(FAMAR+FAMOR)*(XPMN-XPM(IL))/DELT
         FAN2=(FAMAR+FAMOR)*(YPMN-YPM(IL))/DELT
        ENDIF
       ENDIF
      ENDIF
!C--- TYPE LIAISON RIGIDE (MOUVEMENT SEULEMENT EN X)
      IF(IK(IL).EQ.21)THEN
       DELT=SQRT((XPMN-XPM(IL))**2)
       FAN1=0.
       FAN2=0.
       FAN3=0.
        IF(DELT.NE.0.)THEN
         DELTP=(VXMN*(XPMN-XPM(IL)))/DELT
         FAMAR=MAX(EFFAUTMO(IL)+PT(IL)*EWT1,0.)
         FAMOR=FAMO(IL,DELTP,EWT2)
         FAN1=(FAMAR+FAMOR)*(XPMN-XPM(IL))/DELT
        ENDIF
      ENDIF
!C--- TYPE LIAISON RIGIDE (MOUVEMENT SEULEMENT EN Y)
      IF(IK(IL).EQ.22)THEN
       RLI=SQRT((XPMN-XPF(IL))**2+(YPMN-YPF(IL))**2+(ZPMN-ZPF(IL))**2)
       DELT=SQRT((YPMN-YPM(IL))**2)
       FAN1=0.
       FAN2=0.
       FAN3=0.
       IF((RLI-RL(IL)).GE.0.)THEN
        IF(DELT.NE.0.)THEN
         DELTP=(VYMN*(YPMN-YPM(IL)))/DELT
         FAMAR=MAX(EFFAUTMO(IL)+PT(IL)*EWT1,0.)
         FAMOR=FAMO(IL,DELTP,EWT2)
         FAN2=(FAMAR+FAMOR)*(YPMN-YPM(IL))/DELT
        ENDIF
       ENDIF
!*       write ( *, '(a)' ) ' '
!*       write ( *, '(a,a)' ) '    T          DELT            ',
!*     &      'FAN1           FAN2'
!*       write ( *, '(a)' ) ' '
!*       write ( *, '(g14.6,2x,2g14.6)' ) T, DELT, FAN1, FAN2
      ENDIF
!C-- TYPE LIAISON AVEC UN SYSTEME AMORTISSEUR
      IF(IK(IL).EQ.3)THEN
       RLI=SQRT((XPMN-XPF(IL))**2+(YPMN-YPF(IL))**2+(ZPMN-ZPF(IL))**2)
       DELST=RLI-RL(IL)
       DELTP=(VXMN*(XPMN-XPF(IL))+VYMN*(YPMN-YPF(IL))+&
     & VZMN*(ZPMN-ZPF(IL)))/RLI
       IF(T.EQ.0.)THEN
        DELST0(IL)=0.
        EFFSHTEN0(IL)=PT(IL)
        EFFSHTEN(IL)=PT(IL)
       ENDIF
!*       CALL FSHTEN(IL,DELST0(IL),DELST,EFFSHTEN0(IL),PAST)
       CALL FSHTEN(IL,DELST,DELTP,EFFSHTEN0(IL))
       FAMAR=EFFSHTEN(IL)
       FAN1=FAMAR*(XPMN-XPF(IL))/RLI
       FAN2=FAMAR*(YPMN-YPF(IL))/RLI
       FAN3=FAMAR*(ZPMN-ZPF(IL))/RLI

       DELST0(IL)=DELST
       EFFSHTEN0(IL)=EFFSHTEN(IL)

!*       write ( *, '(a)' ) ' '
!*       write ( *, '(a,a)' ) 'IL    T          DELST            ',
!*     &      'EFFSHTEN'
!*       write ( *, '(a)' ) ' '
!*       write ( *, '(i3,2x,f10.2,2x,f10.2,2x,g14.6)')IL,T,DELST,
!*     & EFFSHTEN(IL)

      ENDIF
!C---  TYPE RESSORT EN COMPRESSION DANS UNE DIRECTION (DUCS D'ALBE)
      IF(IK(IL).EQ.-1)THEN
        DELT=YPM(IL)-YPMN
        IF(YPM(IL).LT.0.)THEN
            DELT = -DELT
        ENDIF
        DELTP=VYMN
        FAMOR=FAMO(IL,DELTP,EWT2)
        FAN1=0.
        EFDALB = FAMA(IL,DELT)
        IF(DELT.LT.0.)THEN
            EFDALB = -FAMA(IL,ABS(DELT))
        ENDIF
        FAN2=(MIN(EFDALB+PT(IL)*EWT1,0.)+FAMOR)*&
     &  SIGN(1.,(YPM(IL)-YPF(IL)))
        IF(FROT.NE.0.) THEN
            FAN1=FROT*ABS(FAN2)*SIGN(1.,Y(1))
        END IF
        FAN3=0.
      ENDIF

      AIJ(1+LK,NC61)=AIJ(1+LK,NC61)-FAN1
      AIJ(2+LK,NC61)=AIJ(2+LK,NC61)-FAN2
      AIJ(3+LK,NC61)=AIJ(3+LK,NC61)-FAN3
      AIJ(4+LK,NC61)=AIJ(4+LK,NC61)-((YPMN-YEFF)*FAN3-(ZPMN-ZEFF)*FAN2)
      AIJ(5+LK,NC61)=AIJ(5+LK,NC61)-((ZPMN-ZEFF)*FAN1-(XPMN-XEFF)*FAN3)
      AIJ(6+LK,NC61)=AIJ(6+LK,NC61)-((XPMN-XEFF)*FAN2-(YPMN-YEFF)*FAN1)
 9    CONTINUE
 11   CONTINUE  !FIN BOUCLE LIGNES ET DEFENSES

!C-- DERIVEE DE Y
      DO 14 I=1,NC6
      DERY(I)=Y(I+NC6)
      DERY(I+NC6)=0.
      DO 13 J=1,NC6
      DERY(I+NC6)=DERY(I+NC6)+AIJ(I,J)*AIJ(J,NC61)
 13   CONTINUE
 14   CONTINUE
      RETURN
      END
