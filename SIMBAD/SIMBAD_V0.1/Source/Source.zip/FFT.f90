       SUBROUTINE FFT(N,ZZ,ICHOIX)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: SOUS-PROGRAMME FFT                               *
!*                                                                      *
!*       CALCUL DE LA TRANSFORMEE DE FOURIER D'UN SIGNAL                *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************

      IMPLICIT NONE
!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
!C--- N: NOMBRE D'ECHANTILLONS
!C--- ZZ: ECHANTILLONS A ANALYSER
!C--- ICHOIX :  1=FFT INVERSE; -1=FFT DIRECTE
      INTEGER::N,ICHOIX,NP,I,II,J,J0,J00,J1,J2,L
      INTEGER::MEX2,MOIT,MP1,NMEX2
      INTEGER::IOX(100)
      REAL::FL,FNP
      COMPLEX::ZZ(1)
      COMPLEX::Z,IM,ZQ,ZR,ZFNP,V
!C----------------------------------------------------------------------
       IM=(0.,1.)
       NP=2**N
       DO 1 I=1,N
        IOX(I)=2**(N-I)
 1     CONTINUE

       DO MP1=1,N
        MEX2=2**(MP1-1)
        NMEX2=NP/MEX2
        MOIT=NMEX2/2
        L=0
        DO J00=1,MEX2
            FL=L
            FNP=NP
            V=ICHOIX*8*ATAN(1.)*FL/FNP
            Z=CEXP(IM*V)
            J0=NMEX2*(J00-1)
            DO 2 I=1,MOIT
                J1=J0+I
                J2=J1+MOIT
                ZQ=Z*ZZ(J2)
                ZZ(J2)=ZZ(J1)-ZQ
                ZZ(J1)=ZZ(J1)+ZQ
 2          CONTINUE
            DO I=2,N
                II=I
                IF((L-IOX(I))<0) THEN
                    GOTO 4
                ELSE IF((L-IOX(I))==0) THEN
                    GOTO 3
                ELSE
                    GOTO 3
                END IF
 3              L=L-IOX(I)
            END DO
 4          L=L+IOX(II)
        END DO
       END DO

       L=0
       DO J=1,NP
        IF((L-J)<0) THEN
            GOTO 5
        ELSE IF((L-J)==0) THEN
            GOTO 32
        ELSE
            GOTO 32
        END IF
 32     ZR=ZZ(J)
        ZZ(J)=ZZ(L+1)
        ZZ(L+1)=ZR
 5      DO I=1,N
            II=I
            IF((L-IOX(I))<0) THEN
                GOTO 7
            ELSE IF((L-IOX(I))==0) THEN
                GOTO 6
            ELSE
                GOTO 6
            END IF
 6          L=L-IOX(I)
        END DO
 7      L=L+IOX(II)
       END DO

       IF((ICHOIX-0)<0) THEN
        GOTO 34
       ELSE IF((ICHOIX-0)==0) THEN
        GOTO 33
       ELSE
        GOTO 33
       END IF

 34    ZFNP=FNP
       DO 8 I=1,NP
        ZZ(I)=ZZ(I)/ZFNP
 8     CONTINUE

 33    RETURN
       END
