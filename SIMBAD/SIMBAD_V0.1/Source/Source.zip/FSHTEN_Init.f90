C***********************************************************************
      SUBROUTINE FSHTEN(IL,DELST0,DELST,EFFSHTEN0,PAS)
************************************************************************
*                                                                      *
*   PROGRAMME SIMBAD: SOUS-PROGRAMME FSHTEN                                  *
*                                                                      *
*      CALCUL DE L'EFFORT AVEC UN SYSTEME AMORTISSEUR                        *
*                                                                      *
************************************************************************
*                                                                      *
*  This file is part of SIMBAD program.                                *
*                                                                      *
*  SIMBAD program is free software: you can redistribute it and/or     *
*  modify it under the terms of the GNU General Public License         *
*  as published by the Free Software Foundation, version 3 of          *
*  the License.                                                        *
*                                                                      *
*  SIMBAD program is distributed in the hope that it will be useful,   *
*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
*  GNU General Public License for more details.                        *
*                                                                      *
*  You should have received a copy of the GNU General Public License   *
*  along with SIMBAD program.                                          *
*  If not, see <https://www.gnu.org/licenses/>.                        *
*                                                                      *
************************************************************************

      IMPLICIT NONE
C--- DEFINITION DES CONSTANTES
C--- NMAX: NOMBRE MAX DE PAS DE TEMPS
C--- NCOR: NOMBRE MAX DE CORPS FLOTTANT
C--- NLIG: NOMBRE MAX DE LIGNES ET DEFENSES
C--- NDEG: DEGRE MAX DU POLYNOME DE RAIDEUR ET AMORTISSEMENT
C--- NMPT: NOMBRE MAX DE POINTS SPECIFIQUES
C--- NMPV: NOMBRE MAX DE PAS DE SERIE TEMPORELLE VENT, COURANT
      INTEGER NMAX,NCOR,NLIG,NDEG,NMPT,NMPV
      PARAMETER(NMAX=72000,NCOR=1,NLIG=22,NDEG=5,NMPT=3,NMPV=28800)
C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
C--- IL: INDICE DE LA LIAISON
C--- DELST0,DELST: DEPLACEMENTS DE LA LIAISON AUX INSTANTS T-DT ET T
C--- EFFSHTEN0: EFFORT (N) DE LA LIAISON A L'INSTANT T-DT
C--- PAS: PAS DE TEMPS DE CALCUL
      INTEGER IL
      REAL DELST0,DELST
      REAL PAS
      REAL EFFMIN,EFFMAX,EFFTOT
      REAL FAMA,VAREFFM,VAREFFD,STROKE
C--- DONNEES COMMUNES POUR LE SYSTEME D'AMARRAGE
      INTEGER NAN,NRAI,IK,NAMO
      REAL XPF,YPF,ZPF,XPM,YPM,ZPM,RL,PT,RAI,PA,AMO
      COMMON /AMAR/NAN,XPF(NLIG),YPF(NLIG),ZPF(NLIG),
     &             XPM(NLIG),YPM(NLIG),ZPM(NLIG),RL(NLIG),PT(NLIG),
     &             NRAI(NLIG),RAI(NLIG,NDEG),IK(NLIG),
     &             PA(NLIG),NAMO(NLIG),AMO(NLIG,NDEG)
C--- DONNEES COMMUNES POUR LES EFFORTS FOURNIS PAR LE SOUS-PROGRAMME
      REAL EFFSHTEN,EFFSHTEN0
      COMMON /SHTEN/EFFSHTEN(NLIG)
C-----------------------------------------------------------------------
      VAREFFM=50000.0
      VAREFFD=50000.0
      STROKE=1.50
      EFFTOT = 588600.0
      IF(STROKE<=0.) WRITE(*,*)'STROKE<=0 in subroutine FSHTEN'
      IF (DELST>0..AND.DELST<=0.5) THEN
        IF((DELST-DELST0)>0.) THEN
            EFFSHTEN(IL)= EFFSHTEN0+VAREFFM*PAS
        ELSE
            EFFSHTEN(IL)= EFFSHTEN0-VAREFFD*PAS
        ENDIF
        EFFMIN = PT(IL)
        EFFMAX = PT(IL)+(DELST*(EFFTOT-PT(IL))/0.5)
        IF(EFFSHTEN(IL)<EFFMIN) EFFSHTEN(IL)=EFFMIN
        IF(EFFSHTEN(IL)>EFFMAX) EFFSHTEN(IL)=EFFMAX
      ENDIF

      IF (DELST>0.5.AND.DELST<=(0.75*STROKE)) THEN
        IF((DELST-DELST0)>0.) THEN
            EFFSHTEN(IL)= EFFSHTEN0+VAREFFM*PAS
        ELSE
            EFFSHTEN(IL)= EFFSHTEN0-VAREFFD*PAS
        ENDIF
        EFFMIN = PT(IL)
        EFFMAX = EFFTOT
        IF(EFFSHTEN(IL)<EFFMIN) EFFSHTEN(IL)=EFFMIN
        IF(EFFSHTEN(IL)>EFFMAX) EFFSHTEN(IL)=EFFMAX
      ENDIF

      IF (DELST>(0.75*STROKE).AND.DELST<=STROKE) THEN
        IF((DELST-DELST0)>0.) THEN
            EFFSHTEN(IL)= EFFSHTEN0+VAREFFM*PAS
        ELSE
            EFFSHTEN(IL)= EFFSHTEN0-VAREFFD*PAS
        ENDIF
        EFFMIN = ((EFFTOT-PT(IL))*DELST+
     & (STROKE*(PT(IL)-0.75*EFFTOT)))/(0.25*STROKE)
        EFFMAX = EFFTOT
        IF(EFFSHTEN(IL)<EFFMIN) EFFSHTEN(IL)=EFFMIN
        IF(EFFSHTEN(IL)>EFFMAX) EFFSHTEN(IL)=EFFMAX
      ENDIF

      IF (DELST>STROKE) THEN
            EFFSHTEN(IL)= EFFTOT+FAMA(IL,(DELST-STROKE))
      ENDIF

      IF (DELST<0.) THEN
            EFFSHTEN(IL)= MAX(FAMA(IL,DELST)+PT(IL),0.)
*       write ( *, '(a)' ) ' '
*       write ( *, '(a,a)' ) 'IL          DELST            ',
*     &      'FAMA'
*       write ( *, '(a)' ) ' '
*       write ( *, '(i3,2x,f10.2,2x,g14.6)' ) IL,DELST,
*     & FAMA(IL,DELST)
      ENDIF

      RETURN
      END
