      SUBROUTINE TRAMOU(ITR)
!************************************************************************
!*                                                                      *
!*     PROGRAMME SIMBAD: SOUS-PROGRAMME TRAMOU                          *
!*                                                                      *
!*     ECRITURE DES SIX MOUVEMENTS DU CORPS                             *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE PARA
      USE RESU
      IMPLICIT NONE
!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
!C--- ITR: CHOIX DU TYPE DE FICHIER RESULTATS
      INTEGER::ITR,K
      CHARACTER(12)::TIT(6)
      CHARACTER(29)::TITR(3)
      CHARACTER(len=12)::TMOV,TVEL,TACC
!C----------------------------------------------------------------------
      TIT(1)=' SURGE      '
      TIT(2)=' SWAY       '
      TIT(3)=' HEAVE      '
      TIT(4)=' ROLL       '
      TIT(5)=' PITCH      '
      TIT(6)=' YAW        '
      TITR(1)='MOVEMENT (M AND DEG)         '
      TITR(2)='VELOCITY (M/S AND �/S)       '
      TITR(3)='ACCELERATION (M2/S AND �/S2) '
      TMOV='MOVCG.RES'
      TVEL='VELCG.RES'
      TACC='ACCCG.RES'
!C--  ECRITURE DES MOUVEMENTS
      IF(ITR.EQ.1)THEN
        OPEN(UNIT=21,FILE=TMOV,STATUS='UNKNOWN')
        WRITE(21,700)TITR(1)
        WRITE(21,701)TIT(1),TIT(2),TIT(3),TIT(4),TIT(5),TIT(6)
        DO 1 K=1,NIT
        WRITE(21,702)TT(K),TM(K,1),TM(K,2),TM(K,3),TM(K,4),TM(K,5),&
     &  TM(K,6)
 1      CONTINUE
        CLOSE(21)
      ENDIF
!C--  ECRITURE DES VITESSES
      IF(ITR.EQ.2)THEN
        OPEN(UNIT=22,FILE=TVEL,STATUS='UNKNOWN')
        WRITE(22,700)TITR(2)
        WRITE(22,701)TIT(1),TIT(2),TIT(3),TIT(4),TIT(5),TIT(6)
        DO 2 K=1,NIT
        WRITE(22,702)TT(K),TM(K,7),TM(K,8),TM(K,9),TM(K,10),TM(K,11),&
     &  TM(K,12)
 2      CONTINUE
        CLOSE(22)
      ENDIF
!C--  ECRITURE DES ACCELERATIONS
      IF(ITR.EQ.3)THEN
        OPEN(UNIT=23,FILE=TACC,STATUS='UNKNOWN')
        WRITE(23,700)TITR(3)
        WRITE(23,701)TIT(1),TIT(2),TIT(3),TIT(4),TIT(5),TIT(6)
        DO 3 K=1,NIT
        WRITE(23,702)TT(K),TM(K,13),TM(K,14),TM(K,15),TM(K,16),TM(K,17),&
     &  TM(K,18)
 3      CONTINUE
        CLOSE(23)
      ENDIF
!C**********************************************************************
  700 FORMAT(/30X,A29/)
  701 FORMAT('   TIME       ',6A12/)
  702 FORMAT(1X,1PE11.4,1X,6(1X,1PE10.3,1X))

      RETURN
      END

      SUBROUTINE TRAPNT(ICHOIX,IPT)
!************************************************************************
!*                                                                      *
!*     PROGRAMME SIMBAD: SOUS-PROGRAMME TRAPNT                          *
!*                                                                      *
!*     ECRITURE DES TROIS MOUVEMENTS DE TRANSLATION EN UN POINT DONNE   *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE PARA
      USE RESU
      IMPLICIT NONE
!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
!C--- ICHOIX: CHOIX DU TYPE DE FICHIER RESULTATS
!C--- IPT: NUMERO DU POINT SPECIFIQUE
      INTEGER::ICHOIX,IPT,K,IJ,IJ1,IJ2
      CHARACTER(12)::TIT(3)
      CHARACTER(29)::TITR(3)
      CHARACTER(len=12)::TMOV,TVEL,TACC
      CHARACTER(2)::IND
!C----------------------------------------------------------------------
      TIT(1)='     X      '
      TIT(2)='     Y      '
      TIT(3)='     Z      '
      TITR(1)='  MOVEMENT (M)               '
      TITR(2)='  VELOCITY (M/S)             '
      TITR(3)='  ACCELERATION (M2/S)        '
      WRITE(IND,'(I2)')IPT
      TMOV='MOVPT'//IND//'.RES'
      TVEL='VELPT'//IND//'.RES'
      TACC='ACCPT'//IND//'.RES'
!C--  ECRITURE DES MOUVEMENTS
      IF(ICHOIX.EQ.4)THEN
      OPEN(UNIT=24,FILE=TMOV,STATUS='UNKNOWN')
      IJ=1+3*(ICHOIX-4)+9*(IPT-1)
      IJ1=IJ+1
      IJ2=IJ+2
        WRITE(24,700)IPT,TITR(1)
        WRITE(24,701)TIT(1),TIT(2),TIT(3)
        DO 1 K=1,NIT
        WRITE(24,702)TT(K),TP(K,IJ),TP(K,IJ1),TP(K,IJ2)
 1      CONTINUE
      CLOSE(24)
      ENDIF
!C--  ECRITURE DES VITESSES
      IF(ICHOIX.EQ.5)THEN
      OPEN(UNIT=25,FILE=TVEL,STATUS='UNKNOWN')
      IJ=1+3*(ICHOIX-4)+9*(IPT-1)
      IJ1=IJ+1
      IJ2=IJ+2
        WRITE(25,700)IPT,TITR(2)
        WRITE(25,701)TIT(1),TIT(2),TIT(3)
        DO 2 K=1,NIT
        WRITE(25,702)TT(K),TP(K,IJ),TP(K,IJ1),TP(K,IJ2)
 2      CONTINUE
      CLOSE(25)
      ENDIF
!C--  ECRITURE DES ACCELERATIONS
      IF(ICHOIX.EQ.6)THEN
      OPEN(UNIT=26,FILE=TACC,STATUS='UNKNOWN')
      IJ=1+3*(ICHOIX-4)+9*(IPT-1)
      IJ1=IJ+1
      IJ2=IJ+2
        WRITE(26,700)IPT,TITR(3)
        WRITE(26,701)TIT(1),TIT(2),TIT(3)
        DO 3 K=1,NIT
        WRITE(26,702)TT(K),TP(K,IJ),TP(K,IJ1),TP(K,IJ2)
 3      CONTINUE
      CLOSE(26)
      ENDIF
!C**********************************************************************
  700 FORMAT(/8X,'POINT: ',I4,A29/)
  701 FORMAT('   TIME       ',3A12/)
  702 FORMAT(1X,1PE11.4,1X,3(1X,1PE10.3,1X))

      RETURN
      END

      SUBROUTINE TRATEN(NAN)
!************************************************************************
!*                                                                      *
!*  PROGRAMME SIMBAD: SOUS-PROGRAMME TRATEN                             *
!*                                                                      *
!*     TRACE DES TENSIONS DANS LES AMARRES                              *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE PARA
      USE RESU
      IMPLICIT NONE
!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
!C--- NAN: NOMBRE DE LIGNES ET DE DEFENSES
      INTEGER::NAN,K,J,I
      CHARACTER(29)::TITR(2)
      CHARACTER(12)::TTENS
!C----------------------------------------------------------------------
      TITR(1)='TENSIONS IN LINES            '
      TITR(2)='NUMBER OF LINES: '
      TTENS='LINES.RES'
!C--  ECRITURE DES EFFORTS DANS LES LIGNES ET DUCS D'ALBE
      OPEN(UNIT=27,FILE=TTENS,STATUS='UNKNOWN')
      WRITE(27,700)TITR(1)
      WRITE(27,701)TITR(2),NAN
      WRITE(27,702)(I,I=1,NAN)
      DO 1 K=1,NIT
        WRITE(27,703)TT(K),(TL(K,J),J=1,NAN)
 1    CONTINUE
      CLOSE(27)
!C**********************************************************************
  700 FORMAT(/15X,A29/)
  701 FORMAT(/15X,A29,I4/)
  702 FORMAT('   TIME    ',22I12/)
  703 FORMAT(1X,1PE11.4,1X,22(1X,1PE10.3,1X))

      RETURN
      END

!CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
