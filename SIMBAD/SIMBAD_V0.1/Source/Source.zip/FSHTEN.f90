!C***********************************************************************
      SUBROUTINE FSHTEN(IL,DELST,DELTP,EFFSHTEN0)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: SOUS-PROGRAMME FSHTEN                                  *
!*                                                                      *
!*      CALCUL DE L'EFFORT AVEC UN SYSTEME AMORTISSEUR                        *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE AMAR
      USE SHTEN
      IMPLICIT NONE
!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
!C--- IL: INDICE DE LA LIAISON
!C--- DELST0,DELST: DEPLACEMENTS DE LA LIAISON AUX INSTANTS T-DT ET T
!C--- EFFSHTEN0: EFFORT (N) DE LA LIAISON A L'INSTANT T-DT
!C--- DELTP: VITESSE DE DEPLACEMENT DE LA LIAISON
      INTEGER::IL
      REAL::DELST,DELTP
      REAL::EFFMIN,EFFMAX,EFFBAND
      REAL::FAMA,RAID,AMORT,STROKE
      REAL::EFFSHTEN0
!C-----------------------------------------------------------------------
!*      RAID= 600000.0
!*      AMORT= 9500000.0
      RAID= 850000.0
      AMORT= 650000.0
      STROKE= 1.5
      EFFMIN = PT(IL)
      EFFMAX = 60000.0*9.81
      EFFBAND=75000.0

      IF(STROKE<=0.) WRITE(*,*)'STROKE<=0 in subroutine FSHTEN'
!C-----------------------------------------------------------------------
      IF (DELST>=0..AND.DELST<=STROKE) THEN
        EFFSHTEN(IL)= RAID*DELST+PT(IL)
        IF(EFFSHTEN(IL)>(EFFMAX-EFFBAND)) THEN
            EFFSHTEN(IL)= EFFSHTEN0+AMORT*DELTP
        ENDIF
        IF(EFFSHTEN(IL)<(EFFMIN+EFFBAND)) THEN
            EFFSHTEN(IL)= EFFSHTEN0+AMORT*DELTP
        ENDIF
        IF(EFFSHTEN(IL)<EFFMIN) EFFSHTEN(IL)=EFFMIN
        IF(EFFSHTEN(IL)>EFFMAX) EFFSHTEN(IL)=EFFMAX
      ENDIF

      IF (DELST>STROKE) THEN
            EFFSHTEN(IL)= EFFMAX+FAMA(IL,(DELST-STROKE))

!*       write ( *, '(a)' ) ' '
!*       write ( *, '(a,a)' ) 'IL          DELST            ',
!*     &      'FAMA'
!*       write ( *, '(a)' ) ' '
!*       write ( *, '(i3,2x,f10.2,2x,g14.6)' ) IL,DELST,
!*     & FAMA(IL,DELST)

      ENDIF

      IF (DELST<0.) THEN
            EFFSHTEN(IL)= MAX(FAMA(IL,DELST)+PT(IL),0.)
      ENDIF

      RETURN
      END
