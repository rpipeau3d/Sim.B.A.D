!C***********************************************************************
      FUNCTION V(T)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: FONCTION V                                       *
!*                                                                      *
!*      CALCUL DE LA VITESSE DU VENT A L'INSTANT T PAR INTERPOLATION    *
!*      DANS LE SIGNAL CONNU POINT PAR POINT.                           *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE VENT
      IMPLICIT NONE
!C--- PARAMETRES FONCTION
!C--- V: VITESSE VENT A INSTANT T
!C--- T: INSTANT T
      REAL::V,T,TT
      INTEGER::I
!C----------------------------------------------------------------------
      TT=MOD(T,TMAX)
      DO 1 I=2,NV
      IF(TT.GE.TV(I))GOTO 1
      V=VV(I-1)+(VV(I)-VV(I-1))*(TT-TV(I-1))/(TV(I)-TV(I-1))
      GOTO 2
 1    CONTINUE
 2    CONTINUE
      RETURN
      END
