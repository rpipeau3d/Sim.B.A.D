      SUBROUTINE LECIRREG()
!************************************************************************
!*                                                                      *
!*     PROGRAMME SIMBAD: SOUS-PROGRAMME LECIRREG                        *
!*                                                                      *
!*     LECTURE DES FICHIERS D'EFFORTS DE HOULE                          *
!*     ET DES TERMES DE REPONSE EN IMPULSION POUR LA RADIATION (IRF)    *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE HIRR
      USE IRTN
      IMPLICIT NONE

!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
      CHARACTER(12)::TWAV,TRAD
      CHARACTER(13)::TDRI
      INTEGER::IC1,I,J,K,L1,L2,IEFH,IDER,Iiref,IRD,JRD,JCOR
!C----------------------------------------------------------------------
      TWAV='wave_for.txt'
      TDRI='drift_for.txt'
      TRAD='rad_IRF.txt'
!C--  LECTURE DES EFFORTS DE HOULE
      OPEN(UNIT=31,FILE=TWAV,STATUS='UNKNOWN')
      READ(31,*)NHIR
!C--  CONTROLE DU NOMBRE DE PAS DE TEMPS
      IF(NHIR.GT.NMAX)THEN
        WRITE(*,*)'NUMBER OF WAVE FILE TIME STEPS: NHIR>72000',&
     &  '; STOP OF RUN'
        WRITE(*,*)'OK? WRITE 0'
        READ(*,*)IC1
        STOP
      ENDIF
      DO 3 K=1,NCOR
      DO 2 I=1,6
        READ(31,*)IEFH
        DO 1 J=1,NHIR
            READ(31,*)THOU(J),EFHOUL(I,J,K)
 1      CONTINUE
 2    CONTINUE
 3    CONTINUE
      THOMAX = THOU(NHIR)
      REWIND(31)

!C---  LECTURE DES EFFORTS DE DERIVE
      OPEN(UNIT=32,FILE=TDRI,STATUS='UNKNOWN')
      READ(32,*)NHIR
!C--  CONTROLE DU NOMBRE DE PAS DE TEMPS
      IF(NHIR.GT.NMAX)THEN
        WRITE(*,*)'NUMBER OF WAVE FILE TIME STEPS: NHIR>72000',&
     &  '; STOP OF RUN'
        WRITE(*,*)'OK? WRITE 0'
        READ(*,*)IC1
        STOP
      ENDIF
!C--  EFFORTS DE DERIVE MIS A ZERO
      DO 6 K=1,NCOR
      DO 5 I=1,6
        DO 4 J=1,NHIR
            EFDRIF(I,J,K)=0.
 4      CONTINUE
 5    CONTINUE
 6    CONTINUE
!C-- LECTURE DES VALEURS NON NULLES D'EFFORTS DERIVE
      DO 9 K=1,NCOR
      DO 8 I=1,3
        READ(32,*)IDER
        IDER = IDER+1
        DO 7 J=1,NHIR
            READ(32,*)THOU(J),EFDRIF(IDER,J,K)
 7      CONTINUE
 8    CONTINUE
 9    CONTINUE
      THOMAX = THOU(NHIR)
      REWIND(32)

!C---  LECTURE DES IRF DE RADIATION
      OPEN(UNIT=33,FILE=TRAD,STATUS='UNKNOWN')
      READ(33,*)NStepRdtn
      NStepRdtn1 = NStepRdtn+1
      READ(33,*)Iiref
!C--  CONTROLE DU NOMBRE DE PAS DE TEMPS
      IF(NStepRdtn.GT.NIRDTN)THEN
        WRITE(*,*)'NUMBER OF RADIATION DAMPING TIME STEPS >1000',&
     &  '; STOP OF RUN'
        WRITE(*,*)'OK? WRITE 0'
        READ(*,*)IC1
        STOP
      ENDIF
!C-- MISE A ZERO DES VALEURS D'IRF D'AMORTISSEMENT RADIATION
      DO L1=1,NCOR
        DO 13 L2=1,NCOR
            DO 12 I=1,6
                DO 11 J=1,6
                    DO 10 K=1,NStepRdtn
                    RdtnKrnl(K,I,J,L1,L2)= 0.
 10                 CONTINUE
 11             CONTINUE
 12         CONTINUE
 13     CONTINUE
      END DO
!C-- LECTURE DES VALEURS NON NULLES D'IRF D'AMORTISSEMENT RADIATION
      DO L1=1,NCOR
        DO 16 L2=1,NCOR
            DO 15 I=1,Iiref
                READ(33,*)IRD,JRD
                IRD=IRD+1
                JRD=JRD+1
                DO 14 K=1,NStepRdtn
                    READ(33,*)RdtnTime(K),RdtnKrnl(K,IRD,JRD,L1,L2)
 14             CONTINUE
 15         CONTINUE
 16     CONTINUE
      END DO

      RdtnTMax = RdtnTime(NStepRdtn)
      REWIND(33)

!C-- MISE A ZERO DES VALEURS SAUVEGARDEES DES VITESSES
      JCOR = 6*NCOR
      DO 18 I=1,NStepRdtn
        DO 17 J=1,JCOR
            YHist(I,J)= 0.
 17     CONTINUE
 18   CONTINUE

      RETURN
      END

!CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
