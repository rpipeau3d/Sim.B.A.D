!C***********************************************************************
      SUBROUTINE PV(X1,Y1,Z1,X2,Y2,Z2,X3,Y3,Z3)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: SOUS-PROGRAMME PV                                *
!*                                                                      *
!*     PRODUIT VECTORIEL                                                *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************

      IMPLICIT NONE
!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
      REAL::X1,Y1,Z1,X2,Y2,Z2,X3,Y3,Z3
!C----------------------------------------------------------------------
      X3=Y1*Z2-Z1*Y2
      Y3=Z1*X2-X1*Z2
      Z3=X1*Y2-Y1*X2
      RETURN
      END
