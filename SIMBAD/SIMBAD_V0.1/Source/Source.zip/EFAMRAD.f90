!C***********************************************************************
      SUBROUTINE EFAMRAD(T,Y,ID,KC)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: SUBROUTINE EFAMRAD                               *
!*                                                                      *
!*      CALCUL DES AMORTISSEMENTS DE RADIATION                          *
!*      AVEC EFFETS MEMOIRE.                                            *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE PARA
      USE IRTN
      USE EFRD
      IMPLICIT NONE

!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
!C--- T: INSTANT T
!C--- Y: MOUVEMENTS DU CENTRE DE GRAVITE A L'INSTANT T
!C--- ID: INDICE DU MOUVEMENT
!C--- KC: INDICE DU CORPS FLOTTANT
      INTEGER::ID,KC,K,L,J,JL
      REAL::T,F_Rdtn
      REAL::Y(*)
!C***********************************************************************
!C      MISE A ZERO INITIALE
!C***********************************************************************
      F_Rdtn = 0.

!C**********************************************************************
!C     CONVOLUTION POUR DETERMINER L'AMORTISSEMENT
!C     DE RADIATION AVEC EFFET MEMOIRE
!C**********************************************************************
      DO 10 L=1,NC

        DO 5 J = 1,6
          JL=J+6*(L-1)
          DO  4 K = 2,NStepRdtn-1
           F_Rdtn = F_Rdtn&
     &       + RdtnKrnl(K,ID,J,L,KC)&
     &       *YHist(NStepRdtn1-K,JL)
 4        CONTINUE

          F_Rdtn = F_Rdtn&
     &    + (RdtnKrnl(1,ID,J,L,KC)*Y(JL+6*NC)&
     &    + RdtnKrnl(NStepRdtn,ID,J,L,KC)*YHist(1,JL))/2
 5       CONTINUE

 10   CONTINUE

      FAM(ID,KC) = PAST*F_Rdtn

      RETURN
      END
