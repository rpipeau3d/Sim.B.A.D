!C***********************************************************************
      FUNCTION FAMA(I,D)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: FONCTION FAMA                                    *
!*                                                                      *
!*      CALCUL DU RAPPEL DANS CHAQUE AMARRE (RESSORT EN TRACTION)       *
!*      ET DE LA REACTION DU DUC D'ALBE (RESSORT EN COMPRESSION)        *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE AMAR
      IMPLICIT NONE
!C--- PARAMETRES FORMELS DE LA FONCTION
!C--- I: INDICE DE LIGNE OU DEFENSE
!C--- D: EXTENSION DE LIGNE OU COMPRESSION DE DEFENSE
      INTEGER::I,J
      REAL::D,FAMA
!C-----------------------------------------------------------------------
!*      IF(IK(I).EQ.1.OR.IK(I).EQ.-1)THEN
        FAMA=RAI(I,NRAI(I))
        DO 1 J=NRAI(I),2,-1
            FAMA=FAMA*D+RAI(I,J-1)
 1      CONTINUE
        FAMA=FAMA*D
!*      ENDIF
!C-----------------------------------------------------------------------
      RETURN
      END
