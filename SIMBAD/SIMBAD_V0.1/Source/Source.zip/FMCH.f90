!C***********************************************************************
      SUBROUTINE FMCH(T,FMCX,FMCY,FMCZ)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: SOUS-PROGRAMME FMCH                              *
!*                                                                      *
!*      CALCUL DES EFFORTS A L'INSTANT T PAR INTERPOLATION              *
!*      DANS LE SIGNAL CONNU POINT PAR POINT.                           *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE CHENAL
      IMPLICIT NONE
!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
!C--- T: INSTANT T
!C--- FMCX,FMCY,FMCZ: EFFORTS INDUITS PAR LE NAVIRE CHENALANT A L'INSTANT T
      REAL::T,FMCX,FMCY,FMCZ
      INTEGER::I
!C***********************************************************************
      DO 1 I=2,NCH
      IF(T.GE.TCH(I).AND.T.LE.TCHMAX)GOTO 1
       IF(T.LE.TCHMAX)THEN
       FMCX=FXCH(I-1)+(FXCH(I)-FXCH(I-1))*(T-TCH(I-1))/(TCH(I)-TCH(I-1))
       FMCY=FYCH(I-1)+(FYCH(I)-FYCH(I-1))*(T-TCH(I-1))/(TCH(I)-TCH(I-1))
       FMCZ=FZCH(I-1)+(FZCH(I)-FZCH(I-1))*(T-TCH(I-1))/(TCH(I)-TCH(I-1))
       ELSE
       FMCX=0.
       FMCY=0.
       FMCZ=0.
       ENDIF
      GOTO 2
 1    CONTINUE
!C***********************************************************************
 2    RETURN
      END
