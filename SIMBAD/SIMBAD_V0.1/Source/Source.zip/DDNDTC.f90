SUBROUTINE DDNDTC(KRES,ZGC,IP,PAST,EPSX)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: SOUS-PROGRAMME DDNDTC                            *
!*                                                                      *
!*     TRAITEMENT DE DONNEES                                            *
!*     ANALYSE SPECTRALE D'UN SIGNAL AMORTI PAR UNE                     *
!*     METHODE FFT COUPLEE A UNE INTERPOLATION SPECTRALE                *
!*                                                                      *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************

      USE CONSTANTS
      USE REFT
      IMPLICIT NONE
!--- IAMAX: NOMBRE DE PICS
      INTEGER,PARAMETER::IAMAX=2000
!--- PARAMETRES FORMELS DU SOUS-PROGRAMME
!--- KRES :  POSITION INDICE DANS TABLEAUX DES RESULTATS
!--- ZGC  :  TABLEAU DES VALEURS A ANALYSER
!--- IP   :  NOMBRE DE POINTS 2**IP <=8198 (IP=13)
!--- PAST :  PAS DE TEMPS
!--- EPSX :  SEUIL DE DETECTION DES PICS
      INTEGER::KRES,IP,KZERO(IAMAX),KWW(IAMAX)
      INTEGER::N,NS2,NM1,NS2M1,J,ICHOI,JFOND
      INTEGER::L,LMAX,LM,K,KA,KB,KC
      INTEGER::K1,K1M1,K1P1,KKK,KMAX1,KMAX2,NM
      COMPLEX::ZGC(*),ZZ1(IAMAX),ZK(IAMAX)
      COMPLEX::ZI,ZXM,ZC1,ZKCHAP,ZMU,ZPM
      REAL::PAST,EPSX
      REAL::  AC(4),EPS(IAMAX),AZERO(IAMAX) &
     &       ,OMEG(IAMAX),FREK(IAMAX),FIK(IAMAX) &
     &       ,ALA(IAMAX)
      REAL::PI,T,DOMEGA,PSN
      REAL::XXMAX,XABS,EPSS,GRANTA,PID,P1,P2
      REAL::AIM,AMAX,ARE
!----------------------------------------------------------------------
      PI=4.*ATAN(1.)
      ZI=(0.,1.)
      N=2**IP
      T=(N-1)*PAST
      NS2=N/2
      NM1=N-1
      NS2M1=NS2-1
      DOMEGA=1./T
      PSN=PI/N
      ZXM=(0.,0.)
      XMIN(KRES)=REAL(ZGC(1))
      XMAX(KRES)=REAL(ZGC(1))
!-- SOMME DES VALEURS, DETERMINATION DU MINIMUM ET MAXIMUM
      DO 71 J=1,N
      ZXM=ZXM+ZGC(J)
      XMIN(KRES)=MIN(XMIN(KRES),REAL(ZGC(J)))
      XMAX(KRES)=MAX(XMAX(KRES),REAL(ZGC(J)))
 71   CONTINUE
!-- DIFFERENCE ENTRE MIN ET MAX, MOYENNE
      XDEL(KRES)=XMAX(KRES)-XMIN(KRES)
      ZXM=ZXM/N
      XMOY(KRES)=ZXM
!-- VARIANCE, ECART-TYPE
      XVAR(KRES)=0.
      DO 70 J=1,N
      XVAR(KRES)=XVAR(KRES)+(ZGC(J)-XMOY(KRES))**2
      ZGC(J)=(ZGC(J)-ZXM)*.5*(1.-COS(2*PI*(J-1)/(N-1.)))
 70   CONTINUE
      XVAR(KRES)=SQRT(XVAR(KRES)/N)
!-- TRANSFORMEE DE FOURIER, DETERMINATION DES FREQUENCES
      ICHOI=-1
      CALL FFT(IP,ZGC,ICHOI)
      XXMAX=ABS(ZGC(1))
      DO 2 J=1,NS2
      XABS=ABS(ZGC(J))
      IF(XABS.LT.XXMAX) GOTO 2
      XXMAX=XABS
      JFOND=J
 2    CONTINUE
      EPSS=EPSX*XXMAX
!*
!-- CALCUL DU MAXIMUM : REPERAGE DES PICS
!*
      PID=2.*PI*DOMEGA
      L=0
      K=0
 3    K=K+1
 4    AC(1)=ABS(ZGC(K))
      AC(2)=ABS(ZGC(K+1))
      AC(3)=ABS(ZGC(K+2))
      GRANTA=0.
      DO 666 NM=1,3
      IF(AC(NM).GE.GRANTA)GRANTA=AC(NM)
 666  CONTINUE
      IF((GRANTA-EPSS).LT.0.) GOTO 5
      P1=AC(2)-AC(1)
      P2=AC(3)-AC(2)
      IF(P1.LT.0.) GOTO 5
      IF(P1*P2.GE.0.) GOTO 5
      L=L+1
      KZERO(L)=K+1
      GOTO 9
 5    IF((K+2-NS2)<0) THEN
        GOTO 3
      ELSE IF ((K+2-NS2)==0) THEN
        GOTO 8
      ELSE
        GOTO 8
      END IF
 9    K=K+1
      IF((K+3-NS2)<0) THEN
        GOTO 4
      ELSE IF ((K+3-NS2)==0) THEN
        GOTO 8
      ELSE
        GOTO 8
      END IF
 8    LMAX=L
      IF(LMAX.GE.IAMAX)LMAX=IAMAX
!*     IF(LMAX.EQ.0)WRITE(*,901)
!*
!-- DETERMINATION DE EPSILON
!*
      LM=0
      DO 11 K=1,LMAX
      KA=KZERO(K)
      KB=KA-1
      KC=KA+1
      ZKCHAP=(ZGC(KA)-ZGC(KB))/(ZGC(KA)-ZGC(KC))
      ZK(K)=ZI*4.*PI*(ZKCHAP-1.)/(ZKCHAP+1.)
      ARE=ZI*ZK(K)/(2.*PI)
      IF(ABS(ARE).GE.1.)GOTO 11
      LM=LM+1
      KWW(LM)=KZERO(K)
      ZK(LM)=ZK(K)
 11   CONTINUE
      LMAX=LM
      KKK=0
      AMAX=0.
      KMAX1=1
      DO 12 K=1,LMAX
      K1=KWW(K)
      K1M1=K1-1
      K1P1=K1+1
      ZMU=ZK(K)/(ZI*2.*PI)
      ZPM=(-1.)/(ZMU*(ZMU-1.)*(ZMU+1.))
      ZC1=ZI*PI*(4.-ZMU*ZMU)/((EXP(-ZK(K))-1.)*6.*ZPM)
      ZZ1(K)=-(2.*ZGC(K1)-ZGC(K1P1)-ZGC(K1M1))*ZC1
      ARE=ZZ1(K)
      AIM=-ZI*ZZ1(K)
      AZERO(K)=4.*SQRT(ARE*ARE+AIM*AIM)
      FIK(K)=ATAN2(AIM,ARE)*180./PI
      EPS(K)=ZI*ZK(K)/(2.*PI)
      ALA(K)=ZK(K)/T
      FREK(K)=(K1-1+EPS(K))*DOMEGA
      OMEG(K)=1./FREK(K)
      IF(AZERO(K).GT.AMAX)THEN
      AMAX=AZERO(K)
      KMAX1=K
      ENDIF
 12   CONTINUE
      AMAX=0.
      KMAX2=1
      DO 13 K=1,LMAX
      IF(AZERO(K).GT.AMAX.AND.K.NE.KMAX1)THEN
      AMAX=AZERO(K)
      KMAX2=K
      ENDIF
 13   CONTINUE
      IF(AZERO(KMAX1).GT.AZERO(KMAX2))THEN
      XP1(KRES)=OMEG(KMAX1)
      XA1(KRES)=AZERO(KMAX1)
      XP2(KRES)=OMEG(KMAX2)
      XA2(KRES)=AZERO(KMAX2)
      ELSE
      XP1(KRES)=OMEG(KMAX2)
      XA1(KRES)=AZERO(KMAX2)
      XP2(KRES)=OMEG(KMAX1)
      XA2(KRES)=AZERO(KMAX1)
      ENDIF
      IF(KMAX1.EQ.KMAX2)THEN
      XP2(KRES)=0.
      XA2(KRES)=0.
      ENDIF
!* 901  FORMAT(5X,'ERROR :LMAX=0 OU > 10')
      RETURN
      END
