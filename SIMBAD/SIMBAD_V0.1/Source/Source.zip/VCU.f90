!C***********************************************************************
      FUNCTION VCU(T)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: FONCTION VCU                                     *
!*                                                                      *
!*      CALCUL DE LA VITESSE DU COURANT A L'INSTANT T PAR INTERPOLATION *
!*      DANS LE SIGNAL CONNU POINT PAR POINT.                           *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE COURANT
      IMPLICIT NONE
!C--- PARAMETRES FONCTION
!C--- VCU: VITESSE COURANT A INSTANT T
!C--- T: INSTANT T
      REAL::VCU,T,TT
      INTEGER::I
!C----------------------------------------------------------------------
      TT=MOD(T,TCURMAX)
      DO 1 I=2,NCUR
        IF(TT.GE.TCUR(I))GOTO 1
        VCU=VCUR(I-1)+(VCUR(I)-VCUR(I-1))&
     &  *(TT-TCUR(I-1))/(TCUR(I)-TCUR(I-1))
        GOTO 2
 1    CONTINUE
 2    CONTINUE
      RETURN
      END
