!C***********************************************************************
      SUBROUTINE GAUSS(A,NMAX,N,M,EPS)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: SOUS-PROGRAMME GAUSS                             *
!*                                                                      *
!*     RESOLUTION D'UN SYSTEME LINEAIRE                                 *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************

      IMPLICIT NONE
!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
      INTEGER NMAX,N,M,I,J,K,L,IL
      REAL A(NMAX,1)
      REAL EPS,C,P
!C-----------------------------------------------------------------------
      DO 10 J=1,N-1
        K=J

        DO 20 I=J+1,N
        IF((ABS(A(K,J))-ABS(A(I,J)))<0) THEN
            GOTO 30
        ELSE IF ((ABS(A(K,J))-ABS(A(I,J)))==0) THEN
            GOTO 20
        ELSE
            GOTO 20
        END IF
   30   K=I
   20   CONTINUE

        IF((K-J)<0) THEN
            GOTO 50
        ELSE IF ((K-J)==0) THEN
            GOTO 40
        ELSE
            GOTO 50
        END IF

   50   DO 60 L=J,M
        C=A(J,L)
        A(J,L)=A(K,L)
        A(K,L)=C
   60   CONTINUE

   40   IF((ABS(A(J,J))-EPS)<0) THEN
            GOTO 120
        ELSE IF((ABS(A(J,J))-EPS)==0) THEN
            GOTO 120
        ELSE
            GOTO 70
        END IF

   70   DO 80 K=J+1,M
            P=A(J,K)/A(J,J)
            DO I=J+1,N
                A(I,K)=A(I,K)-A(I,J)*P
            END DO
   80   CONTINUE

   10 CONTINUE

      IF((ABS(A(N,N))-EPS)<0) THEN
        GOTO 120
      ELSE IF((ABS(A(N,N))-EPS)==0) THEN
        GOTO 120
      ELSE
        GOTO 90
      END IF

   90 DO 100 IL=N+1,M
        DO J=N,1,-1
            A(J,IL)=A(J,IL)/A(J,J)
            DO I=1,J-1
                A(I,IL)=A(I,IL)-A(I,J)*A(J,IL)
            END DO
        END DO
  100 CONTINUE
      RETURN

  120 WRITE(*,500)EPS
  500 FORMAT(5X,'PIVOT INFERIEUR A ',1PE16.6)
      STOP
      END
