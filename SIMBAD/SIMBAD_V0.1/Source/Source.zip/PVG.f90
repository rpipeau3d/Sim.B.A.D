!C***********************************************************************
      SUBROUTINE PVG(X,DERX,X1,Y1,Z1,X2,Y2,Z2,VX2,VY2,VZ2,&
     &GX2,GY2,GZ2)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: SOUS-PROGRAMME PVG                               *
!*                                                                      *
!*      CALCUL DE LA POSITION COURANTE D'UN POINT DU CORPS,             *
!*      DE LA VITESSE ET DE L'ACCELERATION EN CE POINT.                 *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE PARA
      IMPLICIT NONE
!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
!C--- X,DERX: MOUVEMENTS ET VITESSES DU CENTRE DE GRAVITE A L'INSTANT T
!C--- X1,Y1,Z1: POSITION INITIALE A L'INSTANT T0 DANS LE REPERE FIXE
!C--- X2,Y2,Z2: POSITION A L'INSTANT T DANS LE REPERE FIXE
!C--- VX2,VY2,VZ2: VITESSE A L'INSTANT T DANS LE REPERE FIXE
!C--- GX2,GY2,GZ2: ACCELERATION A L'INSTANT T DANS LE REPERE FIXE
      REAL::X(*),DERX(*)
      REAL::X1,Y1,Z1,X2,Y2,Z2,VX2,VY2,VZ2,GX2,GY2,GZ2
      REAL::TH,ST,CT
      REAL::XP1,YP1,ZP1,XP2,YP2,ZP2,XP3,YP3,ZP3,XP4,YP4,ZP4
!C----------------------------------------------------------------------
      TH=SQRT(X(4)**2+X(5)**2+X(6)**2)
      IF(TH.LE.1.E-5)THEN
        ST=1
        CT=.5
      ELSE
        ST=SIN(TH)/TH
        CT=(1.-COS(TH))/(TH*TH)
      ENDIF
      CALL PV(X(4),X(5),X(6),X1-XEFF,Y1-YEFF,Z1-ZEFF,XP1,YP1,ZP1)
      CALL PV(X(4),X(5),X(6),XP1,YP1,ZP1,XP2,YP2,ZP2)
      X2=X1+X(1)+ST*XP1+CT*XP2
      Y2=Y1+X(2)+ST*YP1+CT*YP2
      Z2=Z1+X(3)+ST*ZP1+CT*ZP2
      CALL PV(X(10),X(11),X(12),X2-XEFF,Y2-YEFF,Z2-ZEFF,XP1,YP1,ZP1)
      VX2=X(7)+XP1
      VY2=X(8)+YP1
      VZ2=X(9)+ZP1
      CALL PV(X(10),X(11),X(12),XP1,YP1,ZP1,XP2,YP2,ZP2)
      CALL PV(X(10),X(11),X(12),X(7),X(8),X(9),XP3,YP3,ZP3)
      CALL PV(DERX(10),DERX(11),DERX(12),X2-XEFF,Y2-YEFF,Z2-ZEFF&
     &,XP4,YP4,ZP4)
      GX2=DERX(7)+XP4+XP3+XP2
      GY2=DERX(8)+YP4+YP3+YP2
      GZ2=DERX(9)+ZP4+ZP3+ZP2
      RETURN
      END
