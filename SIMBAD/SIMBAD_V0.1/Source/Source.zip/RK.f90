!C***********************************************************************
      SUBROUTINE RK(NC,Y,DERY,T,PAS,FCT)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: SOUS-PROGRAMME RK                                *
!*                                                                      *
!*      RESOLUTION D'UN SYSTEME DIFFERENTIEL PAR UNE METHODE DE         *
!*      RUNGE-KUTTA.                                                    *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*    FCT : SOUS-PROGRAMME DE CALCUL DE LA DERIVEE DE Y AU TEMPS T      *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      IMPLICIT NONE
!C--- PARAMETRES DU SOUS-PROGRAMME
!C--- NC: NOMBRE DE CORPS FLOTTANT
!C--- Y,DERY: MOUVEMENTS ET VITESSES DU CENTRE DE GRAVITE A L'INSTANT T
!C--- T: INSTANT T
!C--- PAS: PAS DE TEMPS DE CALCUL
!C--- FCT: SOUS-PROGRAMME DE CALCUL DE LA DERIVEE DE Y AU TEMPS T
      INTEGER::N,NC,I
      REAL::T,PAS
      REAL::Y(*),DERY(*),YP1(12*NCOR),YF(12*NCOR)
      REAL::AK,TT
!C----------------------------------------------------------------------
      N=12*NC
      CALL FCT(T,Y,DERY)
      DO 1 I=1,N
      AK=PAS*DERY(I)
      YP1(I)=Y(I)+AK/6.
      YF(I)=Y(I)+0.5*AK
 1    CONTINUE
      TT=T+.5*PAS
      CALL FCT(TT,YF,DERY)
      DO 2 I=1,N
      AK=PAS*DERY(I)
      YP1(I)=YP1(I)+AK/3.
      YF(I)=Y(I)+.5*AK
 2    CONTINUE
      CALL FCT(TT,YF,DERY)
      DO 3 I=1,N
      AK=PAS*DERY(I)
      YP1(I)=YP1(I)+AK/3.
      YF(I)=Y(I)+AK
 3    CONTINUE
      T=T+PAS
      CALL FCT(T,YF,DERY)
      DO 4 I=1,N
      Y(I)=YP1(I)+PAS*DERY(I)/6.
 4    CONTINUE
      RETURN
      END
