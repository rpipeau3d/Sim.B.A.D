!C***********************************************************************
      SUBROUTINE FAUTMO(IL,DELT0,DELT,T0,T,ANGAMO,reset0,reset)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: SOUS-PROGRAMME FAUTMO                                  *
!*                                                                      *
!*      CALCUL DU RAPPEL DANS UNE LIAISON RIGIDE                        *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE AMAR
      USE AUTMO
      IMPLICIT NONE
!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
!C--- IL: INDICE DE LA LIAISON
!C--- DELT0,DELT: DEPLACEMENTS DE LA LIAISON AUX INSTANTS T-DT ET T
!C--- T0,T: INSTANTS DU CALCUL A T ET T+DT
!C--- ANGAMO: ANGLE PRIS PAR LA LIAISON
!C--- RESET0,RESET: ACTIONS INTEGRALE A T ET T+DT
      INTEGER IL,I
      REAL DELT0,DELT,T0,T,ANGAMO,reset0,reset
      REAL CVAR,EFF
      REAL AMOANG(19),AMOFOR(19)
!C--- DONNEES EFFORTS INDUITS PAR LA LIAISON RIGIDE (EN kN) EN FONCTION DE L'ANGLE
      DATA AMOANG/0.,10.,20.,30.,40.,50.,60.,70.,80.,90.,&
     & 100.,110.,120.,130.,140.,150.,160.,170.,180./
      DATA AMOFOR/100.,93.32,90.04,89.61,91.97,97.49,107.19,123.19,&
     & 150.16,231.99,150.16,123.19,107.19,97.49,91.97,89.61,90.04,93.32,&
     & 100.00/
!C-----------------------------------------------------------------------

      IF(IK(IL).EQ.2)THEN
        CALL PID_main(DELT0,DELT,T0,T,CVAR,reset0,reset)
        DO 1 I=2,19
         IF(ANGAMO.GE.AMOANG(I))GOTO 1
         EFF=AMOFOR(I-1)+(AMOFOR(I)-AMOFOR(I-1))*(ANGAMO-AMOANG(I-1))&
     &   /(AMOANG(I)-AMOANG(I-1))
         EFF = EFF*1000
         GOTO 2
 1      CONTINUE
 2      CONTINUE
        EFFAUTMO(IL)=NRAI(IL)*CVAR*EFF
      ENDIF

      RETURN
      END
