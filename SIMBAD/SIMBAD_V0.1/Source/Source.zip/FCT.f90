!C***********************************************************************
      SUBROUTINE FCT(T,Y,DERY)
!************************************************************************
!*                                                                      *
!*  PROGRAMME SIMBAD: SOUS-PROGRAMME FCT                                *
!*                                                                      *
!*      CALCUL DE LA DERIVEE DE Y AU TEMPS T                            *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE PARA
      USE COEF
      USE AMAR
      USE VENT
      USE CHENAL
      USE MATR
      USE PTSC
      USE AMVIS
      IMPLICIT NONE
!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
!C--- T: INSTANT T
!C--- Y,DERY: MOUVEMENTS ET VITESSES DU CENTRE DE GRAVITE A L'INSTANT T
      REAL T,Y(*),DERY(*)
      INTEGER NC6,NC61,I,J,K,L,LK,JL,IL
      REAL EWT1,EWT2,FHS,FAM,FEH,FDH
      REAL ALPC,CXV,CYV,CNV,CKV
      REAL DELT,DELTP,DVL
      REAL ROV2,V,FKV,FXV,FYV,FNV
      REAL RLI,FAMAR,FAMOR,FAN1,FAN2,FAN3
      REAL FAMO,FAMA
      REAL XPMN,YPMN,ZPMN,VXMN,VYMN,VZMN,GXMN,GYMN,GZMN
      REAL FMCX,FMCY,FMCZ
!C----------------------------------------------------------------------
      NC6=NC*6
      NC61=NC6+1

!**** FONCTION DE DEMARRAGE
      IF(T.LE.DMAR)THEN
      EWT2=1./COSH(9.90348755*T/DMAR)
      EWT1=1.-EWT2
      ELSE
      EWT2=1./COSH(9.90348755)
      EWT1=1.-EWT2
      ENDIF

!**** CONSTITUTION DU SECOND MEMBRE
      DO K=1,NC
        DO I=1,6
            LK=I+6*(K-1)
!C-- HOULE
            FHS=0.
            FAM=0.
            DO J=1,6
                FHS=FHS+SH(I,J,K)*Y(J+6*(K-1))
                DO L=1,NC
                    JL=J+6*(L-1)
                    FAM=FAM+CA(I,J,L,K)*Y(JL+6*NC)
                END DO
            END DO
            FEH=(F(I,K)*COS(W*T)+F(I+6,K)*SIN(W*T))*AMPL*EWT1
            FDH=FD(I,K)*((AMPL*EWT1)**2)
            AIJ(LK,NC61)=FDH+FEH-FHS-FAM
        END DO
      END DO
!C-- EFFORT DE FROTTEMENT EN DEBATEMENT DU A L'AMORTISSEMENT VISQUEUX
      DO 4 K=1,NC
      LK=2+6*(K-1)
      AIJ(LK,NC61)=AIJ(LK,NC61)-B44PHI*ABS(Y(LK+6*NC))*&
     &Y(LK+6*NC)
4     CONTINUE

!C-- VENT
      DO 71 K=1,NC
      LK=6*(K-1)
      ROV2=.5*RHOA*V(T)**2
      DVL=MOD((DV-Y(6))*180./PI,360.)
      DO 1323 I=2,37
      IF(DVL.GE.ALP(I))GOTO 1323
      ALPC=(DVL-ALP(I-1))/(ALP(I)-ALP(I-1))
      CXV=CX(I-1)+(CX(I)-CX(I-1))*ALPC
      CYV=CY(I-1)+(CY(I)-CY(I-1))*ALPC
      CNV=CN(I-1)+(CN(I)-CN(I-1))*ALPC
      CKV=CK(I-1)+(CK(I)-CK(I-1))*ALPC
      GOTO 2323
 1323 CONTINUE
 2323 CONTINUE
      FXV=ROV2*CXV*SL*EWT1
      FYV=ROV2*CYV*ST*EWT1
      FKV=ROV2*CKV*ST*HR*EWT1
      FNV=ROV2*CNV*ST*ALR*EWT1
      AIJ(1+LK,NC61)=AIJ(1+LK,NC61)+FXV*COS(Y(6))-FYV*SIN(Y(6))
      AIJ(2+LK,NC61)=AIJ(2+LK,NC61)+FXV*SIN(Y(6))+FYV*COS(Y(6))
      AIJ(4+LK,NC61)=AIJ(4+LK,NC61)+FKV
      AIJ(6+LK,NC61)=AIJ(6+LK,NC61)+FNV
 71   CONTINUE

!C-- EFFORTS NAVIRE CHENALANT
      DO 81 K=1,NC
      LK=6*(K-1)
      CALL FMCH(T,FMCX,FMCY,FMCZ)
      AIJ(1+LK,NC61)=AIJ(1+LK,NC61)+FMCX
      AIJ(2+LK,NC61)=AIJ(2+LK,NC61)+FMCY
      AIJ(6+LK,NC61)=AIJ(6+LK,NC61)+FMCZ
!C      WRITE(*,763)T,FMCX,FMCY,FMCZ
 81   CONTINUE
!C 763  FORMAT(4(1X,1PE12.4))

!C-- AMARRAGE
      DO 11 K=1,NC
      LK=6*(K-1)
      DO 9 IL=1,NAN
      CALL PVG(Y,DERY,XPM(IL),YPM(IL),ZPM(IL),XPMN,YPMN,ZPMN,&
     &VXMN,VYMN,VZMN,GXMN,GYMN,GZMN)
!C-     TYPE RESSORT
      IF(IK(IL).EQ.0)THEN
      RLI=SQRT((XPMN-XPF(IL))**2+(YPMN-YPF(IL))**2+(ZPMN-ZPF(IL))**2)
      DELTP=(VXMN*(XPMN-XPF(IL))+VYMN*(YPMN-YPF(IL))+&
     &VZMN*(ZPMN-ZPF(IL)))/RLI
      DELT=RLI-RL(IL)
      FAMAR=FAMA(IL,DELT)+PT(IL)*EWT1
      FAMOR=FAMO(IL,DELTP,EWT2)
      FAN1=(FAMAR+FAMOR)*(XPMN-XPF(IL))/RLI
      FAN2=(FAMAR+FAMOR)*(YPMN-YPF(IL))/RLI
      FAN3=(FAMAR+FAMOR)*(ZPMN-ZPF(IL))/RLI
      ENDIF
!C-     TYPE RESSORT EN TRACTION
      IF(IK(IL).EQ.1)THEN
      RLI=SQRT((XPMN-XPF(IL))**2+(YPMN-YPF(IL))**2+(ZPMN-ZPF(IL))**2)
      DELTP=(VXMN*(XPMN-XPF(IL))+VYMN*(YPMN-YPF(IL))+&
     &VZMN*(ZPMN-ZPF(IL)))/RLI
      DELT=RLI-RL(IL)
      FAMAR=MAX(FAMA(IL,DELT)+PT(IL)*EWT1,0.)
      FAMOR=FAMO(IL,DELTP,EWT2)
      FAN1=(FAMAR+FAMOR)*(XPMN-XPF(IL))/RLI
      FAN2=(FAMAR+FAMOR)*(YPMN-YPF(IL))/RLI
      FAN3=(FAMAR+FAMOR)*(ZPMN-ZPF(IL))/RLI
      ENDIF
!C-     TYPE RESSORT EN COMPRESSION DANS UNE DIRECTION . (DUCS D'ALBE)
      IF(IK(IL).EQ.-1)THEN
      DELT=YPM(IL)-YPMN
      DELTP=VYMN
      FAMOR=FAMO(IL,DELTP,EWT2)
      FAN1=0.
      FAN2=(MIN( FAMA(IL,DELT)+PT(IL)*EWT1 ,0.)+FAMOR)*&
     &SIGN(1.,(YPM(IL)-YPF(IL)))
      FAN3=0.
      ENDIF
!C-----Ecriture de controle des calculs
!C      WRITE(*,764)T,FAN1,FAN2,FAN3
!C 764  FORMAT(4(1X,1PE12.4))
!C-
      AIJ(1+LK,NC61)=AIJ(1+LK,NC61)-FAN1
      AIJ(2+LK,NC61)=AIJ(2+LK,NC61)-FAN2
      AIJ(3+LK,NC61)=AIJ(3+LK,NC61)-FAN3
      AIJ(4+LK,NC61)=AIJ(4+LK,NC61)-((YPMN-YEFF)*FAN3-(ZPMN-ZEFF)*FAN2)
      AIJ(5+LK,NC61)=AIJ(5+LK,NC61)-((ZPMN-ZEFF)*FAN1-(XPMN-XEFF)*FAN3)
      AIJ(6+LK,NC61)=AIJ(6+LK,NC61)-((XPMN-XEFF)*FAN2-(YPMN-YEFF)*FAN1)
 9    CONTINUE
 11   CONTINUE

!**** DERIVEE DE Y
      DO 14 I=1,NC6
      DERY(I)=Y(I+NC6)
      DERY(I+NC6)=0.
      DO 13 J=1,NC6
      DERY(I+NC6)=DERY(I+NC6)+AIJ(I,J)*AIJ(J,NC61)
 13   CONTINUE
 14   CONTINUE
      RETURN
      END
