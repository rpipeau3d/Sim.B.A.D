!C***********************************************************************
      SUBROUTINE POS(X,X1,Y1,Z1,X2,Y2,Z2)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: SOUS-PROGRAMME POS                               *
!*                                                                      *
!*      CALCUL DE LA POSITION COURANTE D'UN POINT DU CORPS              *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE PARA
      IMPLICIT NONE
!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
!C--- X: MOUVEMENTS DU CENTRE DE GRAVITE A L'INSTANT T
!C--- X1,Y1,Z1: POSITION INITIALE A L'INSTANT T0 DANS LE REPERE FIXE
!C--- X2,Y2,Z2: POSITION A L'INSTANT T DANS LE REPERE FIXE
      REAL::X(*)
      REAL::X1,Y1,Z1,X2,Y2,Z2
      REAL::TH,ST,CT
      REAL::XP1,YP1,ZP1,XP2,YP2,ZP2
!C----------------------------------------------------------------------
      TH=SQRT(X(4)**2+X(5)**2+X(6)**2)
      IF(TH.LE.1.E-5)THEN
        ST=1.
        CT=.5
      ELSE
        ST=SIN(TH)/TH
        CT=(1.-COS(TH))/(TH*TH)
      ENDIF
      CALL PV(X(4),X(5),X(6),X1-XEFF,Y1-YEFF,Z1-ZEFF,XP1,YP1,ZP1)
      CALL PV(X(4),X(5),X(6),XP1,YP1,ZP1,XP2,YP2,ZP2)
      X2=X1+X(1)+ST*XP1+CT*XP2
      Y2=Y1+X(2)+ST*YP1+CT*YP2
      Z2=Z1+X(3)+ST*ZP1+CT*ZP2
      RETURN
      END
