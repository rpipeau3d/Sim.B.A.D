!C***********************************************************************
      FUNCTION FAMO(I,D,EWT2)
!************************************************************************
!*                                                                      *
!*   PROGRAMME SIMBAD: FONCTION FAMO                                    *
!*                                                                      *
!*      CALCUL DE L'AMORTISSEMENT DANS CHAQUE AMARRE                    *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*   AMORTISSEMENT DE FORME POLYNOMIALE                                 *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
      USE CONSTANTS
      USE AMAR
      IMPLICIT NONE
!C--- PARAMETRES FORMELS DE LA FONCTION
!C--- I: INDICE DE LIGNE OU DEFENSE
!C--- D: VARIATION DANS LE TEMPS DE L'EXTENSION DE LIGNE OU COMPRESSION DE DEFENSE
!C--- EWT2: RAMPE DE MISE EN ROUTE
      INTEGER::I,J
      REAL::D,FAMO,EWT2
!C----------------------------------------------------------------------
      FAMO=AMO(I,NAMO(I))
      DO 1 J=NAMO(I),2,-1
       FAMO=FAMO*D+AMO(I,J-1)
 1    CONTINUE
      FAMO=(FAMO+PA(I)*EWT2)*D
      RETURN
      END
