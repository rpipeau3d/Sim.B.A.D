      Subroutine PID_main(xin0,xin,t0,t1,CVAR,reset0,reset)

!************************************************************************
!*                                                                      *
!* PROGRAMME SIMBAD: PROGRAMME PID DE CONTROLE D'UNE LIAISON RIGIDE     *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************

      implicit none
!C--- PARAMETRES DU SOUS-PROGRAMME
!C--- XIN0,XIN: DEPLACEMENTS DE LA LIAISON AUX INSTANTS T ET T+DT
!C--- T0,T1: INSTANTS DU CALCUL A T ET T+DT
!C--- RESET0,RESET: ACTIONS INTEGRALE A T ET T+DT
!C--- CVAR: VARIABLE DE CONTROLE DE L'EFFORT (ENTRE O ET 1)
      real::xin0,xin,xout,xoutmax,setpoint
      real::gain,Ti,Td,reset0,reset
      real::deltat,t0,t1,CVAR
      real::error1

!C-- INITIALISATION DES VARIABLES DE CALCUL
      xoutmax = 10.
      setpoint = 0.0E+00
!C-- GAIN: GAIN D'ACTION PROPORTIONNELLE
!C-- TD: PARAMETTRE D'ACTION DERIVEE
!C-- 1/TI: PARAMETRE D'ACTION INTEGRALE
      gain = 0.45
      Td = 0.45
      Ti = 2.0
      xout = 0.

!C--  ESTIMATION DU COEFFICIENT D'EFFORT (XOUT = CVAR) AVEC ALGORITHME CONTROL_PID

        deltat = t1-t0

        call control_pid (deltat,xin0,xin,xout,xoutmax,setpoint,&
     &  gain,Ti,Td,reset0,reset,error1)

        CVAR = xout
        if (CVAR <= 0.) then
          CVAR = 0.
        else
          if (CVAR > 1.0) then
           CVAR = 1.0
           WRITE(*,*)'MAXIMUM EFFORT DELIVERED BY RIGID CONNECTION',&
     &     '...'
          end if
        end if

      return
      end
!c*********************************************************************
      subroutine control_pid (deltat,xin0,xin,xout,xoutmax,&
     &setpoint,gain,Ti,Td,reset0,reset,error1)
!************************************************************************
!*                                                                      *
!* PROGRAMME SIMBAD: ALGORITHME DE CONTROLE DU PID                      *
!*                                                                      *
!* ERROR: ECART MESURE-CONSIGNE
!* EDOT:  VITESSE DE VARIATION DE L'ECART
!* RESET: INTEGRALE DE VARIATION DE L'ECART
!***********************************************************************

      implicit none
!C--- PARAMETRES DU SOUS-PROGRAMME
!C--- DELTAT: PAS DE TEMPS DE CALCUL
!C--- XIN0,XIN: DEPLACEMENTS DE LA CONNECTION (DELT) A T ET T+DT
!C--- XOUT: VARIABLE DE CONTROLE DE L'EFFORT
!C--- XOUTMAX: DEPLACEMENT MAX POUR L'ACTION INTEGRALE
!C--- SETPOINT: CONSIGNE
!C--- GAIN: GAIN D'ACTION PROPORTIONNELLE
!C--- TD: PARAMETTRE D'ACTION DERIVEE
!C--- 1/TI: PARAMETRE D'ACTION INTEGRALE
!C--- RESET0,RESET: ACTIONS INTEGRALE A T ET T+DT
!C--- ERROR1: ECART MESURE-CONSIGNE
!
!********************************************************************
      real::xin0,xin,xout,xoutmax,setpoint
      real::gain,Ti,Td,reset0,reset
      real::deltat

      real::TTi,error,action,edot
      real::error1
!********************************************************************

!C-- SI Ti<0, ACTION INTEGRALE NULLE
      TTi=Ti
      if (Ti<=0d0) TTi=1.0E+20
!C-- CONTROLEUR DE SENS INVERSE
      action = -1.0E+00
!C-- DETERMINATION ECART MESURE-CONSIGNE
      error=(setpoint-xin)*action
!C-- LIMITATION DE L'ACTION INTEGRALE (TOUJOURS FAIBLE, CAR RESET0 TOUJOURS EGAL A 0)
      if ((abs(xin)<xoutmax).and.(abs(xin)>0d0))&
     &reset=reset0+deltat*(xin+xin0)/TTi
!C-- DETERMINATION ACTION DERIVEE
      edot=0.0E+00 ! VALEUR PAR DEFAUT
      edot = (error-error1)/deltat
!C-- CALCUL DE LA VARIABLE DE CONTROLE
      xout = gain*error + reset + Td*edot   ! PID PARALLELE
!C-- SAUVEGARDE DE L'ECART
      error1 = error
      return
      end
!**********************************************************************
