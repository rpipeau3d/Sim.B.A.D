      SUBROUTINE VERIF(NOM)
!************************************************************************
!*                                                                      *
!*     PROGRAMME SIMBAD: SOUS-PROGRAMME VERIF                           *
!*                                                                      *
!*     VERIFICATION DU NOM DES FICHIERS                                 *
!*                                                                      *
!************************************************************************
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************

      IMPLICIT NONE
!C--- PARAMETRES FORMELS DU SOUS-PROGRAMME
      CHARACTER(12)::NOM
      INTEGER::IOUI,IC1
      LOGICAL::FEX
!C----------------------------------------------------------------------
      INQUIRE(FILE=NOM,EXIST=FEX)
      IF(.NOT.FEX)THEN
        WRITE(*,*)'FILE ',NOM,' NOT EXISTING'
10      WRITE(*,*)'ENTER A NEW NAME ? (YES:1 - NO:0)'
          READ(*,*,ERR=10)IOUI
          IF(IOUI.EQ.1)THEN
            WRITE(*,*)'FILE NAME? (12 CHAR. MAX. WITH EXTENSION)'
            READ(*,901)NOM
          ELSE
            WRITE(*,*)'PROGRAM STOPPED - OK? WRITE 0'
            READ(*,*)IC1
            STOP
          ENDIF
      ENDIF
!C**********************************************************************
901   FORMAT(A12)
      RETURN
      END

!CCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCCC
