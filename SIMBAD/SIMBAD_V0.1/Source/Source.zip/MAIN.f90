!************************************************************************
!*                                                                      *
!*                          PROGRAMME SIMBAD                            *
!*                 (SIMulation de Bateaux Amarres sur Defenses)         *
!*                                                                      *
!*  This file is part of SIMBAD program.                                *
!*                                                                      *
!*  SIMBAD program is free software: you can redistribute it and/or     *
!*  modify it under the terms of the GNU General Public License         *
!*  as published by the Free Software Foundation, version 3 of          *
!*  the License.                                                        *
!*                                                                      *
!*  SIMBAD program is distributed in the hope that it will be useful,   *
!*  but WITHOUT ANY WARRANTY; without even the implied warranty of      *
!*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the        *
!*  GNU General Public License for more details.                        *
!*                                                                      *
!*  You should have received a copy of the GNU General Public License   *
!*  along with SIMBAD program.                                          *
!*  If not, see <https://www.gnu.org/licenses/>.                        *
!*                                                                      *
!************************************************************************
!************************************************************************
!*
!*                          PROGRAMME SIMBAD
!*                 (SIMulation de Bateaux Amarres sur Defenses)
!*
!* Notice:
!* Software and information, including technical and engineering data,
!* figures, tables, designs, drawings, details, procedures and specification,
!* presented herein or elsewhere are for general information only.
!* While every effort has been made to insure its accuracy, software and information
!* should not be used or relied upon for any specific application without
!* independent competent professional examination and verification of
!* its accuracy, suitability and applicability, by a qualified professional
!* engineer (e.g. qualified engineer in the field of hydraulics or hydrodynamics).
!*
!* This product (software and information) is provided �as it is�,
!* without warranty of any kind. Anyone making use of this material
!* (software and information) does so at his own risk
!* and assumes any and all liability resulting from such use.
!* The entire risk as to quality or usability of the material (software and information)
!* contained within is with the user. In no event, will the author(s) be held liable
!* for any direct or indirect damages including lost profits, lost savings,
!* loss of business information or other incidental or consequential damages
!* arising from the use of or inability to use the software and information
!* contained within.
!*
!* Notice:
!* Les logiciels et informations, y compris toutes les donn�es techniques et d'ing�nierie,
!* figures, tableaux, mod�les de conception, dessins, pr�sentations d�taill�es,
!* notices et sp�cifications, pr�sent�s ici ou ailleurs ne le sont qu'� titre d'information g�n�rale.
!* Bien que tous les efforts aient �t� faits pour assurer leur exactitude, les logiciels et informations
!* ne doivent pas �tre utilis�s ou invoqu�s pour une application sp�cifique sans un examen
!* et une v�rification de leur exactitude, de leur pertinence et de leur applicabilit�, par un
!* personnel qualifi� et comp�tent (par exemple, un ing�nieur qualifi� dans le domaine de l'hydraulique
!* ou de l'hydrodynamique).
!*
!* Ce produit (logiciels et informations) est fourni �tel quel�, sans garantie d'aucune sorte.
!* Quiconque utilise ce produit le fait � ses propres risques et assume toute responsabilit�
!* r�sultant d'une telle utilisation. Tous les risques relatifs � la qualit� ou � la pertinence d'utilisation
!* du produit (logiciels et informations) sont � la charge de l'utilisateur. En aucun cas, le ou les auteurs
!* ne pourront �tre tenus responsables de tout dommage direct ou indirect, y compris la perte de profits,
!* la perte d'�conomies, la perte d'informations commerciales ou autres dommages incidents ou cons�cutifs
!* r�sultant de l'utilisation ou de l'incapacit� d'utilisation des logiciels et informations donn�s ici ou ailleurs.
!*
!************************************************************************
      PROGRAM SIMBAD
!PARAMETRES COMMUNS
      USE CONSTANTS
      USE PARA
      USE COEF
      USE RESU
      USE REFT
      USE AMAR
      USE VENT
      USE COURANT
      USE CHENAL
      USE MATR
      USE PTSC
      USE HIRR
      USE IRTN
      USE AMVIS
      USE AUTMO
      USE SHTEN
      IMPLICIT NONE

!C--- PARAMETRES FORMELS DU PROGRAMME
      REAL,DIMENSION(12*NCOR):: Y,DERY
      REAL::T,ANGAMO,BETA,DCUR0,DV0,DELT
      REAL::EFDALB,EWT1,G,reset,TDEB,TFIN
      REAL::RLI,XPMN,YPMN,ZPMN
      REAL::FAMA,V
      REAL,DIMENSION(NLIG)::T0,DELT0,reset0
      CHARACTER(60)::TITRE
      CHARACTER(len=12):: THOULE,TVENT,TAMARR,TPOINT,TRESUL
      CHARACTER(len=12):: TCHENAL,TCOURANT,TVITV
      COMPLEX,DIMENSION(NMAX):: ZZ
      INTEGER::I,J,K,L,II,IJ,IL,IM,IP,JL,LK
      INTEGER::IC1,ICH,INU,IPT,ITD,ITF
      INTEGER::NC6,NC12,NCOR6,NDIM,NFFT,NFT,NIT0
      INTEGER::IOUI,ITAB,ITTD,ITTF,IRREG,IndRdtn,ICHFFT,ICHOIX

      EXTERNAL FCT,FCTIR
!C----------------------------------------------------------------------
!**** HOULE REGULIERE OU IRREGULIERE
!**** OPTION HOULE REGULIERE SUPPRIMEE
!**** HOULE REGULIERE TRAITEE COMME UNE HOULE IRREGULIERE
!3000  CONTINUE
!      WRITE(*,*)'HOULE REGULIERE (TAPER 0) OU IRREGULIERE (TAPER 1):'
!      READ(*,*,ERR=3000)IRREG

      IRREG = 1

!C**********************************************************************
!C     OUVERTURE DES FICHIERS DE DONNEES
!C**********************************************************************
!C--- NOMS FICHIERS
      THOULE = 'Houl_irr.txt'
      TVENT = 'VENT.DAT'
      TVITV = 'wind_vel.txt'
      TCOURANT = 'COURANT.DAT'
      TAMARR = 'AMAR.DAT'
      TPOINT = 'POINT.DAT'
      TCHENAL = 'CHENAL.DAT'
      TRESUL = 'RESUL.RES'
!C----------------------------------------------------------------------
 3458 CONTINUE

 765  WRITE(*,902)THOULE,TVENT,TVITV,TCOURANT,&
     &            TAMARR,TPOINT,TCHENAL
      WRITE(*,*)'MODIFICATION OF FILE? (YES:1 - NO:0)'
      READ(*,*,ERR=765)IOUI
      IF(IOUI.EQ.1)THEN
 1201 WRITE(*,*)'NUMBER OF FILE USED (1 to 7)?'
      READ(*,*,ERR=1201)INU
      IF(INU.GT.7)GOTO 1201
      GOTO(1,2,3,4,5,6,7)INU
 1    WRITE(*,*)'WAVE FILE ? (12 CHAR. MAX. WITH EXTENSION)'
      READ(*,901)THOULE
      GOTO 765
 2    WRITE(*,*)'WIND COEFFICIENT FILE ? (12 CHAR. MAX. WITH EXTENSION)'
      READ(*,901)TVENT
      GOTO 765
 3    WRITE(*,*)'WIND VELOCITY FILE ? (12 CHAR. MAX. WITH EXTENSION)'
      READ(*,901)TVITV
      GOTO 765
 4    WRITE(*,*)'CURRENT FILE ? (12 CHAR. MAX. WITH EXTENSION)'
      READ(*,901)TCOURANT
      GOTO 765
 5    WRITE(*,*)'MOORING SYSTEM FILE ? (12 CHAR. MAX. WITH EXTENSION)'
      READ(*,901)TAMARR
      GOTO 765
 6    WRITE(*,*)'SPECIFIC POINT FILE ? (12 CHAR. MAX. WITH EXTENSION)'
      READ(*,901)TPOINT
      GOTO 765
 7    WRITE(*,*)'PASSING SHIP FILE ? (12 CHAR. MAX. WITH EXTENSION)'
      READ(*,901)TCHENAL
      GOTO 765
!* 8    WRITE(*,*)'RESULT FILE ? (12 CHAR. MAX. WITH EXTENSION)'
!*      READ(*,901)TRESUL
!*      GOTO 765
      ENDIF
!C--- VERIFICATION DU NOM DES FICHIERS
      CALL VERIF(THOULE)
      CALL VERIF(TVENT)
      CALL VERIF(TVITV)
      CALL VERIF(TCOURANT)
      CALL VERIF(TAMARR)
      CALL VERIF(TPOINT)
      CALL VERIF(TCHENAL)
!*      CALL VERIF(TRESUL)
!C--- OUVERTURE DES FICHIERS
      OPEN(UNIT=10,FILE=THOULE,STATUS='UNKNOWN')
      OPEN(UNIT=11,FILE=TVENT ,STATUS='UNKNOWN')
      OPEN(UNIT=16,FILE=TVITV ,STATUS='UNKNOWN')
      OPEN(UNIT=12,FILE=TAMARR,STATUS='UNKNOWN')
      OPEN(UNIT=13,FILE=TPOINT,STATUS='UNKNOWN')
      OPEN(UNIT=14,FILE=TCHENAL,STATUS='UNKNOWN')
      OPEN(UNIT=15,FILE=TCOURANT,STATUS='UNKNOWN')
      OPEN(UNIT=20,FILE=TRESUL,STATUS='UNKNOWN')

!**** LECTURE DES DONNEES CONCERNANT LE NAVIRE ET LA HOULE
!C-- LONGUEUR,NOMBRE DE CORPS,POINT ORIGINE,PERIODE,DIRECTION,AMPLITUDE.
!C-- AL: LONGUEUR ENTRE PERPENDICULAIRES (m)
!C-- NC: NOMBRE DE CORPS FLOTTANT (METTRE NC=1)
!C-- XEFF, YEFF, ZEFF: COORDONNEES PAR RAPPORT AU REPERE FIXE R1,
!C-- DU CENTRE DU REPERE MOBILE R2 (AU CENTRE DE GRAVITE G)
!C-- PER: PERIODE DE LA HOULE (en s)
!C-- BETA: DIRECTION DE LA HOULE DANS REPERE R2 (0� : HOULE VENANT DE
!C-- L'ARRIERE; 180� : HOULE VENANT DE L'AVANT)
!C-- AMPL: HAUTEUR HS (HOULE IRREGULIERE)
!C-- OU AMPLITUDE (1/2 HAUTEUR; HOULE REGULIERE) (m)
!C**********************************************************************
      READ(10,*)AL,NC,XEFF,YEFF,ZEFF
      READ(10,*)PER,BETA,AMPL
      NC=1
!C-- AMORTISSEMENT VISQUEUX DE CAVALEMENT:
!C     TIREAU, TIRANT D'EAU DU NAVIRE (m)
!C     B44OM,B44PHI, COEFFICIENTS D'AMORTISSEMENT DE ROULIS (kg.m2/s)
!C     FROT, COEFFICIENT DE FROTTEMENT (ADIMENSIONNEL) DES DEFENSES
!C-----------------------------------------------------------------------
      READ(10,*)TIREAU,B44OM,B44PHI,FROT
!C**********************************************************************
!C-- INERTIES,HYDROSTATIQUES,MASSES AJOUTEES,AMORTISSEMENT,EFFORTS
!C-- D'EXCITATION.
!C-- MATRICE DES INERTIES (MATRICE 6 x 6) : AIN(i,j) en kg et kg.m2
!C-- MATRICE DES EFFORTS DE RAPPEL HYDROSTATIQUES (MATRICE 6 x 6) :
!C-- SH(i,j) en N/m et N.m
!C-- MATRICE DES MASSES AJOUTEES (MATRICE 6 x 6) : CM(i,j)en kg et kg.m2
!C-- PRESENTATION DES MATRICES 6x6:
!C-- AVEC NUMEROS DES SIX MOUVEMENTS TELS QUE:
!C-- 1.	CAVALEMENT (TRANSLATION SUIVANT 02-x2),
!C-- 2.	DEBATTEMENT (TRANSLATION SUIVANT 02-y2),
!C-- 3.	PILONNEMENT (TRANSLATION SUIVANT 02-z2),
!C-- 4.	ROULIS (ROTATION AUTOUR DE 02-x2),
!C-- 5.	TANGAGE (ROTATION AUTOUR DE 02-y2),
!C-- 6.	LACET (ROTATION AUTOUR DE 02-z2),
!C-- LES MATRICES 6 x 6 SE PRESENTENT DE LA FACON SUIVANTE:
!C-- X11	X12...X16
!C-- X21 X22...X26
!C-- ... ... .....
!C-- X61 X62	 X66
!C-- AVEC Xij, VALEUR DONT L'INDICE i DESIGNE LE MOUVEMENT PRINCIPAL
!C-- ET L'INDICE j LE MOUVEMENT DE COUPLAGE
!C----------------------------------------------------------------------
!C-- VALEURS SUIVANTES NON UTILISEES POUR HOULE IRREGULIERE:
!C-- Matrice des amortissements de diffraction-radiation:
!C-- (matrice 6 x 6): CA(i,j)en kg/s et kg.m2/s
!C-- Efforts d'excitation pour une houle d'amplitude unite F(i).
!C-- La premi�re carte donne l'amplitude du cosinus en N
!C-- pour les forces et en N.m pour les moments.
!C-- La deuxi�me carte donne l'amplitude du sinus en N
!C-- pour les forces et en N.m pour les moments.
!C-- Chaque carte donne les amplitudes (en cosinus ou sinus)
!C-- pour les mouvements en ordre croissant de 1 a 6.
!C-- Efforts de derive induits par la houle FD (i).
!C-- Les efforts (en N et N.m) correspondent aux mouvements de 1 a 6.
!C**********************************************************************
      READ(10,*)((AIN(I,J,1),I=1,6),J=1,6)
      READ(10,*)((SH(I,J,1),I=1,6),J=1,6)
      READ(10,*)((CM(I,J,1,1),I=1,6),J=1,6)

      IF(IRREG.EQ.0)THEN
        READ(10,*)((CA(I,J,1,1),I=1,6),J=1,6)
        READ(10,*)(F(I,1),I=1,12)
        READ(10,*)(FD(I,1),I=1,6)
      ENDIF
      REWIND 10

!C**********************************************************************
!C-- POUR LA HOULE IRREGULIERE, LECTURE DES FICHIERS D'EFFORTS DE HOULE
!C-- ET DES TERMES DE REPONSE EN IMPULSION POUR LA RADIATION (IRF)
!C**********************************************************************
      IF(IRREG.EQ.1)THEN
        CALL LECIRREG()
      ENDIF

!**** CALCUL DE CERTAINS PARAMETRES

      PI=4*ATAN(1.)
      RADEG=180/PI
      W=2*PI/PER
      NDIM=12*NC
      RHOE=1023.
      RHOA=1.293
      G=9.81

!**** LECTURE SERIE TEMPORELLE VENT*************************************
!C-- DV0: DIRECTION DU VENT EN DEGRES (�)
!C-- (MEME CONVENTION QUE POUR HOULE)
!C-- DV: DIRECTION EN RADIANS
!C**********************************************************************
      READ(16,*)DV0
      DV=DV0/RADEG
      NV=0
 77   CONTINUE
      NV=NV+1
!****  CONTROLE DU NOMBRE DE PAS DE TEMPS
      IF(NV.GT.NMPV)THEN
        WRITE(*,*)'NUMBER OF WIND FILE TIME STEPS: NMPV>28800',&
     &  '; STOP OF RUN'
        WRITE(*,*)'OK? WRITE 0'
        READ(*,*)IC1
        STOP
      ENDIF
!***********************************************************************
!C-- TV(NV): TEMPS (s)
!C-- VV(NV): VITESSE CORRESPONDANTE (m/s)
!C-- DEFINITION DE LA VITESSE DU VENT EN FONCTION DU TEMPS (SIGNAL V(t))
!C-- EN PARTANT DE TV = 0
!C-- DEFINIR LE SIGNAL TEMPOREL POINT PAR POINT:
!C-- TEMPS TV(s) - VITESSE VV(m/s)
!C-- TERMINER LE SIGNAL PAR UNE VALEUR TV<0
!C-- LE NOMBRE DE POINTS DU SIGNAL EST LIMITE A NMPV = 1000
!C-- LE SIGNAL SE REPETE IDENTIQUE A LUI-MEME, APRES LE TEMPS TVmax,
!C-- LORSQUE LA SIMULATION DEPASSE CE TEMPS MAXIMAL.
!C-- PAS DE DISCONTINUITE LORS DE LA SIMULATION
!C-- NOTA : DESCRIPTION DU SIGNAL V(t) A AU MINIMUM TROIS CARTES:
!C-- DEUX POINTS DE LA COURBE ET UNE CARTE D'INDICE DE FIN (TV<0)
!C**********************************************************************
      READ(16,*)TV(NV),VV(NV)
      IF(TV(NV).GE.0.)GOTO 77
      NV=NV-1
      TMAX=TV(NV)
!***********************************************************************
!C-- ST: SURFACE LATERALE DE PRISE AU VENT (m2)
!C-- SL: SURFACE LONGITUDINALE DE PRISE AU VENT (m2)
!C-- ALR: LONGUEUR ENTRE PERPENDICULAIRES (m)
!C-- HR: HAUTEUR DU CENTRE DE GRAVITE SURFACE VELIQUE
!C-- AU-DESSUS DU PLAN O2-x2-y2 (CENTRE DE GRAVITE) (m)
!C**********************************************************************
      READ(11,*)ST,SL,ALR,HR

!C**********************************************************************
!C-- ALP: VALEUR DE L'ANGLE DE DIRECTION DU VENT
!C-- (TOUS LES 10� DE 0� a 180�; 19 VALEURS)
!C-- CX, CY, CN, CK: VALEURS DES COEFFICIENTS D'EFFORTS (CAVALEMENT, DEBATTEMENT)
!C-- ET MOMENTS (LACET, ROULIS) POUR LES VALEURS DE L'ANGLE CORRESPONDANT
!C**********************************************************************
      DO 2944 I=1,19
        READ(11,*)ALP(I),CX(I),CY(I),CN(I),CK(I)
        ALP(37-I+1)=360.-ALP(I)
        CX(37-I+1)=CX(I)
        CY(37-I+1)=-CY(I)
        CN(37-I+1)=-CN(I)
        CK(37-I+1)=-CK(I)
 2944 CONTINUE

      REWIND 11

!**** LECTURE SERIE TEMPORELLE COURANT*************************************
!C-- DCUR0: DIRECTION DU COURANT EN DEGRES (�)
!C-- (MEME CONVENTION QUE POUR HOULE)
!C-- DCUR: DIRECTION EN RADIANS
!C**********************************************************************
      READ(15,*)DCUR0
      DCUR=DCUR0/RADEG
      NCUR=0
 75   CONTINUE
      NCUR=NCUR+1
!****  CONTROLE DU NOMBRE DE PAS DE TEMPS
      IF(NCUR.GT.NMPV)THEN
        WRITE(*,*)'NUMBER OF CURRENT FILE TIME STEPS: NMPV>1000',&
     &  '; STOP OF RUN'
        WRITE(*,*)'OK? WRITE 0'
        READ(*,*)IC1
        STOP
      ENDIF
!***********************************************************************
!C-- TCUR(NCUR): TEMPS (s)
!C-- VCUR(NCUR): VITESSE CORRESPONDANTE (m/s)
!C-- MEMES CONVENTIONS QUE POUR LE VENT POUR LA SERIE TEMPORELLE
!C**********************************************************************
      READ(15,*)TCUR(NCUR),VCUR(NCUR)
      IF(TCUR(NCUR).GE.0.)GOTO 75
      NCUR=NCUR-1
      TCURMAX=TCUR(NCUR)

!C**********************************************************************
!C-- ANCU: VALEUR DE L'ANGLE DE DIRECTION DU COURANT
!C-- (TOUS LES 10� DE 0� a 180�; 19 VALEURS)
!C-- CUX, CUY, CUN: VALEURS DES COEFFICIENTS D'EFFORTS (CAVALEMENT, DEBATTEMENT)
!C-- ET MOMENT (LACET) POUR LES VALEURS DE L'ANGLE CORRESPONDANT
!C**********************************************************************
      DO 2950 I=1,19
        READ(15,*)ANCU(I),CUX(I),CUY(I),CUN(I)
        ANCU(37-I+1)=360.-ANCU(I)
        CUX(37-I+1)= CUX(I)
        CUY(37-I+1)= -CUY(I)
        CUN(37-I+1)= -CUN(I)
 2950 CONTINUE

      REWIND 15

!**** LECTURE DES CARACTERISTIQUES D'AMARRAGE***************************
!C-- NAN: NOMBRE TOTAL LIGNES AMARRES ET DUCS D'ALBE
!C-- (NAN <= 22; PEUT ETRE MODIFIE DANS LE PROGRAMME)
!C-- CARTES SUIVANTES A REPETER NAN FOIS
!C----------------------------------------------------------------------
!C-- IK, NRAI, RAI (i = 1, NRAI)
!C-- IK, TYPE DE LIAISON:
!C-- 1, LIGNE D'AMARRAGE CLASSIQUE (NON IMMERGEE)
!C-- 2, LIAISON SPECIALE RIGIDE
!C-- 3, LIAISON SPECIALE AVEC AMORTISSEUR (TYPE SHORETENSION)
!C-- -1, DUC D'ALBE
!C-----------------------------------------------------------------------
!C-- NRAI, DEGRE DU POLYNOME DE RAIDEUR (TYPES 1 ET -1) OU NBRE LIAISONS (TYPE 2):
!C-- DEGRE LIMITE A 4 POUR LIGNE D'AMARRAGE (TYPE 1) ET DUC D'ALBE (TYPE -1)
!C-- OU NOMBRE DE LIAISONS DE 20t CHACUNE pour IK=2 (LIMITE A 5)
!C-----------------------------------------------------------------------
!C-- RAI(i), COEFFICIENTS DE RAIDEUR DU POLYNOME EN N/m, N/m2, N/m3... (TYPES 1 ET -1)
!C-- OU VALEURS NULLES POUR CHAQUE LIAISON RIGIDE (IK=2)
!C-----------------------------------------------------------------------
!C-- NAMO, AMO (i = 1, NAMO).
!C-- POLYNOME D'AMORTISSEMENT
!C-- NAMO: DEGRE DU POLYNOME D'AMORTISSEMENT
!C-- AMO(i): VALEURS DES COEFFICIENTS DU POLYNOME
!C-- POUR IK=3, NAMO=1 ET AMO(1)=0.0
!C-----------------------------------------------------------------------
!C-- XPF, YPF, ZPF:
!C-- COORDONNEES DU POINT D'AMARRAGE A TERRE
!C-- DANS REPERE FIXE R1 (m).
!C-----------------------------------------------------------------------
!C-- XPM, YPM, ZPM:
!C-- COORDONNEES DU POINT D'AMARRAGE A BORD DU NAVIRE
!C-- DANS REPERE FIXE R1 (m)
!C-- POUR UN DUC D'ALBE (TYPE -1): XPM = XPF et ZPM = ZPF,
!C-- ET YPM DIFFERENT DE YPF
!C-- POUR UNE LIAISON RIGIDE (TYPE 2): XPM = XPF et ZPM = ZPF,
!C-- MAIS YPF DIFFERENT DE YPM; ATTENTION! YPF ET YPM DOIVENT ETRE PLACES
!C-- DEVANT LES DUCS D'ALBE!!
!C-----------------------------------------------------------------------
!C-- PT, PA
!C-- PT: PRETENSION INITIALE (N)
!C-- PA:	AMORTISSEMENT INITIAL (N.s/m)
!C**********************************************************************

!C-- MISE A ZERO DES VALEURS
      DO I=1,NLIG
        IK(I) = 0
        NRAI(I) = 0
        NAMO(I) = 0
        DO J=1,NDEG
            RAI(I,J) = 0.
            AMO(I,J) = 0.
        ENDDO
        XPF(I) = 0.
        YPF(I) = 0.
        ZPF(I) = 0.
        XPM(I) = 0.
        YPM(I) = 0.
        ZPM(I) = 0.
      ENDDO
!C--- LECTURE DES DONNEES D'AMARRAGE
      READ(12,*)NAN
!****  CONTROLE DU NOMBRE DE LIGNES ET DEFENSES
      IF(NAN.GT.22)THEN
        WRITE(*,*)'NUMBER OF MOORING LINES AND FENDERS: NAN>22',&
     &  '; STOP OF RUN'
        WRITE(*,*)'OK? WRITE 0'
        READ(*,*)IC1
        STOP
      ENDIF
!****
      DO 70 I=1,NAN
        READ(12,*)IK(I),NRAI(I),(RAI(I,K),K=1,NRAI(I))
        READ(12,*)NAMO(I),(AMO(I,K),K=1,NAMO(I))
        READ(12,*)XPF(I),YPF(I),ZPF(I)
        READ(12,*)XPM(I),YPM(I),ZPM(I)
        READ(12,*)PT(I),PA(I)
        RL(I)=SQRT((XPF(I)-XPM(I))**2+(YPF(I)-YPM(I))**2&
     &  +(ZPF(I)-ZPM(I))**2)
        WRITE(*,*)'INITIAL LENGTH:'
        WRITE(*,*)I,RL(I)
!****  CONTROLE DU DEGRE DES POLYNOMES DE RAIDEUR ET AMORTISSEMENT
        IF(IK(I).EQ.1.OR.IK(I).EQ.-1)THEN
            IF(NRAI(I).GT.5)THEN
                WRITE(*,*)'STIFFNESS POLYNOMIAL DEGREE: NRAI>5',&
     &          '; STOP OF RUN'
                WRITE(*,*)'OK? WRITE 0'
                READ(*,*)IC1
                STOP
            ENDIF
        ENDIF
        IF(IK(I).EQ.2)THEN
            IF(NRAI(I).GT.5)THEN
                WRITE(*,*)'NUMBER OF RIGID CONNECTIONS: NRAI>5',&
     &          '; STOP OF RUN'
                WRITE(*,*)'OK? WRITE 0'
                READ(*,*)IC1
                STOP
            ENDIF
        ENDIF

!C-- VALEURS DES LONGUEURS RECALCULEES AVEC PRETENSIONS
!*        IF(IK(I).EQ.1.AND.PT(I).NE.0.) THEN
!*            RL(I) = RL(I)-(PT(I)/RAI(I,1))
!*C-- ECRITURE LONGUEURS MODIFIEES
!*            WRITE(*,*)'LONGUEUR MODIFIEE AVEC PRETENSION:'
!*            WRITE(*,*)I,RL(I)
!*        ENDIF

!C-- INITIALISATION VALEURS POUR CALCUL LIAISONS RIGIDES
        EFFAUTMO(I) = 0.
        T0(I) = 0.
        DELT0(I) = 0.
        reset0(I) = 0.
 70   CONTINUE
      REWIND 12

!**** LECTURE DES POINTS PARTICULIERS DE CALCUL*************************
!C-- NPTS: NOMBRE DE POINTS PARTICULIERS
!C-- (NPTS<=3; PEUT ETRE CHANGE DANS PROGRAMME)
!C----------------------------------------------------------------------
!C-- XPTS, YPTS, ZPTS.
!C-- COORDONNEES DANS REPERE FIXE R1 (m)
!C-- A REPETER NPTS FOIS
!C**********************************************************************

      READ(13,*)NPTS
      DO 71 I=1,NPTS
        READ(13,*)XPTS(I),YPTS(I),ZPTS(I)
 71   CONTINUE
      REWIND 13

!**** LECTURE DU SIGNAL TEMPOREL DES EFFORTS DU NAVIRE CHENALANT
      NCH=0
 76   CONTINUE
      NCH=NCH+1
!****  CONTROLE DU NOMBRE DE PAS DE TEMPS
      IF(NCH.GT.NMPCH)THEN
        WRITE(*,*)'NUMBER OF PASSING SHIP FILE: NMPCH >1000',&
     &  '; STOP OF RUN'
        WRITE(*,*)'OK? WRITE 0'
        READ(*,*)IC1
        STOP
      ENDIF
!***********************************************************************
!C-- TCH(NCH): TEMPS (s)
!C-- FXCH(NCH), FYCH(NCH), FZCH(NCH): EFFORTS ET MOMENT en N et N.m
!C-- DEFINITION DES EFFORTS ET MOMENT EN FONCTION DU TEMPS
!C-- POUR UN NAVIRE CHENALANT
!C-- TERMINER LE SIGNAL PAR UNE VALEUR TCH<0
!C-- SIGNAL MIS 0 APRES LE TEMPS TCHMAX, LORSQUE LA SIMULATION DEPASSE
!C-- CE TEMPS MAXIMAL
!C-- NOTA : LA DESCRIPTION DU SIGNAL A AU MINIMUM TROIS CARTES:
!C-- DEUX POINTS DE LA COURBE ET UNE CARTE D'INDICE DE FIN (TCH<0)
!C-- ATTENTION! PAS DE PRISE EN COMPTE D'UNE DUREE DE DEMARRAGE
!C-- PREVOIR UN DEBUT DE SIGNAL A 0 PENDANT CETTE DUREE
!C**********************************************************************
      READ(14,*)TCH(NCH),FXCH(NCH),FYCH(NCH),FZCH(NCH)
      IF(TCH(NCH).GE.0.)GOTO 76
      NCH=NCH-1
      TCHMAX=TCH(NCH)
      REWIND 14


!C-- ECRITURE DU TITRE DU CALCUL
      WRITE(*,*)'TITLE ?'
      READ(*,'(A60)')TITRE


!C**** CONSTITUTION DE LA MATRICE INERTIE

      DO I=1,6
        DO K=1,NC
            DO J=1,6
                DO L=1,NC
                    LK=I+6*(K-1)
                    JL=J+6*(L-1)
                    AIJ(LK,JL)=(CM(I,J,L,K)+AIN(I,J,K))
                    IF(LK.EQ.JL)THEN
                        AIJ(LK,JL+6*NC)=1.
                    ELSE
                        AIJ(LK,JL+6*NC)=0.
                    ENDIF
                END DO
            END DO
        END DO
      END DO

!C*** INVERSION DE LA MATRICE INERTIE
!C*** AIJ MATRICE 6 LIGNES x 12 COLONNES, AVEC A MATRICE INERTIE ET MATRICE UNITE I = (A,I)
!C*** LA MATRICE I PERMET DE STOCKER PROVISOIREMENT LA MATRICE INVERSE A-1 LORS DE L'EXECUTION
!C*** DE LA SUBROUTINE GAUSS. LES VALEURS DES COLONNES 7 A 12 TRANSFEREES ENSUITE DANS MATRICE
!C*** INITIALE A(6,6) QUI DEVIENT ALORS A-1(6,6). LA PARTIE COMPLEMENTAIRE DE LA MATRICE N'EST
!C*** PLUS UTILISEE (DE LA COLONNE 7 A 12) SI CE N'EST POUR STOCKER LA PARTIE EFFORTS EN COLONNE 7
!C*** LORS DE LA RESOLUTION DU SYSTEME: F = A(J,7) PUIS dX/dt = V et dV/dt = A-1(I,J) * A(J,7)

      NCOR6=6*NCOR
      NC6=6*NC
      NC12=12*NC
      CALL GAUSS(AIJ,NCOR6,NC6,NC12,1.E-6)
      DO I=1,NC6
        DO J=1,NC6
            AIJ(I,J)=AIJ(I,J+NC6)
        END DO
      END DO

!C-- PARAMETRES DE LA SIMULATION:
!C-- EN HOULE IRREGULIERE, LES VALEURS DE DS ET PAST SONT FIXEES PAR
!C-- LES VALEURS OBTENUES LORS DU CALCUL DES EFFORTS DE HOULE
!C-- ET DES IRF DE RADIATION
 1240 CONTINUE
      IF(IRREG.EQ.0)THEN
        WRITE(*,*)'TOTAL SIMULATION TIME (IN SECONDS)?'
        READ(*,*,ERR=1240)DS
        IF(DS.LE.0)GOTO 1240
 1241   WRITE(*,*)'TIME STEP (IN SECOND)?'
        READ(*,*,ERR=1241)PAST
        IF(PAST.LE.0)GOTO 1241
      ENDIF
      IF(IRREG.EQ.1)THEN
        DS = THOMAX
        PAST = RdtnTime(2)-RdtnTime(1)
        WRITE(*,*)'TOTAL SIMULATION TIME (IN SECONDS)?'
        WRITE(*,'(f14.2)')THOMAX
        WRITE(*,*)'TIME STEP (IN SECOND)?'
        WRITE(*,'(g14.4)')PAST
      ENDIF

 1242 WRITE(*,*)'RAMP-UP TIME (IN SECONDS) ?'
      READ(*,*,ERR=1242)DMAR
      IF(DMAR.LT.0)GOTO 1242

!C-- INITIALISATIONS

      DO K=1,NC
        DO I=1,6
            IJ=I+6*(K-1)
            Y(IJ)=0.
            Y(IJ+6*NC)=0.
        END DO
      END DO

      T=0.
      TT(1)=T
      NIT0=1
      NIT=DS/PAST+1
!C--  CONTROLE DU NOMBRE DE PAS DE TEMPS
      IF(NIT.GT.NMAX)THEN
        WRITE(*,*)'NUMBER OF TIME STEPS: NMAX>72000'
        GOTO 1240
      ENDIF
!C-- INITIALISATIONS
      DO 310 I=1,18
        TM(1,I)=0.
 310  CONTINUE
      DO 510 IP=1,NPTS
        IJ=(IP-1)*9
        TP(1,IJ+1)=0.
        TP(1,IJ+2)=0.
        TP(1,IJ+3)=0.
        TP(1,IJ+4)=0.
        TP(1,IJ+5)=0.
        TP(1,IJ+6)=0.
        TP(1,IJ+7)=0.
        TP(1,IJ+8)=0.
        TP(1,IJ+9)=0.
 510  CONTINUE
      DO 511 I=1,NAN
        TL(1,I)=0.
 511  CONTINUE

!C-- RESOLUTION

 2345 CONTINUE
      WRITE(*,*)'*** CALCULATION IN PROGRESS ***'
      DO 20 II=NIT0+1,NIT
        IF(IRREG.EQ.0)THEN
            CALL RK(NC,Y,DERY,T,PAST,FCT)
        ELSE
            CALL RK(NC,Y,DERY,T,PAST,FCTIR)
        ENDIF
!C-> TEMPS
        TT(II)=T
!C-> MOUVEMENTS,VITESSES,ACCELERATIONS
        DO 300 I=1,3
            TM(II,I)=Y(I)
            TM(II,I+6)=Y(I+6)
            TM(II,I+12)=DERY(I+6)
 300    CONTINUE

        DO 400 I=4,6
            TM(II,I)=Y(I)*RADEG
            TM(II,I+6)=Y(I+6)*RADEG
            TM(II,I+12)=DERY(I+6)*RADEG
 400    CONTINUE

!C***********************************************************************
!C      CALCULS PRELIMINAIRES POUR EFFET MEMOIRE DE RADIATION
!C      EN HOULE IRREGULIERE
!C***********************************************************************
        IF(IRREG.EQ.1)THEN
            IndRdtn = T/PAST
            IndRdtn = IndRdtn+1
!C***********************************************************************
!C   SAUVEGARDE DES VALEURS DE VITESSE DU CORPS POUR
!C   LES TEMPS ANTERIEURS AU TEMPS T, JUSQU'A T-RdtnTMax
!C   CES VALEURS SONT MISES DANS LE TABLEAU YHist
!C   SI LE TABLEAU YHist EST PLEIN, ON DECALE LES VALEURS D'UNE UNITE
!C   A CHAQUE PAS DE TEMPS POUR LE CALCUL
!C***********************************************************************
            DO 304 L=1,NC
!C-- REMPLISSAGE DU TABLEAU YHist POUR LES NStepRdtn PAS DE TEMPS
                IF (IndRdtn.LE.NStepRdtn) THEN
                    DO 301 J = 1,6
                        JL=J+6*(L-1)
                        YHist(IndRdtn,JL) = Y(JL+6*NC)
 301                CONTINUE
                ELSE
!C--  TABLEAU DECALE D'UNE UNITE LORSQUE LE NOMBRE DE PAS DE TEMPS
!C--  DEPASSE NStepRdtn (SOIT RdtnTMax, TEMPS MAXIMUM POUR L'EFFET MEMOIRE)
                    DO 303 J = 1,6
                        JL=J+6*(L-1)
                        DO 302 I = 2,NStepRdtn
                            YHist(I-1,JL) = YHist(I,JL)
 302                    CONTINUE
                        YHist(NStepRdtn,JL) = Y(JL+6*NC)
 303                CONTINUE
                ENDIF
 304        CONTINUE
        ENDIF
!C**********************************************************************

!C-- MOUVEMENTS,VITESSES,ACCELERATIONS AUX POINTS PARTICULIERS
        DO 500 IP=1,NPTS
            IJ=(IP-1)*9
            CALL PVG(Y,DERY,XPTS(IP),YPTS(IP),ZPTS(IP),&
     &      TP(II,IJ+1),TP(II,IJ+2),TP(II,IJ+3),&
     &      TP(II,IJ+4),TP(II,IJ+5),TP(II,IJ+6),&
     &      TP(II,IJ+7),TP(II,IJ+8),TP(II,IJ+9))
            TP(II,IJ+1)=TP(II,IJ+1)-XPTS(IP)
            TP(II,IJ+2)=TP(II,IJ+2)-YPTS(IP)
            TP(II,IJ+3)=TP(II,IJ+3)-ZPTS(IP)
 500    CONTINUE
!C-- TENSION DANS LES AMARRES
        IF(T.LE.DMAR)THEN
            EWT1=1.-1./COSH(9.90348755*T/DMAR)
        ELSE
            EWT1=1.-1./COSH(9.90348755)
        ENDIF

        DO 501 I=1,NAN ! BOUCLE POUR EFFORTS AMARRES ET DEFENSES
        CALL POS(Y,XPM(I),YPM(I),ZPM(I),XPMN,YPMN,ZPMN)
!C-- TYPE RESSORT (NON UTILISE)
!*        IF(IK(I).EQ.0)THEN
!*        DELT=SQRT((XPMN-XPF(I))**2+(YPMN-YPF(I))**2+(ZPMN-ZPF (I))**2)
!*     &  -RL(I)
!*        TL(II,I)=(FAMA(I,DELT)+PT(I)*EWT1)/(1000.*G)
!*        ENDIF
!C-- TYPE RESSORT EN TRACTION (AMARRES)
        IF(IK(I).EQ.1)THEN
        DELT=SQRT((XPMN-XPF(I))**2+(YPMN-YPF(I))**2+(ZPMN-ZPF (I))**2)&
     &  -RL(I)
        TL(II,I)=MAX(FAMA(I,DELT)+PT(I)*EWT1,0.)/(1000.*G)
!*        TL(II,I)=MAX(FAMA(I,DELT),0.)/(1000.*G)
        ENDIF
!C-- TYPE LIAISON RIGIDE (MOUVEMENT EN X ET Y)
        IF(IK(I).EQ.2)THEN
        RLI=SQRT((XPMN-XPF(I))**2+(YPMN-YPF(I))**2+(ZPMN-ZPF(I))**2)
        DELT=SQRT((XPMN-XPM(I))**2+(YPMN-YPM(I))**2)
        ANGAMO=0.
        TL(II,I)=0.
!*        IF(II.EQ.(NIT0+1))THEN
        IF(T.EQ.0.)THEN
            T0(I)=0.
            DELT0(I)=0.
            reset0(I)=0.
        ENDIF

        IF((RLI-RL(I)).GE.0.)THEN
          IF((XPMN-XPM(I)).NE.0.)THEN
            PI=4*ATAN(1.)
            ANGAMO = ABS(ATAN((YPMN-YPM(I))/(XPMN-XPM(I))))
            ANGAMO = ANGAMO*180/PI
          ELSE
            ANGAMO=90.
          ENDIF
          IF(DELT.NE.0.)THEN
           CALL FAUTMO(I,DELT0(I),DELT,T0(I),T,ANGAMO,reset0(I),reset)
          ENDIF
          TL(II,I)=MAX(EFFAUTMO(I)+PT(I)*EWT1,0.)/(1000.*G)
        ENDIF

        T0(I)=T
        DELT0(I)=DELT
        reset0(I)=0.

        ENDIF
!C-- TYPE LIAISON RIGIDE (MOUVEMENT SEULEMENT EN X)
        IF(IK(I).EQ.21)THEN
          DELT=SQRT((XPMN-XPM(I))**2)
          ANGAMO=0.
          TL(II,I)=0.
!*          IF(II.EQ.(NIT0+1))THEN
          IF(T.EQ.0.)THEN
            T0(I)=0.
            DELT0(I)=0.
            reset0(I)=0.
          ENDIF

          IF(DELT.NE.0.)THEN
           CALL FAUTMO(I,DELT0(I),DELT,T0(I),T,ANGAMO,reset0(I),reset)
           TL(II,I)=MAX(EFFAUTMO(I)+PT(I)*EWT1,0.)/(1000.*G)
          ENDIF

          T0(I)=T
          DELT0(I)=DELT
          reset0(I)=0.

        ENDIF
!C-- TYPE LIAISON RIGIDE (MOUVEMENT SEULEMENT EN Y)
        IF(IK(I).EQ.22)THEN
        RLI=SQRT((XPMN-XPF(I))**2+(YPMN-YPF(I))**2+(ZPMN-ZPF(I))**2)
        DELT=SQRT((YPMN-YPM(I))**2)
        ANGAMO=90.
        TL(II,I)=0.
!*        IF(II.EQ.(NIT0+1))THEN
        IF(T.EQ.0.)THEN
            T0(I)=0.
            DELT0(I)=0.
            reset0(I)=0.
        ENDIF

        IF((RLI-RL(I)).GE.0.)THEN
          IF(DELT.NE.0.)THEN
           CALL FAUTMO(I,DELT0(I),DELT,T0(I),T,ANGAMO,reset0(I),reset)
          ENDIF
          TL(II,I)=MAX(EFFAUTMO(I)+PT(I)*EWT1,0.)/(1000.*G)
        ENDIF

        T0(I)=T
        DELT0(I)=DELT
        reset0(I)=0.

!*      TOTO = PT(I)*EWT1
!*      write ( *, '(a)' ) ' '
!*      write ( *, '(a,a)' ) '   I    T          DELT            ',
!*     &      'ANGAMO          EFFAUTMO          TENSION'
!*      write ( *, '(a)' ) ' '
!*      write ( *, '(i4,g14.6,2x,5g14.6)' ) I,T,DELT,ANGAMO,EFFAUTMO(I),
!*     &TOTO,TL(II,I)

        ENDIF
!C-- TYPE LIAISON AVEC UN SYSTEME AMORTISSEUR
        IF(IK(I).EQ.3)THEN
            IF(II.EQ.(NIT0+1))THEN
                TL(II,I)=PT(I)/(1000.*G)
            ELSE
                TL(II,I)=MAX(EFFSHTEN(I),0.)/(1000.*G)
            ENDIF

        ENDIF
!C-- RESSORT EN COMPRESSION (DUCS D'ALBE)
        IF(IK(I).EQ.-1)THEN
            DELT=YPM(I)-YPMN
            IF(YPM(I).LT.0.)THEN
                DELT = -DELT
            ENDIF
            EFDALB = FAMA(I,DELT)
            IF(DELT.LT.0.)THEN
                EFDALB = -FAMA(I,ABS(DELT))
            ENDIF
            TL(II,I)=MIN(EFDALB+PT(I)*EWT1,0.)/(1000.*G)
        ENDIF
 501    CONTINUE ! FIN BOUCLE AMARRES ET DEFENSES

 20   CONTINUE
!C--> ********* FIN DE LA BOUCLE DE CALCUL ***********
!C----------------------------------------------------------------------

!C-- CHOIX DE L'ACTION A EFFECTUER

 1234 CONTINUE
      WRITE(*,1000)
      READ(*,*,ERR=1234)ICH

!C-- ECRITURE DES RESULTATS DANS FICHIERS

      IF(ICH.EQ.1)THEN
 4567   CONTINUE
        WRITE(*,1001)
        READ(*,*,ERR=4567)ICHOIX
!C-- ECRITURE MOUVEMENTS, VITESSES OU ACCELERATIONS DU CENTRE DE GRAVITE
        IF(ICHOIX.GE.1.AND.ICHOIX.LE.3)THEN
            CALL TRAMOU(ICHOIX)
            GOTO 4567
        ENDIF
!C-- ECRITURE MOUVEMENTS, VITESSES OU ACCELERATIONS D'UN POINT PARTICULIER
        IF(ICHOIX.GE.4.AND.ICHOIX.LE.6)THEN
            IF(NPTS.GE.1)THEN
 1244           WRITE(*,1002)NPTS
                READ(*,*,ERR=1244)IPT
                IF(IPT.GT.NPTS)GOTO 1244
                IF(IPT.LE.0)GOTO 4567
                CALL TRAPNT(ICHOIX,IPT)
            ELSE
                WRITE(*,*)'NO CALCULATION POINT GIVEN'
            ENDIF
        GOTO 4567
        ENDIF
!C-- ECRITURE EFFORTS AMARRES ET DUCS D'ALBE
        IF(ICHOIX.EQ.7)THEN
            WRITE(*,1003)NAN
            CALL TRATEN(NAN)
            GOTO 4567
        ENDIF

        GOTO 1234
      ENDIF

!**** ON CONTINUE

      IF(ICH.EQ.2)THEN
 1253   WRITE(*,*)'ADDITIONAL DURATION (IN SECONDS) ?'
        READ(*,*,ERR=1253)DS
        IF(DS.LE.0)GOTO 1253
        NIT0=NIT
        NIT=NIT+DS/PAST
!C--  CONTROLE NOMBRE DE PAS DE TEMPS
        IF(NIT.GT.NMAX)THEN
            WRITE(*,*)'NUMBER OF TIME STEPS: NMAX>72000',&
     &      '; RERUN CALCULATION'
            GOTO 1240
        ELSE
            GOTO 2345
        ENDIF
      ENDIF

!**** ANALYSE

      IF(ICH.EQ.3)THEN
 5679   CONTINUE
        WRITE(*,*)'START OF ANALYSIS (IN SECONDS)?'
        READ(*,*,ERR=5679)TDEB
 1246   WRITE(*,*)'END OF ANALYSIS (IN SECONDS)?'
        READ(*,*,ERR=1246)TFIN
        IF(TFIN.GT.TT(NIT))THEN
            WRITE(*,*)'*** END TIME TOO LONG ***'
            GOTO 5679
        ENDIF
        ITTD=0
        ITTF=0
        DO 63 I=1,NIT
            IF(TT(I).GT.TDEB.AND.ITTD.EQ.0)THEN
                ITD=I-1
                ITTD=1
            ENDIF
            IF(TT(I).GE.TFIN.AND.ITTF.EQ.0)THEN
                ITF=I
                ITTF=1
            ENDIF
 63     CONTINUE
!C-- NOMBRE DE PAS DE TEMPS POUR ANALYSE DOIT ETRE MULTIPLE DE 2
        NFFT=LOG(FLOAT(ITF-ITD))/LOG(2.)
        NFT=2**NFFT

        IF(NFT.LT.256)THEN
            WRITE(*,*)'*** INSUFFICIENT NUMBER OF POINTS ',&
     &      'FOR ANALYSIS ***'
            GOTO 1234
        ENDIF
        ICHFFT=-1
!C--- ANALYSE DES VITESSES DE VENT
        DO I=ITD+1,ITD+NFT
            TS(I)=V(TT(I))
            ZZ(I-ITD)=TS(I)
        ENDDO
        CALL DDNDTC(1,ZZ,NFFT,PAST,.05)
!C--- ANALYSE DES MOUVEMENTS DU CENTRE DE GRAVITE
        DO IM=1,6
            DO I=ITD+1,ITD+NFT
                ZZ(I-ITD)=TM(I,IM)
            ENDDO
            CALL DDNDTC(1+IM,ZZ,NFFT,PAST,.05)
        ENDDO
!C--- ANALYSE DES MOUVEMENTS DES POINTS SPECIFIQUES
        DO IPT=1,NPTS
            DO IM=1,3
                IP=9*(IPT-1)+IM
                DO I=ITD+1,ITD+NFT
                    ZZ(I-ITD)=TP(I,IP)
                ENDDO
                CALL DDNDTC(19+9*(IPT-1)+IM,ZZ,NFFT,PAST,.05)
            ENDDO
        ENDDO
!C--- ANALYSE DES EFFORTS DANS LES AMARRES ET DEFENSES
        DO IL=1,NAN
            DO I=ITD+1,ITD+NFT
                ZZ(I-ITD)=TL(I,IL)
            ENDDO
            CALL DDNDTC(19+9*NPTS+IL,ZZ,NFFT,PAST,.05)
        ENDDO

4565    CONTINUE
        WRITE(*,1006)
        READ(*,*,ERR=4565)ITAB
!C-- SORTIE TABLEAUX DE RESULTATS
        IF(ITAB.EQ.1)THEN
         WRITE(20,1013)TITRE
         WRITE(*,1007)
         WRITE(20,1007)
         WRITE(*,1009)XMOY(1),XMIN(1),XMAX(1),XDEL(1),XVAR(1)
         WRITE(20,1009)XMOY(1),XMIN(1),XMAX(1),XDEL(1),XVAR(1)
         WRITE(*,1008)(XMOY(K),XMIN(K),XMAX(K),XDEL(K),XVAR(K),K=2,7)
         WRITE(20,1008)(XMOY(K),XMIN(K),XMAX(K),XDEL(K),XVAR(K),K=2,7)
         DO IPT=1,NPTS
          WRITE(*,1010)IPT,(XMOY(K),XMIN(K),XMAX(K),XDEL(K),XVAR(K),&
     &    K=19+9*(IPT-1)+1,19+9*(IPT-1)+3)
          WRITE(20,1010)IPT,(XMOY(K),XMIN(K),XMAX(K),XDEL(K),XVAR(K),&
     &    K=19+9*(IPT-1)+1,19+9*(IPT-1)+3)
         ENDDO
         IF(NAN.GE.1)THEN
          WRITE(*,1012)
          WRITE(20,1012)
         ENDIF
         DO IL=1,NAN
          K=19+9*NPTS+IL
          WRITE(*,1011)IL,XMOY(K),XMIN(K),XMAX(K),XDEL(K),XVAR(K)
          WRITE(20,1011)IL,XMOY(K),XMIN(K),XMAX(K),XDEL(K),XVAR(K)
         ENDDO
!C----------------------------------------------------------------------
         WRITE(*,1013)TITRE
         WRITE(20,1013)TITRE
         WRITE(*,1107)
         WRITE(20,1107)
         WRITE(*,1109)XP1(1),XA1(1),XP2(1),XA2(1)
         WRITE(20,1109)XP1(1),XA1(1),XP2(1),XA2(1)
         WRITE(*,1108)(XP1(K),XA1(K),XP2(K),XA2(K),K=2,7)
         WRITE(20,1108)(XP1(K),XA1(K),XP2(K),XA2(K),K=2,7)
         DO IPT=1,NPTS
          WRITE(*,1110)IPT,(XP1(K),XA1(K),XP2(K),XA2(K),&
     &    K=19+9*(IPT-1)+1,19+9*(IPT-1)+3)
          WRITE(20,1110)IPT,(XP1(K),XA1(K),XP2(K),XA2(K),&
     &    K=19+9*(IPT-1)+1,19+9*(IPT-1)+3)
         ENDDO
         IF(NAN.GE.1)THEN
          WRITE(*,1112)
          WRITE(20,1112)
         ENDIF
         DO IL=1,NAN
          K=19+9*NPTS+IL
          WRITE(*,1111)IL,XP1(K),XA1(K),XP2(K),XA2(K)
          WRITE(20,1111)IL,XP1(K),XA1(K),XP2(K),XA2(K)
         ENDDO

        ENDIF
!C------------------------------------------------------
      GOTO 1234
      ENDIF

 1251 WRITE(*,*)'ANOTHER RUN ? (YES:1 - NO:0)'
      READ(*,*,ERR=1251)IOUI
      IF(IOUI.EQ.1)THEN
       CLOSE(UNIT=10)
       CLOSE(UNIT=11)
       CLOSE(UNIT=12)
       CLOSE(UNIT=13)
       CLOSE(UNIT=14)
       CLOSE(UNIT=15)
       CLOSE(UNIT=16)
       CLOSE(UNIT=20)
       CLOSE(UNIT=31)
       CLOSE(UNIT=32)
       CLOSE(UNIT=33)
       GOTO 3458
      ENDIF

      STOP

!**** FORMATS

 901  FORMAT(A12)
 902  FORMAT(//' USED FILES : '/&
     &' 1 ',A12/&
     &' 2 ',A12/&
     &' 3 ',A12/&
     &' 4 ',A12/&
     &' 5 ',A12/&
     &' 6 ',A12/&
     &' 7 ',A12//)
!*     &' 8 ',A12//)
 1000 FORMAT(///,&
     &' 0 ---> PROGRAM EXIT '/&
     &' 1 ---> WRITING OF RESULTS FILES '/&
     &' 2 ---> ADDITIONAL DURATION '/&
     &' 3 ---> ANALYSIS OF RESULTS '//)
 1001 FORMAT(///,&
     &' 0 ---> NO FILE WRITING'/&
     &' 1 ---> CENTER OF GRAVITY MOTIONS'/&
     &' 2 ---> CENTER OF GRAVITY VELOCITIES'/&
     &' 3 ---> CENTER OF GRAVITY ACCELERATIONS'/&
     &' 4 ---> MOTIONS OF A SPECIFIC POINT'/&
     &' 5 ---> VELOCITIES OF A SPECIFIC POINT'/&
     &' 6 ---> ACCELERATION OF A SPECIFIC POINT'/&
     &' 7 ---> MOORING LINE AND FENDER LOADS'//)
 1002 FORMAT(///,&
     &' ---> SPECIFIC POINT NUMBER: BETWEEN 1 AND',I3,/)
 1003 FORMAT(///,&
     &' ---> NUMBER OF MOORING LINES AND FENDERS:',I3,/)
 1006 FORMAT(///,&
     &' 0 ---> PROGRAM EXIT'/&
     &' 1 ---> ANALYSIS: TABLE OF RESULTS'//)
 1013 FORMAT(///,1X,A60)
 1007 FORMAT(/&
     &1X/&
     &' ----------------------------------------------------------',&
     &'----------------------'/&
     &' |             |   AVERAGE  |    MIN.    |    MAX.    |   ',&
     &'MAX-MIN  |    RMS     |'/&
     &' ----------------------------------------------------------',&
     &'----------------------')
 1009 FORMAT(&
     &' | WIND  (M/S) |',5(' ',1PE10.3,' |')/&
     &' --------------------------------------',&
     &'------------------------------------------')
 1008 FORMAT(&
     &' | SURGE (M)   |',5(' ',1PE10.3,' |')/&
     &' --------------------------------------',&
     &'------------------------------------------'/&
     &' | SWAY  (M)   |',5(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'-----------------------------------------'/&
     &' | HEAVE (M)   |',5(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'-----------------------------------------'/&
     &' | ROLL  (DEG) |',5(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'-----------------------------------------'/&
     &' | PITCH (DEG) |',5(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'-----------------------------------------'/&
     &' | YAW   (DEG) |',5(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'-----------------------------------------')
 1010 FORMAT(&
     &' | POINT ',I3,'   :',63X,' |'/&
     &' ---------------------------------------',&
     &'-----------------------------------------'/&
     &' | SURGE (M)   |',5(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'-----------------------------------------'/&
     &' | SWAY  (M)   |',5(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'-----------------------------------------'/&
     &' | HEAVE (M)   |',5(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'-----------------------------------------')
 1012 FORMAT(&
     &' | TENSION     :',63X,' |'/&
     &' --------------------------------------',&
     &'------------------------------------------')
 1011 FORMAT(&
     &' | LINE ',I2,' (T) |',5(' ',1PE10.3,' |')/&
     &' --------------------------------------',&
     &'------------------------------------------')
 1107 FORMAT(/&
     &1X/&
     &' ----------------------------------------------------------',&
     &'---------'/&
     &' |             |PERIOD 1 (S)| AMPLITUDE 1|PERIOD 2 (S)| AM',&
     &'PLITUDE 2|'/&
     &' ----------------------------------------------------------',&
     &'---------')
 1109 FORMAT(&
     &' | WIND  (M/S) |',4(' ',1PE10.3,' |')/&
     &' --------------------------------------',&
     &'-----------------------------')
 1108 FORMAT(&
     &' | SURGE (M)   |',4(' ',1PE10.3,' |')/&
     &' --------------------------------------',&
     &'-----------------------------'/&
     &' | SWAY  (M)   |',4(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'----------------------------'/&
     &' | HEAVE (M)   |',4(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'----------------------------'/&
     &' | ROLL  (DEG) |',4(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'----------------------------'/&
     &' | PITCH (DEG) |',4(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'----------------------------'/&
     &' | YAW   (DEG) |',4(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'----------------------------')
 1110 FORMAT(&
     &' | POINT ',I3,'   :',50X,' |'/&
     &' --------------------------------------',&
     &'-----------------------------'/&
     &' | SURGE (M)   |',4(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'----------------------------'/&
     &' | SWAY  (M)   |',4(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'----------------------------'/&
     &' | HEAVE (M)   |',4(' ',1PE10.3,' |')/&
     &' ---------------------------------------',&
     &'----------------------------')
 1112 FORMAT(&
     &' | TENSION     :',50X,' |'/&
     &' --------------------------------------',&
     &'-----------------------------')
 1111 FORMAT(&
     &' | LINE ',I2,' (T) |',4(' ',1PE10.3,' |')/&
     &' --------------------------------------',&
     &'-----------------------------')
      END PROGRAM SIMBAD
