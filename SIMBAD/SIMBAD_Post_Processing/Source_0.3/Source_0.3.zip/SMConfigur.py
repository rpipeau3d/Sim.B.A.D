# -*- coding: utf-8 -*-
##  This file is part of SIMBAD post-processing program.

##  SIMBAD post-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD post-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD post-processing program.
##  If not, see <https://www.gnu.org/licenses/>.

import vpython as vp
import numpy as np
import Max_Min as MM
# import random as rd

def SMConfigur(res_file1,res_file2,motion_CG,num_dt,time,inum_start,inum_end):

    with open(res_file1,'r') as df:
        raw = df.readlines()
        print('\nReading the file results in the ' + res_file1 + ' file')

# Enumerate to split the result file
        for i, line in enumerate(raw, start=0):
# Wave characteristics
            if i==1:
                Tp = float(raw[i].split()[0])
                DirW = float(raw[i].split()[1])
                Hs = float(raw[i].split()[2])                
# Reading of ship characteristics
            if i==2:
                Lpp = float(raw[i].split()[0])
                Dr = float(raw[i].split()[1])
                Br = float(raw[i].split()[2])
                Wd = float(raw[i].split()[3])

# Reading of center of gravity position
            if i==3:
                xg = float(raw[i].split()[0])
                yg = float(raw[i].split()[1])
                Og = float(raw[i].split()[2])

    with open(res_file2,'r') as df:
        raw = df.readlines()
        print('\nReading the file results in the ' + res_file2 + ' file')
        num_lines = int(raw[0].split()[0])
        typ_lin = np.zeros(num_lines).astype(int)
        xyz_quay = np.zeros((3,num_lines)).astype(float) 
        xyz_ship = np.zeros((3,num_lines)).astype(float) 

# Enumerate to split the result file
        k = 1
        num_lines1 = 0        
        for i in range (num_lines):            
            for j, line in enumerate(raw, start=0):
# Reading of mooring line characteristics
                if j==k:
                    typ_lin[i] = float(raw[j].split()[0])
                    xyz_quay[0,i] = float(raw[j+2].split()[0])
                    xyz_quay[1,i] = float(raw[j+2].split()[1])
                    xyz_quay[2,i] = float(raw[j+2].split()[2])
                    xyz_ship[0,i] = float(raw[j+3].split()[0])
                    xyz_ship[1,i] = float(raw[j+3].split()[1])
                    xyz_ship[2,i] = float(raw[j+3].split()[2])
            k = k+5
            if typ_lin[i] == 1:
                num_lines1 += 1
    max_xlines = MM.Maximum(0,num_lines1,xyz_ship[0,:])
    min_xlines = MM.Minimum(0,num_lines1,xyz_ship[0,:])
    max_zlines = MM.Maximum(0,num_lines1,xyz_ship[2,:])

    imin_quay = 0
    min_yquay = MM.Minimum(0,num_lines1,xyz_quay[1,:])
    for i in range(num_lines1):
        if xyz_quay[1,i] == min_yquay: 
            if imin_quay == 0: 
                imin_quay = i
            else:
                imax_quay = i

# Drawing of mooring configuration
    vp.scene.width = 1000
    vp.scene.height = 500
    # vp.scene.caption = """To rotate "camera", drag with right button or Ctrl-drag.
    # To zoom, drag with middle button or Alt/Option depressed, or use scroll wheel.
    # On a two-button mouse, middle is left + right.
    # To pan left/right and up/down, Shift-drag.
    # Touch screen: pinch/extend to zoom, swipe or two-finger rotate."""
    vp.scene.forward = vp.vector(0,0.3,-1.0)
    vp.scene.userspin = True
    vp.scene.userzoom = True
# Drawing of ship
    ship= vp.box(color= vp.color.cyan,size= vp.vector(Lpp-Br/2,Br,Dr+max_zlines),
                   pos=vp.vector((Lpp-Br/2)/2-xg,0,(max_zlines-Dr)/2))
    bow = vp.cylinder(color= vp.color.cyan,pos=vp.vector(Lpp-xg-Br/2, 0,-Dr), 
                      axis=vp.vector(0, 0, 1),size=vp.vector(Dr+max_zlines,Br,Br))
    if xyz_ship[0,0] < 0:
        stern = vp.box(color= vp.color.cyan,
                    pos=vp.vector(-xg, 0,(max_zlines-Dr)/2), 
                    axis=vp.vector(1, 0, 0),size=vp.vector(-2*xyz_ship[0,0],Br,Dr+max_zlines))
    if xyz_ship[0,0] < 0:
        myship = vp.compound([stern,ship,bow])
    else:
        myship = vp.compound([ship,bow])
    make_axes(40)
    turn_axes("on")
# Drawing of sea surface, soil
    mer = vp.box(pos=vp.vector(0,0,0), size= vp.vector(2*Lpp,5*Br,0.05), 
                texture="water.jpg")
    sol = vp.box(pos=vp.vector(0,0,-Wd), size= vp.vector(2*Lpp,5*Br,0.05), 
                texture="fond.jpg")
# Drawing of quays
    quay1 = vp.box(pos=vp.vector(0,xyz_quay[1,0]+Br/2,(xyz_quay[2,0]-Wd)/2), 
                   size= vp.vector(2*Lpp,Br,xyz_quay[2,0]+Wd), 
                   texture="beton.jpg")
    i1 = imin_quay
    i2 = imax_quay
    length_quay2 = (xyz_quay[0,i2]-xyz_quay[0,i1])
    quay2 = vp.box(pos=vp.vector((xyz_quay[0,i2]+xyz_quay[0,i1])/2-xg,
                   (xyz_quay[1,0]+xyz_quay[1,i1])/2,(xyz_quay[2,i1]-Wd)/2), 
                   size= vp.vector(length_quay2,
                   (xyz_quay[1,0]-xyz_quay[1,i1]),xyz_quay[2,i1]+Wd), 
                   texture="beton.jpg")
# Drawing of lines,bollards,fenders
    line ={}
    bollard = {}
    bollship = {}
    for i in range(num_lines1):
        line[i] = vp.curve(pos=[vp.vector(xyz_quay[0,i]-xg,xyz_quay[1,i],xyz_quay[2,i]),
                vp.vector(xyz_ship[0,i]-xg,xyz_ship[1,i],xyz_ship[2,i])],
                color=vp.color.yellow,radius=0.75)          
        bollard[i] = vp.cylinder(pos=vp.vector(xyz_quay[0,i]-xg,xyz_quay[1,i],xyz_quay[2,i]),
                                 axis=vp.vector(0, 0, 1),radius=2,length=2,texture="metal.jpg")
        bollship[i] = vp.cylinder(pos=vp.vector(xyz_ship[0,i]-xg,xyz_ship[1,i],xyz_ship[2,i]),
                                 axis=vp.vector(0, 0, 1),radius=2,length=2,color=vp.color.red)
    num_fenders = num_lines - num_lines1
    fender = np.zeros(num_fenders).astype(str)
    j = 0
    for i in range(num_lines):
        if typ_lin[i] == -1:
            radius = np.abs(xyz_quay[1,i]-xyz_ship[1,i])/2
            fender[j] = vp.helix(color= vp.color.orange,
                                 pos=vp.vector(xyz_quay[0,i]-xg,xyz_ship[1,i],xyz_quay[2,i]),
                                 axis=vp.vector(0,1,0),thickness = 4,
                                 size=vp.vector(4*radius,2*radius,2*radius))
            j += 1
# Wave, wind, current directions
    DirW = vp.radians(DirW)
    vp.arrow(pos=vp.vector(75, -75, 0), axis=vp.vector(np.cos(DirW)*20,
             np.sin(DirW)*20,0),color=vp.color.red, shaftwidth = 2)
    vp.label(pos=vp.vector(75,-75, 0), text='Wave', align='left', 
             space=30, height=12, border=4, font='sans')
    reponsW = input('If any wind, indicate wind direction:\n'
                +'(default: No wind)\n')
    if reponsW !='':
        try:
            DirWind = float(reponsW)
            DirWind = vp.radians(DirWind)
            vp.arrow(pos=vp.vector(10, -75, 0), axis=vp.vector(np.cos(DirWind)*20,
                     np.sin(DirWind)*20,0),color=vp.color.blue, shaftwidth = 2)
            vp.label(pos=vp.vector(10,-75, 0), text='Wind', align='left', 
                     space=30, height=12, border=4, font='sans')
        except IOError:
            print("Wind direction is not a float") 
    reponsW = input('If any current, indicate current direction:\n'
                +'(default: No current)\n')
    if reponsW !='':
        try:
            DirCur = float(reponsW)
            DirCur = vp.radians(DirCur)
            vp.arrow(pos=vp.vector(150, -75, 0), axis=vp.vector(np.cos(DirCur)*20,
                     np.sin(DirCur)*20,0),color=vp.color.yellow, shaftwidth = 2)
            vp.label(pos=vp.vector(150,-75, 0), text='Current', align='left', 
                     space=30, height=12, border=4, font='sans')
        except IOError:
            print("Wind direction is not a float") 
# Ship motion around the axis origin
    i_posx = myship.pos.x
    i_posy = myship.pos.y
    i_posz = myship.pos.z
    # print(i_posx,i_posy,i_posz)
    mean_roll = np.mean(motion_CG[3,:])
    mean_pitch = np.mean(motion_CG[4,:])
    mean_yaw = np.mean(motion_CG[5,:])
    # print(mean_roll,mean_pitch,mean_yaw)
    mean_roll = vp.radians(mean_roll)
    mean_pitch = vp.radians(mean_pitch)
    mean_yaw = vp.radians(mean_yaw)
    dt = time[1]-time[0]
    Nxyz_ship = pos_line(motion_CG,xyz_ship,xg,yg,Og,num_dt,num_lines1)
    ind_imag=0
    prefix='shipmooring_'
    num_length = 3
    
    for i in range(inum_start,inum_end-1):
        vp.rate(30)
        surge = motion_CG[0,i]
        sway = motion_CG[1,i]
        heave = motion_CG[2,i]
        d_roll = vp.radians(motion_CG[3,i+1])-vp.radians(motion_CG[3,i])
        d_pitch = vp.radians(motion_CG[4,i+1])-vp.radians(motion_CG[4,i])
        d_yaw = vp.radians(motion_CG[5,i+1])-vp.radians(motion_CG[5,i])
        myship.pos.x = i_posx + surge
        myship.pos.y = i_posy + sway
        myship.pos.z = i_posz + heave
        center = vp.vector(myship.pos.x,myship.pos.y,Og+heave)
        # center = vp.vector(myship.pos.x,myship.pos.y,myship.pos.z)
        Vec1,Vec2,Vec3 = rotation(d_roll,d_pitch,d_yaw)
# The roll rotation could be activated if the sequence of ship motions
# is not too long!! Otherwise, it could generate inappropriate motion 
        # myship.rotate(angle=d_roll, axis=Vec1, origin= center)
        myship.rotate(angle=d_pitch, axis=Vec2, origin= center)
        myship.rotate(angle=d_yaw, axis=Vec3, origin= center)
        for j in range(num_lines1):
            line[j].visible = False
            line[j] = vp.curve(pos=[vp.vector(xyz_quay[0,j]-xg,xyz_quay[1,j],xyz_quay[2,j]),
                vp.vector(Nxyz_ship[0,i,j]-xg,Nxyz_ship[1,i,j],Nxyz_ship[2,i,j])],
                color=vp.color.blue,radius=0.75)          
            bollship[j].visible=False
            bollship[j] = vp.cylinder(pos=vp.vector(Nxyz_ship[0,i,j]-xg,Nxyz_ship[1,i,j],Nxyz_ship[2,i,j]),
                        axis=vp.vector(0, 0, 1),radius=2,length=2,color=vp.color.red)
# To be activated for a video production
        # if (time[i]>=4200.0 and time[i]<=4300.0):
        #     if i%5 == 0:
        #         vp.scene.capture(f"{prefix}{ind_imag:0{num_length}d}")
        #         myevt = vp.scene.waitfor('click')
        #         ind_imag+=1
        
def rotation(roll,pitch,yaw):
    C1 = np.cos(roll)
    C2 = np.cos(pitch)
    C3 = np.cos(yaw)
    S1 = np.sin(roll)
    S2 = np.sin(pitch)
    S3 = np.sin(yaw)
    Vec1 = vp.vector(C3*C2,C3*S2*S1-S3*C1,C3*S2*C1+S3*S1)
    Vec2 = vp.vector(S3*C2,S3*S2*S1+C3*C1,S3*S2*C1-C3*S1)
    Vec3 = vp.vector(-S2,C2*S1,C2*C1)
    return Vec1,Vec2,Vec3

def pos_line(motion_CG,xyz_ship,xg,yg,Og,num_dt,num_lines1):
    Nxyz_ship = np.zeros((3,num_dt,num_lines1)).astype(float)
    for i in range(num_dt):
     C1 = np.cos(vp.radians(motion_CG[3,i]))
     C2 = np.cos(vp.radians(motion_CG[4,i]))
     C3 = np.cos(vp.radians(motion_CG[5,i]))
     S1 = np.sin(vp.radians(motion_CG[3,i]))
     S2 = np.sin(vp.radians(motion_CG[4,i]))
     S3 = np.sin(vp.radians(motion_CG[5,i]))
     for j in range(num_lines1):
      XP1= xyz_ship[0,j]-xg
      YP1= xyz_ship[1,j]-yg
      ZP1= xyz_ship[2,j]-Og
      XP2= C3*C2*XP1+(C3*S2*S1-S3*C1)*YP1+(C3*S2*C1+S3*S1)*ZP1
      YP2= S3*C2*XP1+(S3*S2*S1+C3*C1)*YP1+(S3*S2*C1-C3*S1)*ZP1
      ZP2= -S2*XP1+C2*S1*YP1+C2*C1*ZP1
      Nxyz_ship[0,i,j]=xyz_ship[0,j]+motion_CG[0,i]+XP2-XP1
      Nxyz_ship[1,i,j]=xyz_ship[1,j]+motion_CG[1,i]+YP2-YP1
      Nxyz_ship[2,i,j]=xyz_ship[2,j]+motion_CG[2,i]+ZP2-ZP1    
    return Nxyz_ship

def make_axes(length):
    global axes
    xaxis = vp.arrow(pos=vp.vector(0,0,0),axis=length*vp.vector(1,0,0),
                     color=vp.color.red)
    yaxis = vp.arrow(pos=vp.vector(0,0,0),axis=length*vp.vector(0,1,0),
                  color=vp.color.green)
    zaxis = vp.arrow(pos=vp.vector(0,0,0),axis=length*vp.vector(0,0,1),
                     color=vp.color.blue)
    fudge = 0.06*length
    xlabel = vp.label(text="x",color=xaxis.color,
                      pos=xaxis.pos+xaxis.axis+vp.vector(0,fudge,0),box=False)
    ylabel = vp.label(text="y",color=yaxis.color,
                      pos=yaxis.pos+yaxis.axis+vp.vector(fudge,0,0),box=False)
    zlabel = vp.label(text="z",color=zaxis.color,
                      pos=zaxis.pos+zaxis.axis+vp.vector(fudge,0,0),box=False)
    axes = [xaxis,yaxis,zaxis,xlabel,ylabel,zlabel]
    return 

def turn_axes(OnOrOff):
    global axes
    if (OnOrOff == "on" or OnOrOff == "On" or OnOrOff == "ON"):
        for shape in axes:
            shape.visible = True
    if (OnOrOff == "off" or OnOrOff == "Off" or OnOrOff == "OFF"):
        for shape in axes:
            shape.visible = False
    return
