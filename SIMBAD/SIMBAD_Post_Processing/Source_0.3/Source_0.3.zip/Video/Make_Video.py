# -*- coding: utf-8 -*-
"""
Created on Sat Aug  2 15:47:17 2025

@author: pierre.francois.deme
"""

import glob
import os
import Video

def seq_renaming(folder='.', prefix='shipmooring_', start=0, num_length=3):
    count = start
    folder += '/'
    for fname in glob.glob(folder + '*.png'):
        suffix = fname[fname.rfind('.'):]
        outstr = f"{folder}/{prefix}{count:0{num_length}d}{suffix}"
        count += 1
        os.rename(fname, outstr)
        
seq_renaming('Images')
Video.video_from_images('Images', 'shipmooring.avi',length_of_video_in_seconds=50)