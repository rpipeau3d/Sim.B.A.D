##  This file is part of SIMBAD post-processing program.

##  SIMBAD post-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD post-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD post-processing program.
##  If not, see <https://www.gnu.org/licenses/>.


# Import modules
from scipy.signal import find_peaks
import numpy as np
from math import ceil

# Function maximum
def Maximum(inum_start,inum_end,liste):
    maxi = liste[inum_start]
    longueur=len(liste)
    for i in range(inum_start,inum_end):
        if liste[i] >= maxi:
            maxi = liste[i]
    return maxi

# Function minimum
def Minimum(inum_start,inum_end,liste):
    mini = liste[inum_start]
    longueur=len(liste)
    for i in range(inum_start,inum_end):
        if liste[i] <= mini:
            mini = liste[i]
    return mini

# Function determination and ranking of peaks in a time series
def Rank_peak(inum_start,inum_end,liste):
    x = liste[inum_start:inum_end]
    mean_x = np.mean(x)
    min_x = np.min(x)
    if all(0 == a for a in x) is False:
        peaks1, _ = find_peaks(x, height=mean_x)
        peaks2, _ = find_peaks(-x, height=-mean_x)
        if mean_x>=0:
            x_sort1 = sorted(x[peaks1],reverse=True)
            x_sort2 = sorted(x[peaks2])
            number_peaks = len(peaks1)
        else:
            x_sort1 = sorted(x[peaks2])
            x_sort2 = sorted(x[peaks1],reverse=True)
            number_peaks = len(peaks2)

# Calculation of F1/3 and F1/10
        
        h3 = 0.0
        num_h3 = int(ceil(number_peaks/3))
        if num_h3!=0:
            for i in range(num_h3):
                  h3= h3+x_sort1[i]
            h3= h3/num_h3

        h10 = 0.0
        num_h10 = int(ceil(number_peaks/10))
        if num_h10!=0:
            for i in range(num_h10):
                  h10= h10+x_sort1[i]
            h10= h10/num_h10

    else:
        x_sort1 = x
        x_sort2 = x
        h3 = 0.0
        h10 = 0.0

# Calculation of mean and standard deviation on the peaks
# statistical maximum and minimum values
    hmean1 = np.mean(x_sort1)
    hstd1 = np.std(x_sort1)
    hmean2 = np.mean(x_sort2)
    hstd2 = np.std(x_sort2)
    if mean_x>=0:
        hmaxstd = hmean1 + 3.8*hstd1
        hminstd = hmean2 - 3.8*hstd2
    else:
        hminstd = hmean1 - 3.8*hstd1
        hmaxstd = hmean2 + 3.8*hstd2

##    print(number_peaks,num_h3,num_h10)
##    plt.plot(x)
##    plt.plot(peaks, x[peaks], "x")
##    plt.plot(np.full_like(x,mean_x), "--", color="gray")
##    plt.show()

    return h3,h10,hminstd,hmaxstd

# Function determination and ranking of peaks in a time series
def Rank_peakMov(inum_start,inum_end,liste):
    x = liste[inum_start:inum_end]
    mean_x = np.mean(x)
    min_x = np.min(x)
    max_x = np.max(x)
    if max_x>0 and min_x>=0:
        peaks1, _ = find_peaks(x, height=mean_x)
        peaks2, _ = find_peaks(-x, height=-mean_x)
        x_sort1 = sorted(x[peaks1],reverse=True)
        x_sort2 = sorted(x[peaks2])
    if max_x>=0 and min_x<0:
        peaks1, _ = find_peaks(x, height=0)
        peaks2, _ = find_peaks(-x, height=0)
        x_sort1 = sorted(x[peaks1],reverse=True)
        x_sort2 = sorted(x[peaks2])
    if max_x<=0 and min_x<0:
        peaks1, _ = find_peaks(-x, height=-mean_x)
        peaks2, _ = find_peaks(x, height=mean_x)
        x_sort1 = sorted(x[peaks1])
        x_sort2 = sorted(x[peaks2],reverse=True)

##    plt.plot(x)
##    plt.plot(peaks2, x[peaks2], "x")
##    plt.plot(np.full_like(x,0), "--", color="gray")
##    plt.show()

# Calculation of F1/3 and F1/10
    number_peaks1 = len(peaks1)
    h31 = 0.0
    num_h31 = int(ceil(number_peaks1/3))
    if num_h31!=0:
        for i in range(num_h31):
              h31= h31+x_sort1[i]
        h31= h31/num_h31

    number_peaks2 = len(peaks2)
    h32 = 0.0
    num_h32 = int(ceil(number_peaks2/3))
    if num_h32!=0:
        for i in range(num_h32):
              h32= h32+x_sort2[i]
        h32= h32/num_h32
    
    h101 = 0.0
    num_h101 = int(ceil(number_peaks1/10))
    if num_h101!=0:
        for i in range(num_h101):
              h101= h101+x_sort1[i]
        h101= h101/num_h101

    h102 = 0.0
    num_h102 = int(ceil(number_peaks2/10))
    if num_h102!=0:
        for i in range(num_h102):
              h102= h102+x_sort2[i]
        h102= h102/num_h102

# Calculation of mean and standard deviation on the peaks
# statistical maximum and minimum values
    hmean1 = np.mean(x_sort1)
    hstd1 = np.std(x_sort1)
    hmean2 = np.mean(x_sort2)
    hstd2 = np.std(x_sort2)

    if max_x>0 and min_x>=0:
        h3 = h31
        h10 = h101
        hmaxstd = hmean1 + 3.8*hstd1
        hminstd = hmean2 - 3.8*hstd2
    if max_x>=0 and min_x<0:
        h3 = max(h31,abs(h32))
        if h3 == abs(h32):
            h3 = -h3
        h10 = max(h101,abs(h102))
        if h10 == abs(h102):
            h10 = -h10
        hmaxstd = hmean1 + 3.8*hstd1
        hminstd = hmean2 - 3.8*hstd2
    if max_x<=0 and min_x<0:
        h3 = h31
        h10 = h101
        hminstd = hmean1 - 3.8*hstd1
        hmaxstd = hmean2 + 3.8*hstd2        

    return h3,h10,hminstd,hmaxstd
