##  This file is part of SIMBAD post-processing program.

##  SIMBAD post-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD post-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD post-processing program.
##  If not, see <https://www.gnu.org/licenses/>.


# Import modules
import numpy as np
import matplotlib.pyplot as plt
from math import ceil
from prettytable import PrettyTable
import Max_Min as MM

# TENSIONS IN LINES AND DOLPHINS
def Tensions(res_file):
    with open(res_file,'r') as df:
        raw = df.readlines()
        print('\nReading the file results in the ' + res_file + ' file')
        #print(len(raw))
        num_dt = len(raw)-8

# Enumerate to split the result file
        for i, line in enumerate(raw, start=0):

# Reading of total number of lines and dolphins
            if 'NUMBER OF LINES:' in line:
                number_lines = raw[i].split()[-1]
                number_lines = int(number_lines)
                #print (number_lines)
# Reading of each line number
            if 'TIME' in line:
                no_line = {}
                no_line = np.zeros(number_lines).astype(int)
                tmp = number_lines
                for j in range(tmp):
                    no_line[j] = raw[i].split()[j+1]
                #print(no_line)
# Reading of time and tensions data
        time = {}
        time = np.zeros(num_dt).astype(np.float)
        tension_line = {}
        tension_line = np.zeros((number_lines,num_dt)).astype(np.float)
        inum = 0
        for i, line in enumerate(raw, start=0):
            if i > 7:
                time[inum] = raw[i].split()[0]
                tmp = number_lines
                for j in range(tmp):
                    tension_line[j][inum] = raw[i].split()[j+1]
                inum += 1
    #print(time, tension_line)
# Determination of time start, time end
    tstart = input('Time start (in s), default = 400s:')
    if tstart != '':
        tstart = np.float(tstart)
    else:
        tstart = np.float('400')
    tend = input('Time end (in s), default = 10700s:')
    if tend != '':
        tend = np.float(tend)
    else:
        tend = np.float('10700')
    if tend > time[inum-1]: tend = time[inum-1]
    inum_start = 0
    inum_end = 0
    while time[inum_start] < tstart: inum_start += 1
    while time[inum_end] < tend: inum_end += 1
# Number of figures to draw
    num_fig = int(ceil(number_lines/3))
# if num_fig%3!=0 : num_fig = num_fig+1
    #print(num_fig)
    iligne = 0
    for i in range(num_fig):
        fig = plt.figure(i+1,figsize=(8.27,11.69))
        for j in range(3):
            if iligne < number_lines:
                plt.interactive(True)
                plt.subplot(3,1,j+1)
                plt.plot(time[:inum_end], tension_line[iligne,:inum_end],label='Line n°: {}'.format(iligne+1))
                plt.grid(True)
                plt.legend()
                plt.ylabel('Forces (in t)')
                iligne += 1
            else:
                break
        fig.suptitle('Forces in lines and dolphins')
        plt.xlabel('Time (in s)')
        plt.show()
# Determination of max and min
    max_line = {}
    min_line = {}
    max_line = np.zeros(number_lines).astype(np.float)
    min_line = np.zeros(number_lines).astype(np.float)
    #print(inum,len(tension_line[1,:]))
    for i in range(number_lines):
        max_line[i] = MM.Maximum(inum_start,inum_end,tension_line[i,:])
        min_line[i] = MM.Minimum(inum_start,inum_end,tension_line[i,:])
    t = PrettyTable(['Forces in line n°', 'Min','Max'])
    for i in range(number_lines):
        t.add_row([no_line[i],min_line[i],max_line[i]])
    print(t)

# Determination an ranking of of peaks in a time series
# Determination of f1/3, f1/10, hmaxstd,hminstd
    h3 = np.zeros(number_lines).astype(np.float)
    h10 = np.zeros(number_lines).astype(np.float)
    hmaxstd = np.zeros(number_lines).astype(np.float)
    hminstd = np.zeros(number_lines).astype(np.float)
    for i in range(number_lines):    
        h3[i],h10[i],hminstd[i],hmaxstd[i] = MM.Rank_peak(inum_start,inum_end,tension_line[i,:])
        if min_line[i] == 0.0: hminstd[i]=0.0
        if max_line[i] == 0.0: hmaxstd[i]=0.0

# Writing of results in a txt file
    with open('Max_Min.txt','w') as fid:
        fid.write("                  Forces\n")
        fid.write("Line n°:    Min       Max        MPMin      MPMax      F1/3       F1/10\n")
        for i in range(number_lines):
            tmp = np.array([no_line[i],min_line[i],max_line[i],hminstd[i],hmaxstd[i],h3[i],h10[i]])
            np.savetxt(fid,[tmp],fmt="%4i %10.2f %10.2f %10.2f %10.2f %10.2f %10.2f")

# MOTIONS, VELOCITIES, ACCELERATIONS OF CENTER OF GRAVITY
def Center_Gravity(repons,res_file):
    with open(res_file,'r') as df:
        raw = df.readlines()
        print('\nReading the file results in the ' + res_file + ' file')
        #print(len(raw))
        num_dt = len(raw)-5

# Enumerate to split the result file
        for i, line in enumerate(raw, start=0):

# Reading of motion type
            if 'TIME' in line:
                ty_motion = {}
                ty_motion = np.zeros(6).astype(str)
                for j in range(6):
                    ty_motion[j] = raw[i].split()[j+1]
                #print(ty_motion)
# Reading of time and motion data
        time = {}
        time = np.zeros(num_dt).astype(np.float)
        motion_CG = {}
        motion_CG = np.zeros((6,num_dt)).astype(np.float)
        inum = 0
        for i, line in enumerate(raw, start=0):
            if i > 4:
                time[inum] = raw[i].split()[0]
                tmp = 6
                for j in range(tmp):
                    motion_CG[j][inum] = raw[i].split()[j+1]
                inum += 1
    #print(time, motion_CG)
# Determination of time start, time end
    tstart = input('Time start (in s), default = 400s:')
    if tstart != '':
        tstart = np.float(tstart)
    else:
        tstart = np.float('400')
    tend = input('Time end (in s), default = 10700s:')
    if tend != '':
        tend = np.float(tend)
    else:
        tend = np.float('10700')
    if tend > time[inum-1]: tend = time[inum-1]
    inum_start = 0
    inum_end = 0
    while time[inum_start] < tstart: inum_start += 1
    while time[inum_end] < tend: inum_end += 1

# Number of figures to draw
    num_fig = int(ceil(6/3))
    #print(num_fig)
    iligne = 0
    for i in range(num_fig):
        fig = plt.figure(i+1,figsize=(8.27,11.69))
        for j in range(3):
            if iligne < 6:
                plt.interactive(True)
                plt.subplot(3,1,j+1)
                titre = ty_motion[iligne]
                plt.plot(time[:inum_end], motion_CG[iligne,:inum_end],label=titre)
                plt.grid(True)
                plt.legend()
                if iligne < 3: 
                    if repons=='2': plt.ylabel('Motion (in m)')
                    if repons=='3': plt.ylabel('Velocity (in m/s)')
                    if repons=='4': plt.ylabel('Acceleration (in m/s2)')                    
                else:
                    if repons=='2':plt.ylabel('Motion (in deg.)')
                    if repons=='3':plt.ylabel('Velocity (in deg./s)')
                    if repons=='4':plt.ylabel('Acceleration (in deg./s2)')                    
                iligne += 1
            else:
                break
        if repons=='2': fig.suptitle('Motions of Center of Gravity')
        if repons=='3': fig.suptitle('Velocities of Center of Gravity')
        if repons=='4': fig.suptitle('Accelerations of Center of Gravity')
        plt.xlabel('Time (in s)')
        plt.show()
# Determination of max and min
    max_mov = {}
    min_mov = {}
    max_mov = np.zeros(6).astype(np.float)
    min_mov = np.zeros(6).astype(np.float)
    for i in range(6):
        max_mov[i] = MM.Maximum(inum_start,inum_end,motion_CG[i,:])
        min_mov[i] = MM.Minimum(inum_start,inum_end,motion_CG[i,:])
    if repons=='2':t = PrettyTable(['Motion of CG', 'Min','Max'])
    if repons=='3':t = PrettyTable(['Velocity of CG', 'Min','Max'])
    if repons=='4':t = PrettyTable(['Acceleration of CG', 'Min','Max'])    
    for i in range(6):
        t.add_row([ty_motion[i],min_mov[i],max_mov[i]])
    print(t)

# Determination an ranking of of peaks in a time series
# Determination of f1/3, f1/10, max and min statistical values
    h3 = np.zeros(6).astype(np.float)
    h10 = np.zeros(6).astype(np.float)
    hmaxstd = np.zeros(6).astype(np.float)
    hminstd = np.zeros(6).astype(np.float)
    for i in range(6):    
        h3[i],h10[i],hminstd[i],hmaxstd[i] = MM.Rank_peakMov(inum_start,inum_end,motion_CG[i,:])

# Writing of results in a txt file
    with open('MotionCG.txt','w') as fid:
        if repons=='2': fid.write("                  Motion\n")
        if repons=='3': fid.write("                Velocity\n")
        if repons=='4': fid.write("            Acceleration\n")
        fid.write("Type:        Min       Max        MPMin      MPMax      F1/3       F1/10\n")
        for i in range(6):
            tmp = np.array([ty_motion[i],min_mov[i],max_mov[i],hminstd[i],hmaxstd[i],h3[i],h10[i]])
            np.savetxt(fid,[tmp],fmt="%-10.6s")

# MOTIONS, VELOCITIES, ACCELERATIONS OF A PARTICULAR POINT
def Point(repons,res_file):
    with open(res_file,'r') as df:
        raw = df.readlines()
        print('\nReading the file results in the ' + res_file + ' file')
        #print(len(raw))
        num_dt = len(raw)-5

# Enumerate to split the result file
        for i, line in enumerate(raw, start=0):

# Reading of motion type
            if 'TIME' in line:
                ty_motion = {}
                ty_motion = np.zeros(3).astype(str)
                for j in range(3):
                    ty_motion[j] = raw[i].split()[j+1]
                #print(ty_motion)
# Reading of time and motion data
        time = {}
        time = np.zeros(num_dt).astype(np.float)
        motion_PT = {}
        motion_PT = np.zeros((3,num_dt)).astype(np.float)
        inum = 0
        for i, line in enumerate(raw, start=0):
            if i > 4:
                time[inum] = raw[i].split()[0]
                tmp = 3
                for j in range(tmp):
                    motion_PT[j][inum] = raw[i].split()[j+1]
                inum += 1
    #print(time, motion_PT)
# Determination of time start, time end
    tstart = input('Time start (in s), default = 400s:')
    if tstart != '':
        tstart = np.float(tstart)
    else:
        tstart = np.float('400')
    tend = input('Time end (in s), default = 10700s:')
    if tend != '':
        tend = np.float(tend)
    else:
        tend = np.float('10700')
    if tend > time[inum-1]: tend = time[inum-1]
    inum_start = 0
    inum_end = 0
    while time[inum_start] < tstart: inum_start += 1
    while time[inum_end] < tend: inum_end += 1

# Number of figures to draw
    num_fig = int(ceil(3/3))
    #print(num_fig)
    iligne = 0
    for i in range(num_fig):
        fig = plt.figure(i+1,figsize=(8.27,11.69))
        for j in range(3):
            if iligne < 3:
                plt.interactive(True)
                plt.subplot(3,1,j+1)                
                titre = ty_motion[iligne]
                plt.plot(time[:inum_end], motion_PT[iligne,:inum_end],label=titre)
                plt.grid(True)
                plt.legend()
                if repons=='5': plt.ylabel('Motion (in m)')
                if repons=='6': plt.ylabel('Velocity (in m/s)')
                if repons=='7': plt.ylabel('Acceleration (in m/s2)')
                iligne += 1
            else:
                break
        if repons=='5': fig.suptitle('Motions of a Particular Point')
        if repons=='6': fig.suptitle('Velocities of a Particular Point')
        if repons=='7': fig.suptitle('Accelerations of a Particular Point')      
        plt.xlabel('Time (in s)')
        plt.show()
# Determination of max and min
    max_mov = {}
    min_mov = {}
    max_mov = np.zeros(3).astype(np.float)
    min_mov = np.zeros(3).astype(np.float)
    for i in range(3):
        max_mov[i] = MM.Maximum(inum_start,inum_end,motion_PT[i,:])
        min_mov[i] = MM.Minimum(inum_start,inum_end,motion_PT[i,:])
    if repons=='5': t = PrettyTable(['Motion of a Particular Point', 'Min','Max'])
    if repons=='6': t = PrettyTable(['Velocity of a Particular Point', 'Min','Max'])
    if repons=='7': t = PrettyTable(['Acceleration of a Particular Point', 'Min','Max'])
    for i in range(3):
        t.add_row([ty_motion[i],min_mov[i],max_mov[i]])
    print(t)

# Determination an ranking of of peaks in a time series
# Determination of f1/3, f1/10, max and min statistical values
    h3 = np.zeros(3).astype(np.float)
    h10 = np.zeros(3).astype(np.float)
    hmaxstd = np.zeros(3).astype(np.float)
    hminstd = np.zeros(3).astype(np.float)
    for i in range(3):    
        h3[i],h10[i],hminstd[i],hmaxstd[i] = MM.Rank_peakMov(inum_start,inum_end,motion_PT[i,:])

# Writing of results in a txt file
    with open('MotionPT.txt','w') as fid:
        if repons=='5': fid.write("                  Motion\n")
        if repons=='6': fid.write("                Velocity\n")
        if repons=='7': fid.write("            Acceleration\n")
        fid.write("Type:        Min       Max        MPMin      MPMax      F1/3       F1/10\n")
        for i in range(3):
            tmp = np.array([ty_motion[i],min_mov[i],max_mov[i],hminstd[i],hmaxstd[i],h3[i],h10[i]])
            np.savetxt(fid,[tmp],fmt="%-10.6s")
