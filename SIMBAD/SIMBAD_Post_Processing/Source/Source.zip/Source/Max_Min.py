##  This file is part of SIMBAD post-processing program.

##  SIMBAD post-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD post-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD post-processing program.
##  If not, see <https://www.gnu.org/licenses/>.

# Import modules
from scipy.signal import find_peaks
import numpy as np
import matplotlib.pyplot as plt
from math import ceil

# Function maximum
def Maximum(inum_start,inum_end,liste):
    maxi = liste[inum_start]
    longueur=len(liste)
    for i in range(inum_start,inum_end):
        if liste[i] >= maxi:
            maxi = liste[i]
    return maxi

# Function minimum
def Minimum(inum_start,inum_end,liste):
    mini = liste[inum_start]
    longueur=len(liste)
    for i in range(inum_start,inum_end):
        if liste[i] <= mini:
            mini = liste[i]
    return mini

# Function determination and ranking of peaks in a time series
def Rank_peak(inum_start,inum_end,liste):
    x = liste[inum_start:inum_end]
    mean_x = np.mean(x)
    p1 = liste[inum_start]
    p2 = liste[inum_start+1]
    if mean_x>=0:
        peaks, _ = find_peaks(x, height=mean_x)
        x_sort = sorted(x[peaks],reverse=True)
##        print(x_sort)
    else:
        peaks, _ = find_peaks(-x, height=-mean_x)
        x_sort = sorted(x[peaks])
##        print(x_sort)

# Calculation of F1/3 and F1/10
    number_peaks = len(peaks)
    h3 = 0.0
    num_h3 = int(ceil(number_peaks/3))
    if num_h3!=0:
        for i in range(num_h3):
              h3= h3+x_sort[i]
        h3= h3/num_h3
    else:
        print("Determination of F1/3 not possible")

    h10 = 0.0
    num_h10 = int(ceil(number_peaks/10))
    if num_h10!=0:
        for i in range(num_h10):
              h10= h10+x_sort[i]
        h10= h10/num_h10
    else:
        print("Determination of F1/10 not possible")
##    print(number_peaks,num_h3,num_h10)
##    plt.plot(x)
##    plt.plot(peaks, x[peaks], "x")
##    plt.plot(np.full_like(x,mean_x), "--", color="gray")
##    plt.show()

    return h3,h10

# Function determination and ranking of peaks in a time series
def Rank_peakMov(inum_start,inum_end,liste):
    x = liste[inum_start:inum_end]
    peaks1, _ = find_peaks(x, height=0)
    x_sort1 = sorted(x[peaks1],reverse=True)
##    print(x_sort1)

    peaks2, _ = find_peaks(-x, height=0)
    x_sort2 = sorted(x[peaks2])
##    print(x_sort2)

##    plt.plot(x)
##    plt.plot(peaks2, x[peaks2], "x")
##    plt.plot(np.full_like(x,0), "--", color="gray")
##    plt.show()

    number_peaks1 = len(peaks1)
    h31 = 0.0
    num_h31 = int(ceil(number_peaks1/3))
    if num_h31!=0:
        for i in range(num_h31):
              h31= h31+x_sort1[i]
        h31= h31/num_h31
    else:
        print("Determination of F1/3 not possible")

# Calculation of mean and standard deviation,
# statistical maximum and minimum values
    hmean = np.mean(x)
    hstd = np.std(x)
    hmaxstd = hmean + 3.8*hstd
    hminstd = hmean - 3.8*hstd

# Calculation of F1/3 and F1/10
    number_peaks2 = len(peaks2)
    h32 = 0.0
    num_h32 = int(ceil(number_peaks2/3))
    if num_h32!=0:
        for i in range(num_h32):
              h32= h32+x_sort2[i]
        h32= h32/num_h32
    else:
        print("Determination of F1/3 not possible")

    h3 = max(h31,abs(h32))
    if h3 == abs(h32):
        h3 = -h3
##    print(h31,h32,h3)
    
    h101 = 0.0
    num_h101 = int(ceil(number_peaks1/10))
    if num_h101!=0:
        for i in range(num_h101):
              h101= h101+x_sort1[i]
        h101= h101/num_h101
    else:
        print("Determination of F1/10 not possible")

    h102 = 0.0
    num_h102 = int(ceil(number_peaks2/10))
    if num_h102!=0:
        for i in range(num_h102):
              h102= h102+x_sort2[i]
        h102= h102/num_h102
    else:
        print("Determination of F1/10 not possible")

    h10 = max(h101,abs(h102))
    if h10 == abs(h102):
        h10 = -h10
##    print(h101,h102,h10)

    return h3,h10,hminstd,hmaxstd
