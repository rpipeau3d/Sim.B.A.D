from cx_Freeze import setup, Executable
base = None
#Remplacer "monprogramme.py" par le nom du script qui lance votre programme
executables = [Executable("RUN.py", base=base)]
#Renseignez ici la liste complète des packages utilisés par votre application
packages = ["idna",
            "Analyse.py",
            "Max_Min.py",
            ]
options = {
    'build_exe': {    
        'packages':packages,
    },
}
#Adaptez les valeurs des variables "name", "version", "description" à votre programme.
setup(
    name = "Output_SIMBAD",
    options = options,
    version = "0.1",
    author = "PFD",
    description = 'Output from SIMBAD',
    executables = executables
)
