##  This file is part of SIMBAD post-processing program.

##  SIMBAD post-processing program is free software:
##  you can redistribute it and/or modify it under the terms
##  of the GNU General Public License as published by
##  the Free Software Foundation, version 3 of the License.
##
##  SIMBAD post-processing program is distributed in the hope
##  that it will be useful,but WITHOUT ANY WARRANTY;
##  without even the implied warranty of MERCHANTABILITY or
##  FITNESS FOR A PARTICULAR PURPOSE. See the
##  GNU General Public License for more details.
##
##  You should have received a copy of the GNU General Public License
##  along with SIMBAD post-processing program.
##  If not, see <https://www.gnu.org/licenses/>.


# Import modules
import numpy as np
import Analyse as An

# Choice of one result file
repons = input('1: Tensions in lines,\n'
               +'2: Motions of CG,\n'
               +'3: Velocities of CG,\n'
               +'4: Accelerations of CG,\n'
               +'5: Motions of a particular point,\n'
               +'6: Velocities of a particular point,\n'
               +'7: Accelerations of a particular point\n'
               )
if '1' in repons: res_file = str('LINES.RES')
if '2' in repons: res_file = str('MOVCG.RES')
if '3' in repons: res_file = str('VELCG.RES')
if '4' in repons: res_file = str('ACCCG.RES')
if '5' in repons: res_file = str('MOVPT 1.RES')
if '6' in repons: res_file = str('VELPT 1.RES')
if '7' in repons: res_file = str('ACCPT 1.RES')

# TENSIONS IN LINES AND DOLPHINS
if '1' in repons:
    try:
        f = open(res_file)
        An.Tensions(res_file)
    except IOError:
        print("File LINES.RES not accessible")

# MOTIONS OF CENTER OF GRAVITY
if '2' in repons:
    try:
        f = open(res_file)
        An.Center_Gravity('2',res_file)
    except IOError:
        print("File MOVCG.RES not accessible")

# VELOCITIES OF CENTER OF GRAVITY
if '3' in repons:
    try:
        f = open(res_file)
        An.Center_Gravity('3',res_file)
    except IOError:
        print("File VELCG.RES not accessible")    

# ACCELERATIONS OF CENTER OF GRAVITY
if '4' in repons:
    try:
        f = open(res_file)
        An.Center_Gravity('4',res_file)
    except IOError:
        print("File ACCCG.RES not accessible")    

# MOTIONS OF A PARTICULAR POINT
if '5' in repons:
    try:
        f = open(res_file)
        An.Point('5',res_file)
    except IOError:
        print("File MOVPT 1.RES not accessible")    

# VELOCITIES OF A PARTICULAR POINT
if '6' in repons:
    try:
        f = open(res_file)
        An.Point('6',res_file)
    except IOError:
        print("File VELPT 1.RES not accessible")   

# ACCELERATIONS OF A PARTICULAR POINT
if '7' in repons:
    try:
        f = open(res_file)
        An.Point('7',res_file)
    except IOError:
        print("File ACCPT 1.RES not accessible")   

#
input("Press the ENTER key to continue...")
